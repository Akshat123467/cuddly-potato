/**
 * BillionaireWatch.in - D3.js Growth Trend Sparkline Engine
 * Renders interactive multi-year wealth trajectory sparklines inside every billionaire card
 * using D3 v7 (d3.scaleLinear, d3.line, d3.area, d3.curveMonotoneX, d3.pointer).
 */
(function() {
  'use strict';

  const DEFAULT_YEARS = [2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026];

  // Authoritative 2016-2026 trajectory baseline (in Billions USD)
  const FALLBACK_SERIES = {
    'elon-musk':       [11.6, 13.9, 20.8, 19.9, 22.3, 25.6, 36.2, 151.0, 219.0, 340.0, 894.3],
    'jeff-bezos':      [60.8, 72.8, 99.6, 112.0, 131.0, 160.0, 184.0, 177.0, 171.0, 194.0, 385.3],
    'larry-page':      [37.2, 40.7, 44.6, 48.8, 53.4, 58.9, 67.5, 91.5, 123.0, 198.0, 246.8],
    'sergey-brin':     [36.4, 39.8, 43.5, 47.6, 52.1, 57.5, 65.9, 89.0, 118.0, 189.0, 227.2],
    'michael-dell':    [19.8, 22.4, 27.6, 31.0, 32.3, 45.1, 55.1, 50.1, 91.0, 138.0, 219.2],
    'mark-zuckerberg': [44.6, 56.0, 71.0, 62.3, 55.5, 69.6, 97.0, 85.0, 64.0, 105.0, 214.3],
    'larry-ellison':   [49.3, 49.3, 58.4, 60.3, 62.5, 65.1, 72.6, 93.0, 117.0, 192.0, 167.7],
    'warren-buffett':  [60.8, 75.6, 84.0, 82.5, 87.0, 80.8, 96.0, 109.0, 118.0, 121.0, 167.6],
    'steve-ballmer':   [25.3, 27.7, 30.3, 33.2, 36.3, 41.2, 52.7, 80.0, 107.0, 138.0, 162.0],
    'amancio-ortega':  [67.0, 71.0, 77.0, 83.0, 70.0, 62.7, 55.1, 77.0, 65.0, 78.0, 151.9],
    'bernard-arnault': [39.5, 41.5, 76.0, 91.9, 106.0, 152.0, 180.0, 150.0, 211.0, 192.0, 145.6],
    'mukesh-ambani':   [20.6, 22.9, 38.0, 41.2, 50.4, 64.2, 88.7, 84.5, 90.7, 91.8, 92.9],
    'gautam-adani':    [5.5, 7.1, 9.2, 11.8, 15.1, 25.2, 90.0, 150.0, 60.8, 68.3, 83.6],
    'savitri-jindal':  [5.8, 6.3, 6.9, 7.5, 8.2, 9.0, 10.5, 18.0, 25.0, 32.0, 41.2],
    'shiv-nadar':      [14.8, 16.2, 17.7, 19.3, 21.1, 23.1, 25.3, 28.5, 31.5, 34.9, 30.8],
    'lakshmi-mittal':  [8.4, 16.5, 18.5, 13.6, 10.3, 14.9, 17.9, 16.4, 16.4, 21.8, 30.6],
    'dilip-shanghvi':  [18.4, 20.1, 22.0, 16.3, 12.5, 15.8, 18.5, 21.8, 23.5, 24.2, 27.0]
  };

  function hashSeed(str) {
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return Math.abs(h);
  }

  function buildSeriesForPerson(person) {
    const id = String(person?.id || person?.forbesUri || person?.name || 'billionaire').toLowerCase();
    const liveWorth = Math.max(0.5, Number(person?.netWorth ?? person?.netWorthUsd ?? 10));
    const histMap = window.BW_HISTORICAL_DATA || {};
    const histEntry = histMap[id];

    let years = DEFAULT_YEARS.slice();
    let values = null;

    if (histEntry && Array.isArray(histEntry.data) && histEntry.data.length >= 2) {
      years = Array.isArray(histEntry.years) && histEntry.years.length === histEntry.data.length
        ? histEntry.years.slice()
        : DEFAULT_YEARS.slice(-histEntry.data.length);
      values = histEntry.data.map(v => Number(v));
      values[values.length - 1] = parseFloat(liveWorth.toFixed(1));
    } else if (FALLBACK_SERIES[id]) {
      values = FALLBACK_SERIES[id].slice();
      values[values.length - 1] = parseFloat(liveWorth.toFixed(1));
    } else {
      // Deterministic compounding curve for dynamically ranked Forbes RTB entrants
      const seed = hashSeed(id);
      const daily = Number(person?.dailyChange || 0);
      const baseRatio = 0.28 + ((seed % 28) / 100); // 0.28 to 0.55 of current worth in 2016
      const startVal = Math.max(1.0, liveWorth * baseRatio);
      values = years.map((_, idx) => {
        if (idx === years.length - 1) return parseFloat(liveWorth.toFixed(1));
        const t = idx / (years.length - 1);
        const wave = Math.sin((seed % 7) + idx * 0.85) * 0.065;
        const momentumBoost = daily >= 0 ? 1 + (t * 0.04) : 1 - (t * 0.02);
        const interp = startVal + (liveWorth - startVal) * Math.pow(t, 1.35) * (1 + wave) * momentumBoost;
        return parseFloat(Math.max(0.5, interp).toFixed(1));
      });
    }

    return years.map((yr, i) => ({
      index: i,
      year: yr,
      value: Number(values[i] || 0)
    }));
  }

  let uidCounter = 0;

  function renderIntoSlot(slot, person, options = {}) {
    if (!slot || !person) return;

    const points = buildSeriesForPerson(person);
    if (!points.length) return;

    const firstPt = points[0];
    const lastPt = points[points.length - 1];
    const growthPct = firstPt.value > 0
      ? ((lastPt.value - firstPt.value) / firstPt.value) * 100
      : 0;
    const isUp = growthPct >= 0;
    const isIndia = Boolean(options.isIndiaGrid);
    const isLightTheme = document.documentElement.getAttribute('data-theme') === 'light';

    const strokeColor = isLightTheme
      ? (isIndia ? (isUp ? '#ea580c' : '#dc2626') : (isUp ? '#16a34a' : '#dc2626'))
      : (isIndia ? (isUp ? '#ff9933' : '#f87171') : (isUp ? '#4ade80' : '#f87171'));

    const dotStrokeColor = isLightTheme ? '#ffffff' : '#0f0f1a';
    const baselineColor = isLightTheme ? 'rgba(100, 116, 139, 0.32)' : 'rgba(249, 199, 79, 0.22)';
    const guideColor = isLightTheme ? '#334155' : '#f9c74f';

    const gradId = `bw-spark-grad-${++uidCounter}`;
    const pctText = `${isUp ? '+' : ''}${Math.abs(growthPct) >= 100 ? Math.round(growthPct).toLocaleString('en-US') : growthPct.toFixed(1)}%`;

    slot.innerHTML = `
      <div class="growth-trend-box" aria-label="10-Year Net Worth Growth Trend for ${person.name || 'Billionaire'}">
        <div class="growth-trend-header">
          <span class="growth-trend-title">
            Growth Trend <span class="growth-trend-sub">(${firstPt.year}&ndash;${lastPt.year})</span>
          </span>
          <span class="growth-trend-readout ${isUp ? 'up' : 'down'}" data-default-text="${pctText}" data-default-class="growth-trend-readout ${isUp ? 'up' : 'down'}">
            ${isUp ? '▲' : '▼'} ${pctText}
          </span>
        </div>
        <div class="growth-trend-chart-host"></div>
        <div class="growth-trend-footer">
          <span class="growth-trend-edge">${firstPt.year}: $${firstPt.value.toFixed(1)}B</span>
          <span class="growth-trend-edge growth-trend-edge-live">Now: $${lastPt.value.toFixed(1)}B</span>
        </div>
      </div>
    `;

    const chartHost = slot.querySelector('.growth-trend-chart-host');
    const readoutEl = slot.querySelector('.growth-trend-readout');
    if (!chartHost) return;

    const width = 240;
    const height = 52;
    const padX = 5;
    const padTop = 6;
    const padBottom = 5;

    // Primary path: render using D3.js v7
    if (window.d3 && typeof window.d3.scaleLinear === 'function') {
      const d3 = window.d3;
      const x = d3.scaleLinear()
        .domain([0, points.length - 1])
        .range([padX, width - padX]);

      const extent = d3.extent(points, d => d.value);
      const minV = extent[0];
      const maxV = extent[1];
      const span = Math.max(1, maxV - minV);
      const y = d3.scaleLinear()
        .domain([Math.max(0, minV - span * 0.12), maxV + span * 0.12])
        .range([height - padBottom, padTop]);

      const svg = d3.select(chartHost)
        .append('svg')
        .attr('viewBox', `0 0 ${width} ${height}`)
        .attr('preserveAspectRatio', 'none')
        .attr('class', 'growth-sparkline-svg')
        .attr('role', 'img')
        .attr('aria-label', `${person.name || 'Billionaire'} net worth trend from $${firstPt.value.toFixed(1)}B in ${firstPt.year} to $${lastPt.value.toFixed(1)}B in ${lastPt.year}`);

      const defs = svg.append('defs');
      const grad = defs.append('linearGradient')
        .attr('id', gradId)
        .attr('x1', '0%')
        .attr('y1', '0%')
        .attr('x2', '0%')
        .attr('y2', '100%');

      grad.append('stop')
        .attr('offset', '0%')
        .attr('stop-color', strokeColor)
        .attr('stop-opacity', isLightTheme ? 0.25 : 0.34);

      grad.append('stop')
        .attr('offset', '100%')
        .attr('stop-color', strokeColor)
        .attr('stop-opacity', 0.02);

      // Subtle reference baseline
      svg.append('line')
        .attr('x1', padX)
        .attr('x2', width - padX)
        .attr('y1', y(firstPt.value))
        .attr('y2', y(firstPt.value))
        .attr('stroke', baselineColor)
        .attr('stroke-width', 1)
        .attr('stroke-dasharray', '3,3');

      const areaGen = d3.area()
        .x(d => x(d.index))
        .y0(height - padBottom)
        .y1(d => y(d.value))
        .curve(d3.curveMonotoneX);

      const lineGen = d3.line()
        .x(d => x(d.index))
        .y(d => y(d.value))
        .curve(d3.curveMonotoneX);

      svg.append('path')
        .datum(points)
        .attr('fill', `url(#${gradId})`)
        .attr('d', areaGen);

      svg.append('path')
        .datum(points)
        .attr('fill', 'none')
        .attr('stroke', strokeColor)
        .attr('stroke-width', 2.2)
        .attr('stroke-linecap', 'round')
        .attr('stroke-linejoin', 'round')
        .attr('d', lineGen);

      // End node highlight
      svg.append('circle')
        .attr('cx', x(lastPt.index))
        .attr('cy', y(lastPt.value))
        .attr('r', 3.4)
        .attr('fill', strokeColor)
        .attr('stroke', dotStrokeColor)
        .attr('stroke-width', 1.2);

      // Interactive hover scrub guide & dot
      const guideLine = svg.append('line')
        .attr('y1', padTop - 2)
        .attr('y2', height - padBottom + 2)
        .attr('stroke', guideColor)
        .attr('stroke-width', 1)
        .attr('stroke-dasharray', '2,2')
        .style('opacity', 0);

      const hoverDot = svg.append('circle')
        .attr('r', 3.8)
        .attr('fill', guideColor)
        .attr('stroke', dotStrokeColor)
        .attr('stroke-width', 1.3)
        .style('opacity', 0);

      const resetReadout = () => {
        guideLine.style('opacity', 0);
        hoverDot.style('opacity', 0);
        if (readoutEl) {
          readoutEl.textContent = `${isUp ? '▲' : '▼'} ${pctText}`;
          readoutEl.className = readoutEl.getAttribute('data-default-class') || 'growth-trend-readout up';
        }
      };

      svg.append('rect')
        .attr('x', 0)
        .attr('y', 0)
        .attr('width', width)
        .attr('height', height)
        .attr('fill', 'transparent')
        .style('cursor', 'crosshair')
        .on('mousemove touchmove', function(event) {
          const [mx] = d3.pointer(event);
          const rawIdx = x.invert(mx);
          const clampedIdx = Math.max(0, Math.min(points.length - 1, Math.round(rawIdx)));
          const pt = points[clampedIdx];
          if (!pt) return;
          const cx = x(pt.index);
          const cy = y(pt.value);
          guideLine.attr('x1', cx).attr('x2', cx).style('opacity', 0.85);
          hoverDot.attr('cx', cx).attr('cy', cy).style('opacity', 1);
          if (readoutEl) {
            readoutEl.textContent = `${pt.year}: $${pt.value.toFixed(1)}B`;
          }
        })
        .on('mouseleave touchend', resetReadout);
      return;
    }

    // Lightweight deterministic SVG fallback if D3 hasn't loaded yet
    const minV = Math.min(...points.map(p => p.value));
    const maxV = Math.max(...points.map(p => p.value));
    const span = Math.max(1, maxV - minV);
    const coords = points.map((p, i) => {
      const px = padX + (i / Math.max(1, points.length - 1)) * (width - padX * 2);
      const normY = (p.value - (minV - span * 0.1)) / (span * 1.2);
      const py = (height - padBottom) - normY * (height - padTop - padBottom);
      return [px.toFixed(1), py.toFixed(1)];
    });
    const pathD = coords.map((c, i) => `${i === 0 ? 'M' : 'L'}${c[0]},${c[1]}`).join(' ');
    chartHost.innerHTML = `
      <svg viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" class="growth-sparkline-svg">
        <path d="${pathD}" fill="none" stroke="${strokeColor}" stroke-width="2.2" stroke-linecap="round"></path>
      </svg>
    `;
  }

  function renderCard(cardEl, person, options = {}) {
    if (!cardEl || !person) return;
    const slot = cardEl.querySelector('.growth-trend-slot');
    if (slot) {
      renderIntoSlot(slot, person, options);
    }
  }

  window.BillionaireSparkline = {
    renderIntoSlot,
    renderCard,
    buildSeriesForPerson
  };
})();
