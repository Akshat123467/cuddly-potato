/**
 * BillionaireWatch.in - Interactive AI Wealth Assistant ("BillionaireWatch AI")
 *
 * Powered by:
 * 1. Grounded Financial Analysis (/api/chat -> SEC EDGAR, BSE/NSE Disclosures & Public Market Quotes).
 * 2. Cached Wealth Valuation Engine (window.BillionaireWatchData).
 * 3. Live Dynamic Forex Engine: Instant USD to INR (₹ Crores & ₹ Lakh Crores) conversions.
 * 4. High-Contrast WCAG AA theme compliance & clickable regulatory citations.
 */
(function() {
  'use strict';

  const BOT_TITLE = "BillionaireWatch AI";
  const STORAGE_SESSION_KEY = 'bw_chat_history_v3';
  const DEFAULT_FX_RATE = 94.09;

  // Fallback Dual-Source Wealth Intelligence Database (used only if live API feed is unreachable)
  const DUAL_INDEX_DATABASE = [
    {
      id: "elon-musk",
      name: "Elon Musk",
      country: "United States 🇺🇸",
      company: "Tesla (TSLA), SpaceX, xAI, Neuralink, X",
      netWorthUsd: 894.3,
      publicEquityUsd: 824.2,
      vestedOptionsUsd: 46.0,
      privateAssetsUsd: 24.0,
      globalRank: 1,
      hasDedicatedProfile: true,
      keyAssets: "SpaceX common stock & vested performance options (~4.77B sh + 350M options), Tesla equity (~395.6M sh), xAI & Neuralink private holdings.",
      methodologyNote: "Real-time valuation combines public Tesla shares, SpaceX common equity + in-the-money vested options (Market minus Strike), and private xAI/Neuralink stakes."
    },
    {
      id: "jeff-bezos",
      name: "Jeff Bezos",
      country: "United States 🇺🇸",
      company: "Amazon (AMZN), Blue Origin, Bezos Expeditions",
      netWorthUsd: 385.3,
      publicEquityUsd: 221.4,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 163.9,
      globalRank: 2,
      hasDedicatedProfile: true,
      keyAssets: "Amazon.com common shares, Blue Origin aerospace valuation, Bezos Expeditions.",
      methodologyNote: "Reflects daily NASDAQ AMZN close plus private aerospace and venture valuations."
    },
    {
      id: "larry-page",
      name: "Larry Page",
      country: "United States 🇺🇸",
      company: "Alphabet / Google (GOOGL)",
      netWorthUsd: 246.8,
      publicEquityUsd: 241.0,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 5.8,
      globalRank: 3,
      hasDedicatedProfile: true,
      keyAssets: "Alphabet Class A, B & C common shares, Waymo & AI ventures.",
      methodologyNote: "Verified against SEC Form 4 insider filings and NASDAQ daily prices."
    },
    {
      id: "sergey-brin",
      name: "Sergey Brin",
      country: "United States 🇺🇸",
      company: "Alphabet / Google (GOOGL)",
      netWorthUsd: 227.2,
      publicEquityUsd: 221.5,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 5.7,
      globalRank: 4,
      hasDedicatedProfile: true,
      keyAssets: "Alphabet Class A, B & C shares, LTA aerospace research.",
      methodologyNote: "Tracked daily via NASDAQ trading volume and SEC beneficial ownership filings."
    },
    {
      id: "michael-dell",
      name: "Michael Dell",
      country: "United States 🇺🇸",
      company: "Dell Technologies (DELL), Broadcom",
      netWorthUsd: 219.2,
      publicEquityUsd: 192.4,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 26.8,
      globalRank: 5,
      hasDedicatedProfile: true,
      keyAssets: "Dell Technologies controlling stake, Broadcom shares, DFO Management private investments.",
      methodologyNote: "Tracks NYSE DELL share price plus DFO Management family office valuations."
    },
    {
      id: "mark-zuckerberg",
      name: "Mark Zuckerberg",
      country: "United States 🇺🇸",
      company: "Meta Platforms (META)",
      netWorthUsd: 214.3,
      publicEquityUsd: 210.8,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 3.5,
      globalRank: 6,
      hasDedicatedProfile: true,
      keyAssets: "Meta Platforms Class A & B voting equity, Chan Zuckerberg Initiative.",
      methodologyNote: "Calculated daily from META share price and SEC proxy disclosures."
    },
    {
      id: "larry-ellison",
      name: "Larry Ellison",
      country: "United States 🇺🇸",
      company: "Oracle Corporation (ORCL)",
      netWorthUsd: 167.7,
      publicEquityUsd: 155.2,
      vestedOptionsUsd: 4.5,
      privateAssetsUsd: 8.0,
      globalRank: 7,
      hasDedicatedProfile: true,
      keyAssets: "Oracle Corporation common equity (~42%), vested Oracle executive options, Tesla stake, Lanai estate.",
      methodologyNote: "Reflects NYSE ORCL close, in-the-money vested options, and pledged/unpledged collateral disclosures."
    },
    {
      id: "warren-buffett",
      name: "Warren Buffett",
      country: "United States 🇺🇸",
      company: "Berkshire Hathaway (BRK.A / BRK.B)",
      netWorthUsd: 167.6,
      publicEquityUsd: 166.1,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 1.5,
      globalRank: 8,
      hasDedicatedProfile: true,
      keyAssets: "Berkshire Hathaway Class A shares after $55B+ in cumulative charitable donations.",
      methodologyNote: "Verified quarterly via Berkshire SEC 13F & Form 4 share conversion disclosures."
    },
    {
      id: "steve-ballmer",
      name: "Steve Ballmer",
      country: "United States 🇺🇸",
      company: "Microsoft (MSFT), LA Clippers",
      netWorthUsd: 162.0,
      publicEquityUsd: 153.5,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 8.5,
      globalRank: 9,
      hasDedicatedProfile: true,
      keyAssets: "Microsoft common stock (~333M shares), LA Clippers NBA franchise, Intuit Dome.",
      methodologyNote: "Combines MSFT market equity with sports franchise valuations."
    },
    {
      id: "amancio-ortega",
      name: "Amancio Ortega",
      country: "Spain 🇪🇸",
      company: "Inditex / Zara, Pontegadea",
      netWorthUsd: 151.9,
      publicEquityUsd: 132.4,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 19.5,
      globalRank: 10,
      hasDedicatedProfile: true,
      keyAssets: "Inditex (~59% stake) and Pontegadea commercial real estate.",
      methodologyNote: "BME Madrid closing price converted daily to USD."
    },
    {
      id: "mukesh-ambani",
      name: "Mukesh Ambani",
      country: "India 🇮🇳",
      company: "Reliance Industries, Jio Platforms, Reliance Retail",
      netWorthUsd: 92.9,
      publicEquityUsd: 88.4,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 4.5,
      globalRank: 22,
      indiaRank: 1,
      hasDedicatedProfile: true,
      keyAssets: "Reliance Industries (~50% promoter stake), Jio Platforms, Reliance Retail, Jamnagar Green Energy.",
      methodologyNote: "Tracked daily across BSE/NSE closing equity valuation plus unlisted subsidiary estimates."
    },
    {
      id: "gautam-adani",
      name: "Gautam Adani",
      country: "India 🇮🇳",
      company: "Adani Enterprises, Adani Ports, Adani Green",
      netWorthUsd: 83.6,
      publicEquityUsd: 81.2,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 2.4,
      globalRank: 26,
      indiaRank: 2,
      hasDedicatedProfile: true,
      keyAssets: "Listed Adani Group entities (Ports, Enterprises, Green Energy, Transmission, Power).",
      methodologyNote: "Derived from daily NSE/BSE market capitalization of promoter holdings."
    }
  ];

  function formatInr(crores) {
    if (isNaN(crores) || crores === null || crores === undefined) return '0';
    const parts = Math.round(crores).toString().split('.');
    let lastThree = parts[0].substring(parts[0].length - 3);
    const otherNumbers = parts[0].substring(0, parts[0].length - 3);
    if (otherNumbers !== '') {
      lastThree = ',' + lastThree;
    }
    return otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
  }

  function formatLakhCr(crores) {
    if (!crores) return '0 Cr';
    const lakhCr = (crores / 100000).toFixed(2);
    return `₹${lakhCr} Lakh Cr (₹${formatInr(crores)} Crores)`;
  }

  function getActiveFxRate() {
    return (window.BillionaireWatchData && window.BillionaireWatchData.getFxRate()) || DEFAULT_FX_RATE;
  }

  function getLiveAllPool() {
    if (window.BillionaireWatchData && typeof window.BillionaireWatchData.getAll === 'function') {
      const pool = window.BillionaireWatchData.getAll();
      if (Array.isArray(pool) && pool.length > 0) {
        return [...pool].sort((a, b) => Number(b.netWorth ?? b.netWorthUsd ?? 0) - Number(a.netWorth ?? a.netWorthUsd ?? 0));
      }
    }
    return [...DUAL_INDEX_DATABASE].sort((a, b) => Number(b.netWorthUsd) - Number(a.netWorthUsd));
  }

  function injectStyles() {
    if (document.getElementById('bw-ai-bot-styles')) return;

    const style = document.createElement('style');
    style.id = 'bw-ai-bot-styles';
    style.textContent = `
      #bw-ai-bot-root {
        position: fixed;
        bottom: 24px;
        right: 24px;
        z-index: 99999;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      }

      .bw-bot-launcher {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        background: linear-gradient(135deg, #FFA500, #ff8c00);
        color: #1a1a2e;
        border: 2px solid #ffffff;
        padding: 12px 22px;
        border-radius: 50px;
        box-shadow: 0 8px 25px rgba(255, 165, 0, 0.5);
        cursor: pointer;
        font-weight: 800;
        font-size: 0.95rem;
        transition: all 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);
        user-select: none;
      }

      .bw-bot-launcher:hover {
        transform: translateY(-3px) scale(1.03);
        box-shadow: 0 12px 30px rgba(255, 165, 0, 0.7);
      }

      .bw-bot-launcher .bw-pulse-dot {
        width: 10px;
        height: 10px;
        background: #10b981;
        border: 2px solid #ffffff;
        border-radius: 50%;
        box-shadow: 0 0 8px #10b981;
        animation: bwPulse 1.8s infinite;
      }

      @keyframes bwPulse {
        0% { transform: scale(0.9); opacity: 0.8; }
        50% { transform: scale(1.35); opacity: 0.4; }
        100% { transform: scale(0.9); opacity: 0.8; }
      }

      .bw-chat-window {
        position: fixed;
        bottom: 86px;
        right: 24px;
        width: 440px;
        max-width: calc(100vw - 32px);
        height: 640px;
        max-height: calc(100vh - 110px);
        background: #16213e;
        color: #ffffff;
        border: 2px solid #FFA500;
        border-radius: 18px;
        box-shadow: 0 20px 50px rgba(0, 0, 0, 0.75);
        display: flex;
        flex-direction: column;
        overflow: hidden;
        opacity: 0;
        transform: translateY(20px) scale(0.95);
        pointer-events: none;
        transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        z-index: 100000;
      }

      .bw-chat-window.open {
        opacity: 1;
        transform: translateY(0) scale(1);
        pointer-events: all;
      }

      .bw-chat-header {
        background: #0f172a;
        padding: 14px 18px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-bottom: 2px solid rgba(255, 165, 0, 0.3);
      }

      .bw-header-info {
        display: flex;
        align-items: center;
        gap: 12px;
      }

      .bw-bot-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: linear-gradient(135deg, #FFA500, #ff8c00);
        color: #1a1a2e;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.2rem;
        box-shadow: 0 4px 12px rgba(255, 165, 0, 0.4);
      }

      .bw-header-title {
        font-size: 1.05rem;
        font-weight: 800;
        color: #FFA500;
        margin: 0;
        line-height: 1.2;
      }

      .bw-header-status {
        font-size: 0.75rem;
        color: #4ade80;
        display: flex;
        align-items: center;
        gap: 6px;
        font-weight: 600;
      }

      .bw-status-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #4ade80;
        box-shadow: 0 0 6px #4ade80;
      }

      .bw-header-actions {
        display: flex;
        align-items: center;
        gap: 8px;
      }

      .bw-icon-btn {
        background: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: #ffffff;
        width: 32px;
        height: 32px;
        border-radius: 8px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 0.95rem;
        transition: all 0.2s;
      }

      .bw-icon-btn:hover {
        background: #FFA500;
        color: #1a1a2e;
      }

      .bw-source-strip {
        background: rgba(0, 0, 0, 0.45);
        padding: 6px 14px;
        font-size: 0.72rem;
        color: #cbd5e1;
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-bottom: 1px solid rgba(255, 255, 255, 0.08);
      }

      .bw-source-strip strong {
        color: #FFA500;
      }

      .bw-chat-messages {
        flex: 1;
        overflow-y: auto;
        padding: 16px;
        display: flex;
        flex-direction: column;
        gap: 14px;
        background: #0f1527;
        scroll-behavior: smooth;
      }

      .bw-chat-messages::-webkit-scrollbar {
        width: 6px;
      }
      .bw-chat-messages::-webkit-scrollbar-thumb {
        background: rgba(255, 165, 0, 0.4);
        border-radius: 4px;
      }

      .bw-msg {
        max-width: 90%;
        padding: 14px 16px;
        border-radius: 14px;
        font-size: 0.88rem;
        line-height: 1.55;
        word-break: break-word;
      }

      .bw-msg-bot {
        align-self: flex-start;
        background: #1e293b;
        border: 1px solid rgba(255, 165, 0, 0.25);
        color: #ffffff;
        border-bottom-left-radius: 4px;
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.35);
      }

      .bw-msg-bot strong {
        color: #f9c74f;
      }

      .bw-msg-bot a {
        color: #FFA500;
        text-decoration: underline;
        font-weight: 700;
      }

      .bw-msg-user {
        align-self: flex-end;
        background: linear-gradient(135deg, #FFA500, #ff8c00);
        color: #1a1a2e;
        font-weight: 700;
        border-bottom-right-radius: 4px;
        box-shadow: 0 4px 14px rgba(255, 165, 0, 0.3);
      }

      .bw-sources-list {
        margin-top: 10px;
        padding-top: 8px;
        border-top: 1px solid rgba(255, 255, 255, 0.14);
        font-size: 0.76rem;
      }

      .bw-sources-list a {
        display: inline-block;
        margin: 3px 6px 0 0;
        padding: 3px 8px;
        border-radius: 6px;
        background: rgba(255, 165, 0, 0.14);
        border: 1px solid rgba(255, 165, 0, 0.4);
        color: #f9c74f !important;
        text-decoration: none !important;
        font-size: 0.72rem;
      }

      .bw-typing {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 10px 16px;
        background: #1e293b;
        border-radius: 12px;
        align-self: flex-start;
        border: 1px solid rgba(255, 165, 0, 0.3);
        color: #f9c74f;
        font-size: 0.8rem;
        font-weight: 700;
      }

      .bw-typing span {
        width: 7px;
        height: 7px;
        border-radius: 50%;
        background: #FFA500;
        animation: bwTyping 1.4s infinite ease-in-out both;
      }
      .bw-typing span:nth-child(1) { animation-delay: -0.32s; }
      .bw-typing span:nth-child(2) { animation-delay: -0.16s; }

      @keyframes bwTyping {
        0%, 100% { transform: translateY(0); opacity: 0.3; }
        50% { transform: translateY(-5px); opacity: 1; }
      }

      .bw-quick-prompts {
        padding: 10px 14px;
        display: flex;
        gap: 8px;
        overflow-x: auto;
        white-space: nowrap;
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        background: #0b1120;
      }

      .bw-quick-prompts::-webkit-scrollbar {
        display: none;
      }

      .bw-chip {
        background: rgba(255, 165, 0, 0.12);
        color: #f9c74f;
        border: 1px solid #FFA500;
        border-radius: 20px;
        padding: 6px 14px;
        font-size: 0.76rem;
        font-weight: 700;
        cursor: pointer;
        transition: all 0.2s ease;
        flex-shrink: 0;
      }

      .bw-chip:hover {
        background: #FFA500;
        color: #1a1a2e;
        transform: translateY(-1px);
      }

      .bw-chat-input-area {
        padding: 12px 14px;
        background: #0f172a;
        display: flex;
        align-items: center;
        gap: 8px;
        border-top: 2px solid rgba(255, 165, 0, 0.25);
      }

      .bw-chat-input {
        flex: 1;
        background: rgba(255, 255, 255, 0.08);
        border: 1.5px solid rgba(255, 165, 0, 0.4);
        color: #ffffff;
        padding: 11px 16px;
        border-radius: 24px;
        font-size: 0.9rem;
        outline: none;
        transition: border-color 0.2s;
      }

      .bw-chat-input:focus {
        border-color: #FFA500;
        box-shadow: 0 0 10px rgba(255, 165, 0, 0.3);
      }

      .bw-send-btn {
        width: 42px;
        height: 42px;
        border-radius: 50%;
        background: #FFA500;
        color: #1a1a2e;
        border: none;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: transform 0.2s;
        font-size: 1.05rem;
        flex-shrink: 0;
        font-weight: 800;
      }

      .bw-send-btn:hover {
        transform: scale(1.08);
        background: #ffb733;
      }

      .bw-disclaimer {
        text-align: center;
        font-size: 0.7rem;
        color: #94a3b8;
        padding: 5px 10px 8px 10px;
        background: #0f172a;
        border-top: 1px solid rgba(255, 255, 255, 0.05);
      }

      .bw-disclaimer strong {
        color: #4ade80;
      }

      @media (max-width: 640px) {
        #bw-ai-bot-root {
          bottom: 16px;
          right: 16px;
        }

        .bw-bot-launcher {
          padding: 10px 18px;
          font-size: 0.88rem;
        }

        .bw-chat-window {
          bottom: 0 !important;
          right: 0 !important;
          left: 0 !important;
          width: 100vw !important;
          max-width: 100vw !important;
          height: 88vh !important;
          max-height: 88vh !important;
          border-radius: 20px 20px 0 0 !important;
          border-left: none !important;
          border-right: none !important;
          border-bottom: none !important;
        }
      }
    `;
    document.head.appendChild(style);
  }

  function createWidget() {
    if (document.getElementById('bw-ai-bot-root')) return;
    if (!document.body) return;

    const root = document.createElement('div');
    root.id = 'bw-ai-bot-root';

    root.innerHTML = `
      <button class="bw-bot-launcher" id="bwBotLauncher" aria-label="Open Wealth AI Assistant" title="Ask BillionaireWatch AI">
        <i class="fas fa-crown"></i>
        <span>Ask Wealth AI</span>
        <div class="bw-pulse-dot"></div>
      </button>

      <div class="bw-chat-window" id="bwChatWindow" role="dialog" aria-modal="true" aria-label="BillionaireWatch AI Assistant">
        <div class="bw-chat-header">
          <div class="bw-header-info">
            <div class="bw-bot-avatar"><i class="fas fa-robot"></i></div>
            <div>
              <h3 class="bw-header-title">${BOT_TITLE}</h3>
              <div class="bw-header-status">
                <span class="bw-status-dot"></span>
                <span>SEC EDGAR &bull; BSE/NSE &bull; Market Quotes</span>
              </div>
            </div>
          </div>
          <div class="bw-header-actions">
            <button class="bw-icon-btn" id="bwClearChatBtn" title="Clear conversation"><i class="fas fa-trash-alt"></i></button>
            <button class="bw-icon-btn" id="bwCloseChatBtn" title="Close"><i class="fas fa-times"></i></button>
          </div>
        </div>

        <div class="bw-source-strip">
          <span><i class="fas fa-landmark" style="color:#4ade80;"></i> Sources: <strong>SEC Filings</strong> &bull; <strong>BSE/NSE</strong> &bull; <strong>Public Quotes</strong></span>
          <span id="bwBotForexBadge">1 USD = ₹${getActiveFxRate().toFixed(2)}</span>
        </div>

        <div class="bw-chat-messages" id="bwChatMessages">
          <div class="bw-msg bw-msg-bot">
            👋 <strong>Welcome to BillionaireWatch Wealth Intelligence!</strong><br><br>
            I analyze disclosed shareholdings from <strong>SEC EDGAR</strong> and Indian <strong>BSE/NSE promoter filings</strong> with dynamic USD/INR conversions (1 USD = ₹${getActiveFxRate().toFixed(2)} INR).<br><br>
            Ask about Elon Musk's SpaceX/Tesla holdings, Top 10 Global or India rankings in ₹ Crores, or how public equity and vested option spreads are calculated!
          </div>
        </div>

        <div class="bw-quick-prompts" id="bwQuickPrompts">
          <button class="bw-chip" data-prompt="Break down Elon Musk net worth across Tesla, SpaceX shares and vested options">👑 Elon: Equity Breakdown</button>
          <button class="bw-chip" data-prompt="What is Mukesh Ambani and Gautam Adani net worth and Global Rank?">🇮🇳 Ambani vs Adani (₹ Cr)</button>
          <button class="bw-chip" data-prompt="Show Top 10 World Billionaires with exact net worth and Global Rank">📊 Top 10 Rankings</button>
          <button class="bw-chip" data-prompt="Explain how vested options and SEC filings affect billionaire net worth">⚡ Options &amp; Filings Math</button>
          <button class="bw-chip" data-prompt="How do billionaires minimize taxes using Buy Borrow Die?">🏛️ Tax Strategies</button>
        </div>

        <form class="bw-chat-input-area" id="bwChatForm">
          <input type="text" class="bw-chat-input" id="bwChatInput" placeholder="Ask: 'Elon Musk SEC equity breakdown'..." autocomplete="off">
          <button type="submit" class="bw-send-btn" id="bwSendBtn" aria-label="Send message">
            <i class="fas fa-paper-plane"></i>
          </button>
        </form>

        <div class="bw-disclaimer">
          ⚡ <strong>Independent Estimates</strong> &bull; SEC EDGAR &bull; BSE/NSE &bull; FX Synced
        </div>
      </div>
    `;

    document.body.appendChild(root);
    setupEvents();
  }

  function setupEvents() {
    const launcher = document.getElementById('bwBotLauncher');
    const chatWindow = document.getElementById('bwChatWindow');
    const closeBtn = document.getElementById('bwCloseChatBtn');
    const clearBtn = document.getElementById('bwClearChatBtn');
    const form = document.getElementById('bwChatForm');
    const input = document.getElementById('bwChatInput');
    const chipsContainer = document.getElementById('bwQuickPrompts');

    if (!launcher || !chatWindow) return;

    launcher.addEventListener('click', () => {
      chatWindow.classList.toggle('open');
      if (chatWindow.classList.contains('open')) {
        updateForexBadge();
        setTimeout(() => input?.focus(), 150);
      }
    });

    closeBtn?.addEventListener('click', () => {
      chatWindow.classList.remove('open');
    });

    clearBtn?.addEventListener('click', () => {
      const messagesContainer = document.getElementById('bwChatMessages');
      if (messagesContainer) {
        messagesContainer.innerHTML = `
          <div class="bw-msg bw-msg-bot">
            👋 Conversation cleared. Ask any question about net worth methodology, SEC/BSE public disclosures, or ₹ Crores conversions!
          </div>
        `;
      }
      sessionStorage.removeItem(STORAGE_SESSION_KEY);
    });

    chipsContainer?.addEventListener('click', (e) => {
      const chip = e.target.closest('.bw-chip');
      if (chip && input) {
        const prompt = chip.getAttribute('data-prompt');
        input.value = '';
        sendMessage(prompt);
      }
    });

    form?.addEventListener('submit', (e) => {
      e.preventDefault();
      if (!input) return;
      const text = input.value.trim();
      if (!text) return;
      sendMessage(text);
      input.value = '';
    });

    document.addEventListener('click', (e) => {
      const trigger = e.target.closest('.open-wealth-ai, [data-open-bot], #ask-wealth-ai-btn, .ask-ai-btn');
      if (trigger) {
        e.preventDefault();
        chatWindow.classList.add('open');
        updateForexBadge();
        setTimeout(() => input?.focus(), 150);
      }
    });

    window.addEventListener('bw-data-updated', () => {
      updateForexBadge();
    });
  }

  function updateForexBadge() {
    const badge = document.getElementById('bwBotForexBadge');
    if (badge) {
      badge.textContent = `1 USD = ₹${getActiveFxRate().toFixed(2)}`;
    }
  }

  function appendMessage(text, sender, sources = []) {
    const messagesContainer = document.getElementById('bwChatMessages');
    if (!messagesContainer) return;
    const msg = document.createElement('div');
    msg.className = `bw-msg bw-msg-${sender}`;
    let html = formatMarkdown(text);

    if (sender === 'bot' && Array.isArray(sources) && sources.length > 0) {
      const uniqueSources = sources.slice(0, 4);
      html += `<div class="bw-sources-list"><strong>Verified Web Sources:</strong><br>` +
        uniqueSources.map(s => `<a href="${s.url}" target="_blank" rel="noopener noreferrer"><i class="fas fa-external-link-alt"></i> ${escapeHtml(s.title || 'Source')}</a>`).join('') +
        `</div>`;
    }

    msg.innerHTML = html;
    messagesContainer.appendChild(msg);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }

  function escapeHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function showTypingIndicator() {
    const messagesContainer = document.getElementById('bwChatMessages');
    if (!messagesContainer) return;
    removeTypingIndicator();
    const typing = document.createElement('div');
    typing.id = 'bwTypingIndicator';
    typing.className = 'bw-typing';
    typing.innerHTML = `
      <i class="fas fa-search fa-spin" style="margin-right: 4px;"></i>
      <span>Checking SEC, BSE/NSE &amp; Market Data...</span>
      <span></span><span></span>
    `;
    messagesContainer.appendChild(typing);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }

  function removeTypingIndicator() {
    const indicators = document.querySelectorAll('#bwTypingIndicator, .bw-typing');
    indicators.forEach(el => el.remove());
  }

  function formatMarkdown(str) {
    return String(str || '')
      .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+|\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>')
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/\n\n/g, '<br><br>')
      .replace(/\n- /g, '<br>• ')
      .replace(/\n/g, '<br>');
  }

  async function sendMessage(question) {
    if (!question || !question.trim()) return;
    const cleanQ = question.trim();
    appendMessage(cleanQ, 'user');
    showTypingIndicator();

    try {
      // Query server-side Gemini + Google Search + Live Forbes endpoint first
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 12000);
      const resp = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: cleanQ }),
        signal: controller.signal
      });
      clearTimeout(timeoutId);

      if (resp.ok) {
        const data = await resp.json();
        if (data && data.reply) {
          removeTypingIndicator();
          appendMessage(data.reply, 'bot', data.sources || []);
          return;
        }
      }
    } catch (err) {
      // Fall through cleanly to live-hydrated local engine
    }

    // Fallback: use hydrated BillionaireWatchData (SEC/BSE disclosures + FX)
    try {
      const answer = generateGroundedWealthResponse(cleanQ);
      removeTypingIndicator();
      appendMessage(answer, 'bot', [
        { title: 'SEC EDGAR Company Filings', url: 'https://www.sec.gov/edgar/searchedgar/companysearch' },
        { title: 'BillionaireWatch Methodology', url: '/about.html#methodology' }
      ]);
    } catch (err) {
      removeTypingIndicator();
      const pool = getLiveAllPool();
      const top = pool[0];
      const rate = getActiveFxRate();
      const worth = Number(top?.netWorth ?? top?.netWorthUsd ?? 894.3);
      const inrCr = Math.round(worth * rate * 100);
      appendMessage(`✓ **Disclosures Snapshot:** #1 **${top?.name || 'Elon Musk'}** holds **$${worth.toFixed(1)}B USD** (≈ ${formatLakhCr(inrCr)}) at **1 USD = ₹${rate.toFixed(2)}**.`, 'bot');
    }
  }

  // Grounded Filings & Disclosures Answer Engine
  function generateGroundedWealthResponse(query) {
    const q = query.toLowerCase();
    const rate = getActiveFxRate();
    const pool = getLiveAllPool();

    // 1. Methodology & Options Disclosures Math
    if (q.includes('difference') || q.includes('methodology') || q.includes('options') || q.includes('filings') || (q.includes('forbes') && q.includes('bloomberg') && !q.includes('musk') && !q.includes('ambani') && !q.includes('adani'))) {
      return `📊 **How SEC Disclosures & Public Exchange Quotes Calculate Billionaire Net Worth:**\n\n` +
        `1. **Public Equity (SEC Form 4 / BSE-NSE Filings):**\n` +
        `   • Multiplies verified common shareholdings (e.g., TSLA, AMZN, GOOGL, RELIANCE.NS) by public exchange closing stock prices.\n` +
        `2. **Vested Performance Options Spread:**\n` +
        `   • Includes in-the-money vested stock options using **(Market Share Price − Option Strike Price) × Vested Options**.\n` +
        `3. **Private Enterprise Benchmarks:**\n` +
        `   • Private companies (such as SpaceX, Blue Origin, or xAI) are valued via institutional tender-offer benchmarks and secondary financing rounds, reconciled independently of proprietary third-party lists.\n\n` +
        `💱 **Active FX Benchmark:** **1 USD = ₹${rate.toFixed(2)} INR**.`;
    }

    // 2. Spend Elon's $1T Game
    if (q.includes('game') || q.includes('spend') || q.includes('receipt') || q.includes('neal.fun') || q.includes('1 trillion')) {
      return `🎮 **Spend Elon Musk's $1 Trillion Simulator:**\n\n` +
        `• **Starting Balance:** **$1,000,000,000,000 USD** (≈ **₹${(1000 * rate / 10).toFixed(2)} Lakh Crore** at live ₹${rate}/$ FX rate).\n` +
        `• **Items Included:** Big Macs, Artisan Coffee, iPhone 16 Pro Max, SpaceX Falcon 9 launches, NBA teams, and Mars City Alpha.\n\n` +
        `👉 **[Open Spend Elon's $1T Game](/live-site/spend-elon-money.html)**`;
    }

    // 3. Tax Minimization / Buy Borrow Die
    if (q.includes('tax') || q.includes('escape') || q.includes('avoid') || q.includes('loophole') || q.includes('buy borrow die')) {
      return `🏛️ **How Billionaires Legally Minimize Taxes (Buy, Borrow, Die):**\n\n` +
        `1. **Buy / Build:** Unrealized equity appreciation triggers **$0 capital gains tax** while shares remain unsold.\n` +
        `2. **Borrow:** Founders pledge equity for **Securities-Backed Lines of Credit (SBLOCs)** since loan proceeds are tax-free.\n` +
        `3. **Die:** Heirs receive a **stepped-up cost basis** at fair market value, permanently erasing unrealized historical gains.\n` +
        `4. **Zero / $1 Salary & DAFs:** Executive pay is structured in long-term equity awards alongside Donor-Advised Fund deductions.`;
    }

    // 4. India Comparison / Rankings
    if ((q.includes('ambani') && q.includes('adani')) || (q.includes('india') && (q.includes('top') || q.includes('richest') || q.includes('rank')))) {
      const indiaList = pool.filter(b => b.country === 'IN').slice(0, 5);
      if (indiaList.length > 0) {
        let res = `🇮🇳 **Top Indian Billionaires (BSE/NSE Filings & FX Sync):**\n\n`;
        indiaList.forEach((b, idx) => {
          const worth = Number(b.netWorth ?? b.netWorthUsd ?? 0);
          const inrCr = Math.round(worth * rate * 100);
          res += `${idx + 1}. **${b.name}** (${b.source || 'Diversified'})\n` +
            `   • **Net Worth:** **$${worth.toFixed(1)}B USD** (≈ ${formatLakhCr(inrCr)})\n` +
            `   • **Global Rank:** #${b.globalRank || '?'} worldwide\n\n`;
        });
        res += `*Reference Forex Rate Applied: 1 USD = ₹${rate.toFixed(2)} INR.*`;
        return res;
      }
    }

    // 5. Global Top 10 Live Summary
    if (q.includes('top 10') || q.includes('rankings') || q.includes('who is the richest') || q.includes('who is richest') || q.includes('richest person')) {
      const topList = pool.slice(0, 10);
      let res = `👑 **Global Top 10 Billionaires (Strictly Sorted Descending by Net Worth):**\n\n`;
      topList.forEach((b, idx) => {
        const worth = Number(b.netWorth ?? b.netWorthUsd ?? 0);
        const inrCr = Math.round(worth * rate * 100);
        const gRank = b.globalRank || (idx + 1);
        res += `**#${gRank} ${b.name}** — **$${worth.toFixed(1)}B USD** (≈ ${formatLakhCr(inrCr)})\n` +
          `   • *Source:* ${b.source || b.company}\n`;
      });
      res += `\n⚡ *Synced at 1 USD = ₹${rate.toFixed(2)} INR from SEC, BSE/NSE & Open Market APIs.*`;
      return res;
    }

    // 6. Match ANY billionaire across full live dataset (top 150 tracked)
    const cleanTerms = q.replace(/[^a-z\s]/g, ' ').split(/\s+/).filter(w => w.length > 2 && !['net', 'worth', 'forbes', 'bloomberg', 'compare', 'what', 'rank', 'the', 'and', 'live', 'how', 'much', 'money', 'usd', 'inr', 'crores'].includes(w));
    let matchedPerson = null;

    if (cleanTerms.length > 0) {
      matchedPerson = pool.find(b => {
        const fullName = String(b.name || '').toLowerCase();
        return cleanTerms.every(term => fullName.includes(term));
      }) || pool.find(b => {
        const fullName = String(b.name || '').toLowerCase();
        return cleanTerms.some(term => term.length >= 4 && fullName.includes(term));
      });
    }

    if (matchedPerson) {
      const worth = Number(matchedPerson.netWorth ?? matchedPerson.netWorthUsd ?? 0);
      const inrCr = Math.round(worth * rate * 100);
      const gRank = matchedPerson.globalRank || (pool.findIndex(x => x.id === matchedPerson.id) + 1);
      const pubEq = matchedPerson.publicEquityUsd !== undefined ? `$${Number(matchedPerson.publicEquityUsd).toFixed(1)}B` : 'Tracked via public filings';
      const optEq = matchedPerson.vestedOptionsUsd !== undefined ? `$${Number(matchedPerson.vestedOptionsUsd).toFixed(1)}B` : '$0.0B';
      const privEq = matchedPerson.privateAssetsUsd !== undefined ? `$${Number(matchedPerson.privateAssetsUsd).toFixed(1)}B` : 'Private stakes';

      let disclosuresSnippet = '';
      if (Array.isArray(matchedPerson.disclosures) && matchedPerson.disclosures.length > 0) {
        disclosuresSnippet = `\n\n📋 **Key Disclosed Equity & Option Positions:**\n` +
          matchedPerson.disclosures.slice(0, 4).map(d =>
            `• **${d.companyName}** (${d.ticker || 'Private'}): **$${Number(d.valueBillions).toFixed(1)}B**` +
            (d.isOption ? ` *(Options Spread: $${d.priceUsd} − $${d.exerciseOptionPriceUsd} strike)*` : ` *(Live price $${d.priceUsd}/sh)*`)
          ).join('\n');
      }

      const profileNote = matchedPerson.hasDedicatedProfile
        ? `\n\n👉 Full timeline & breakdown on their **[Profile Page](/live-site/profiles/${matchedPerson.id}.html)**.`
        : '';

      return `🔍 **${matchedPerson.name} Live Net Worth & Disclosures Breakdown:**\n\n` +
        `• **Live Valuation:** **$${worth.toFixed(1)} Billion USD**\n` +
        `  └ **Indian Rupee Equivalent:** **${formatLakhCr(inrCr)}** (@ ₹${rate.toFixed(2)}/$)\n` +
        `• **Verified Global Rank:** **#${gRank} Worldwide**\n` +
        `• **Primary Sources:** ${matchedPerson.source || matchedPerson.company}\n` +
        `• **Valuation Composition:** Public Equity **${pubEq}** &bull; Vested Options **${optEq}** &bull; Private Assets **${privEq}**` +
        disclosuresSnippet +
        profileNote;
    }

    // 7. General Search Guidance with current #1 summary
    const leader = pool[0];
    const leaderWorth = Number(leader?.netWorth ?? leader?.netWorthUsd ?? 894.3);
    const leaderInr = Math.round(leaderWorth * rate * 100);

    return `💡 **BillionaireWatch Live Search Results for "${query}":**\n\n` +
      `Currently, **#${leader?.globalRank || 1} ${leader?.name || 'Elon Musk'}** leads the global rankings at **$${leaderWorth.toFixed(1)}B USD** (${formatLakhCr(leaderInr)}) at **1 USD = ₹${rate.toFixed(2)}**.\n\n` +
      `Try asking me:\n` +
      `• **"Elon Musk net worth Forbes vs Bloomberg"**\n` +
      `• **"Show Top 10 rankings with exact Global Ranks"**\n` +
      `• **"Compare Mukesh Ambani and Gautam Adani"**\n` +
      `• **"Michael Dell net worth and holdings"**\n` +
      `• **"Explain vested options and filings methodology"**`;
  }

  function init() {
    injectStyles();
    createWidget();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  window.BillionaireWatchBot = {
    open: () => {
      const chatWindow = document.getElementById('bwChatWindow');
      if (chatWindow) chatWindow.classList.add('open');
      updateForexBadge();
      const input = document.getElementById('bwChatInput');
      if (input) setTimeout(() => input.focus(), 150);
    },
    close: () => {
      const chatWindow = document.getElementById('bwChatWindow');
      if (chatWindow) chatWindow.classList.remove('open');
    },
    ask: (question) => {
      const chatWindow = document.getElementById('bwChatWindow');
      if (chatWindow) chatWindow.classList.add('open');
      updateForexBadge();
      const input = document.getElementById('bwChatInput');
      if (input) input.value = '';
      sendMessage(question);
    }
  };
})();
