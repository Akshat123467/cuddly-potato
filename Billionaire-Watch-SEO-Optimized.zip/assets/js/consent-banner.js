/**
 * BillionaireWatch.in - GDPR / UK PECR & Google AdSense Cookie Consent Banner
 * Implements Google Consent Mode v2 defaults & user preference management.
 */
(function() {
  'use strict';

  const CONSENT_KEY = 'bw_cookie_consent_v1';

  window.dataLayer = window.dataLayer || [];
  function gtag() {
    window.dataLayer.push(arguments);
  }

  function applyConsentState(state) {
    const adConsent = state && state.ads ? 'granted' : 'denied';
    const analyticsConsent = state && state.analytics ? 'granted' : 'denied';

    try {
      gtag('consent', 'update', {
        ad_storage: adConsent,
        ad_user_data: adConsent,
        ad_personalization: adConsent,
        analytics_storage: analyticsConsent
      });
    } catch (e) {}

    window.adsbygoogle = window.adsbygoogle || [];
    window.adsbygoogle.requestNonPersonalizedAds = state && state.ads ? 0 : 1;
  }

  function getSavedConsent() {
    try {
      const raw = localStorage.getItem(CONSENT_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e) {
      return null;
    }
  }

  function saveConsent(prefs) {
    const payload = {
      essential: true,
      analytics: Boolean(prefs.analytics),
      ads: Boolean(prefs.ads),
      updatedAt: new Date().toISOString()
    };
    try {
      localStorage.setItem(CONSENT_KEY, JSON.stringify(payload));
    } catch (e) {}
    applyConsentState(payload);
    return payload;
  }

  // Initialize default denied signals before personalized tags trigger
  const existing = getSavedConsent();
  if (existing) {
    applyConsentState(existing);
  } else {
    try {
      gtag('consent', 'default', {
        ad_storage: 'denied',
        ad_user_data: 'denied',
        ad_personalization: 'denied',
        analytics_storage: 'denied',
        wait_for_update: 500
      });
    } catch (e) {}
    window.adsbygoogle = window.adsbygoogle || [];
    window.adsbygoogle.requestNonPersonalizedAds = 1;
  }

  function removeBanner() {
    const el = document.getElementById('bw-consent-banner');
    if (el) el.remove();
  }

  function getPrivacyHref() {
    const path = window.location.pathname || '';
    if (path.includes('/profiles/') || path.includes('/insights/') || path.includes('/tools/')) {
      return '../privacy-policy.html';
    }
    return 'privacy-policy.html';
  }

  function showConsentBanner(forceManage) {
    if (!forceManage && getSavedConsent()) return;
    if (document.getElementById('bw-consent-banner')) return;

    const current = getSavedConsent() || { analytics: false, ads: false };
    const privacyUrl = getPrivacyHref();

    const banner = document.createElement('aside');
    banner.id = 'bw-consent-banner';
    banner.setAttribute('role', 'dialog');
    banner.setAttribute('aria-label', 'Cookie and Advertising Consent');
    banner.style.cssText = [
      'position: fixed',
      'left: 16px',
      'right: 16px',
      'bottom: 16px',
      'z-index: 9999',
      'max-width: 980px',
      'margin: 0 auto',
      'background: #16213e',
      'color: #f8fafc',
      'border: 1.5px solid #f9c74f',
      'border-radius: 12px',
      'padding: 18px 22px',
      'box-shadow: 0 14px 40px rgba(0,0,0,0.65)',
      'font-family: system-ui, -apple-system, sans-serif',
      'font-size: 0.9rem',
      'line-height: 1.5'
    ].join(';');

    banner.innerHTML = `
      <div style="display:flex; flex-wrap:wrap; align-items:flex-start; justify-content:space-between; gap:16px;">
        <div style="flex:1 1 420px;">
          <strong style="display:block; color:#f9c74f; font-size:1rem; margin-bottom:6px;">Cookie &amp; Privacy Preferences (EU / UK GDPR &amp; AdSense)</strong>
          <p style="margin:0 0 8px 0; color:#e2e8f0 !important;">
            BillionaireWatch.in uses essential local storage (theme &amp; currency settings) plus optional analytics and Google AdSense advertising cookies. Visitors in the EEA and UK can choose non-personalized ads or customize settings anytime. See our
            <a href="${privacyUrl}" style="color:#f9c74f !important; text-decoration:underline; font-weight:600;">Privacy Policy</a>.
          </p>
          <div id="bw-consent-details" style="display:${forceManage ? 'block' : 'none'}; margin-top:10px; padding:10px 12px; background:rgba(15,15,26,0.6); border-radius:8px; border:1px solid rgba(255,255,255,0.12);">
            <label style="display:flex; align-items:center; gap:8px; margin-bottom:6px; color:#cbd5e1; cursor:not-allowed;">
              <input type="checkbox" checked disabled> <span><strong>Essential Storage</strong> (Required for currency toggle &amp; theme)</span>
            </label>
            <label style="display:flex; align-items:center; gap:8px; margin-bottom:6px; color:#f8fafc; cursor:pointer;">
              <input type="checkbox" id="bw-opt-analytics" ${current.analytics ? 'checked' : ''}> <span><strong>Analytics Cookies</strong> (Aggregated readership metrics)</span>
            </label>
            <label style="display:flex; align-items:center; gap:8px; color:#f8fafc; cursor:pointer;">
              <input type="checkbox" id="bw-opt-ads" ${current.ads ? 'checked' : ''}> <span><strong>Personalized Advertising (Google AdSense)</strong> (Uncheck for non-personalized ads)</span>
            </label>
          </div>
        </div>
        <div style="display:flex; flex-wrap:wrap; gap:8px; align-items:center; justify-content:flex-end;">
          <button type="button" id="bw-consent-manage" style="background:transparent; color:#f9c74f; border:1px solid rgba(249,199,79,0.5); padding:9px 14px; border-radius:8px; font-weight:600; cursor:pointer;">
            ${forceManage ? 'Save Choices' : 'Manage Preferences'}
          </button>
          <button type="button" id="bw-consent-reject" style="background:#1a1a2e; color:#ffffff; border:1px solid rgba(255,255,255,0.35); padding:9px 14px; border-radius:8px; font-weight:600; cursor:pointer;">
            Essential Only
          </button>
          <button type="button" id="bw-consent-accept" style="background:#f9c74f; color:#1a1a2e; border:none; padding:9px 18px; border-radius:8px; font-weight:800; cursor:pointer;">
            Accept All
          </button>
        </div>
      </div>
    `;

    document.body.appendChild(banner);

    const detailsEl = document.getElementById('bw-consent-details');
    const manageBtn = document.getElementById('bw-consent-manage');
    const rejectBtn = document.getElementById('bw-consent-reject');
    const acceptBtn = document.getElementById('bw-consent-accept');

    let detailsOpen = Boolean(forceManage);

    manageBtn.addEventListener('click', function() {
      if (!detailsOpen) {
        detailsEl.style.display = 'block';
        manageBtn.textContent = 'Save Choices';
        detailsOpen = true;
      } else {
        const analytics = Boolean(document.getElementById('bw-opt-analytics')?.checked);
        const ads = Boolean(document.getElementById('bw-opt-ads')?.checked);
        saveConsent({ analytics, ads });
        removeBanner();
      }
    });

    rejectBtn.addEventListener('click', function() {
      saveConsent({ analytics: false, ads: false });
      removeBanner();
    });

    acceptBtn.addEventListener('click', function() {
      saveConsent({ analytics: true, ads: true });
      removeBanner();
    });
  }

  window.BillionaireConsent = {
    openPreferences: function() {
      removeBanner();
      showConsentBanner(true);
    },
    getState: getSavedConsent
  };

  function scheduleConsentBanner() {
    if (typeof window.requestIdleCallback === 'function') {
      window.requestIdleCallback(function() { showConsentBanner(false); }, { timeout: 1500 });
    } else {
      setTimeout(function() { showConsentBanner(false); }, 600);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', scheduleConsentBanner);
  } else {
    scheduleConsentBanner();
  }
})();
