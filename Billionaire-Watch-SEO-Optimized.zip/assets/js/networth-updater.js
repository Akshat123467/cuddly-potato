/**
 * BillionaireWatch.in - Cached Filings, Public Market & Currency Exchange Engine
 *
 * Features:
 * 1. Static-first cached data/billionaires.json hydration (populated by scheduled GitHub Actions / Netlify cron).
 * 2. Live USD/INR Currency Exchange Rate Auto-Fetcher (94.29 fallback + open.er-api.com FX API).
 * 3. Strict Mathematical Sorting & 1-Based Global Rank Engine.
 * 4. Dual-Currency Support (USD $ and INR ₹ Crores / Lakh Crores) with view switcher.
 * 5. Automatic synchronization across home grids, Quick Preview Modal, and 17 profile pages.
 */
(function() {
  'use strict';

  const STORAGE_KEY = 'bw_networth_data_v6';
  const FX_STORAGE_KEY = 'bw_forex_rate_v2';
  const DEFAULT_USD_TO_INR_RATE = 94.29;

  // Authoritative Baseline Snapshot (SEC EDGAR Form 4 / 13D & BSE/NSE Promoter Disclosures)
  const MASTER_BILLIONAIRES = [
    {
      id: "elon-musk",
      name: "Elon Musk",
      country: "US",
      countryName: "United States",
      netWorthUsd: 891.4,
      publicEquityUsd: 154.4,
      vestedOptionsUsd: 46.0,
      privateAssetsUsd: 691.0,
      dailyChange: 8.93,
      source: "Tesla, SpaceX, xAI",
      age: 55,
      hasDedicatedProfile: true,
      image: "images/avatars/elon-musk.jpg",
      bio: "World's richest individual leading electric mobility with Tesla, orbital launch & Starlink with SpaceX, and frontier intelligence with xAI. Valuation reflects common equity, vested SpaceX performance options, and private holdings.",
      disclosures: [
        { companyName: "SpaceX (Common Stock)", ticker: "PRIVATE-SPACEX", shares: 4766400000, priceUsd: 139.94, exerciseOptionPriceUsd: null, isOption: false, valueBillions: 667.0 },
        { companyName: "Tesla, Inc. (Common Stock)", ticker: "TSLA", shares: 395620000, priceUsd: 390.16, exerciseOptionPriceUsd: null, isOption: false, valueBillions: 154.36 },
        { companyName: "SpaceX (Vested Options)", ticker: "PRIVATE-SPACEX-OPT", shares: 350000000, priceUsd: 139.94, exerciseOptionPriceUsd: 8.40, isOption: true, valueBillions: 46.0 }
      ]
    },
    {
      id: "jeff-bezos",
      name: "Jeff Bezos",
      country: "US",
      countryName: "United States",
      netWorthUsd: 406.6,
      publicEquityUsd: 242.7,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 163.9,
      dailyChange: 2.84,
      source: "Amazon, Blue Origin",
      age: 62,
      hasDedicatedProfile: true,
      image: "images/avatars/jeff-bezos.jpg",
      bio: "Founder of Amazon and aerospace pioneer Blue Origin, holding extensive public Amazon equity alongside private aerospace, media, and capital ventures."
    },
    {
      id: "michael-dell",
      name: "Michael Dell",
      country: "US",
      countryName: "United States",
      netWorthUsd: 364.3,
      publicEquityUsd: 337.5,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 26.8,
      dailyChange: 13.62,
      source: "Dell Technologies, Broadcom",
      age: 61,
      hasDedicatedProfile: true,
      image: "images/avatars/michael-dell.jpg",
      bio: "Chairman and CEO of Dell Technologies, whose fortune surged alongside AI server infrastructure demand and strategic Broadcom equity stakes."
    },
    {
      id: "larry-page",
      name: "Larry Page",
      country: "US",
      countryName: "United States",
      netWorthUsd: 233.0,
      publicEquityUsd: 227.2,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 5.8,
      dailyChange: 3.86,
      source: "Google / Alphabet",
      age: 53,
      hasDedicatedProfile: true,
      image: "images/avatars/larry-page.jpg",
      bio: "Co-founder of Google and Alphabet controlling shareholder, capitalizing on breakthroughs in generative AI, cloud computing, and Waymo."
    },
    {
      id: "mark-zuckerberg",
      name: "Mark Zuckerberg",
      country: "US",
      countryName: "United States",
      netWorthUsd: 224.9,
      publicEquityUsd: 221.4,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 3.5,
      dailyChange: 5.17,
      source: "Meta Platforms",
      age: 42,
      hasDedicatedProfile: true,
      image: "images/avatars/mark-zuckerberg.jpg",
      bio: "Co-founder and CEO of Meta Platforms, driving global social networks, open-source Llama AI intelligence, and wearable computing."
    },
    {
      id: "sergey-brin",
      name: "Sergey Brin",
      country: "US",
      countryName: "United States",
      netWorthUsd: 214.5,
      publicEquityUsd: 208.8,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 5.7,
      dailyChange: 3.86,
      source: "Google / Alphabet",
      age: 53,
      hasDedicatedProfile: true,
      image: "images/avatars/sergey-brin.jpg",
      bio: "Google co-founder actively contributing to next-generation AI foundation models and quantum computing ventures."
    },
    {
      id: "warren-buffett",
      name: "Warren Buffett",
      country: "US",
      countryName: "United States",
      netWorthUsd: 186.5,
      publicEquityUsd: 185.0,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 1.5,
      dailyChange: 3.87,
      source: "Berkshire Hathaway",
      age: 96,
      hasDedicatedProfile: true,
      image: "images/avatars/warren-buffett.jpg",
      bio: "The 'Oracle of Omaha' and leader of Berkshire Hathaway, renowned for disciplined capital allocation and compounding value."
    },
    {
      id: "steve-ballmer",
      name: "Steve Ballmer",
      country: "US",
      countryName: "United States",
      netWorthUsd: 183.0,
      publicEquityUsd: 174.5,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 8.5,
      dailyChange: -1.27,
      source: "Microsoft, LA Clippers",
      age: 70,
      hasDedicatedProfile: true,
      image: "images/avatars/steve-ballmer.jpg",
      bio: "Former Microsoft CEO and owner of the NBA's Los Angeles Clippers and Intuit Dome arena."
    },
    {
      id: "larry-ellison",
      name: "Larry Ellison",
      country: "US",
      countryName: "United States",
      netWorthUsd: 156.0,
      publicEquityUsd: 143.5,
      vestedOptionsUsd: 4.5,
      privateAssetsUsd: 8.0,
      dailyChange: 7.97,
      source: "Oracle",
      age: 82,
      hasDedicatedProfile: true,
      image: "images/avatars/larry-ellison.jpg",
      bio: "Co-founder and CTO of Oracle Corporation, expanding enterprise AI cloud database infrastructure worldwide."
    },
    {
      id: "amancio-ortega",
      name: "Amancio Ortega",
      country: "ES",
      countryName: "Spain",
      netWorthUsd: 154.8,
      publicEquityUsd: 135.3,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 19.5,
      dailyChange: 0.4,
      source: "Inditex / Zara, Pontegadea",
      age: 90,
      hasDedicatedProfile: true,
      image: "images/avatars/amancio-ortega.jpg",
      bio: "Fast fashion pioneer and founder of Inditex (Zara), backed by a global commercial real estate portfolio via Pontegadea."
    },
    {
      id: "bernard-arnault",
      name: "Bernard Arnault",
      country: "FR",
      countryName: "France",
      netWorthUsd: 148.7,
      publicEquityUsd: 143.3,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 5.4,
      dailyChange: -0.2,
      source: "LVMH Moët Hennessy Louis Vuitton",
      age: 77,
      hasDedicatedProfile: true,
      image: "images/avatars/bernard-arnault.jpg",
      bio: "Chairman and CEO of LVMH Moët Hennessy Louis Vuitton, overseeing 75 prestigious luxury Maisons."
    },
    {
      id: "mukesh-ambani",
      name: "Mukesh Ambani",
      country: "IN",
      countryName: "India",
      netWorthUsd: 92.7,
      publicEquityUsd: 88.2,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 4.5,
      dailyChange: 0.6,
      source: "Reliance Industries (Jio, Retail, Oil)",
      age: 69,
      hasDedicatedProfile: true,
      image: "images/avatars/mukesh-ambani.jpg",
      bio: "Chairman and MD of Reliance Industries, leading India's energy transition, Jio telecommunications, and digital retail ecosystem."
    },
    {
      id: "gautam-adani",
      name: "Gautam Adani",
      country: "IN",
      countryName: "India",
      netWorthUsd: 83.4,
      publicEquityUsd: 81.0,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 2.4,
      dailyChange: 0.9,
      source: "Adani Group (Ports, Power, Green Energy)",
      age: 64,
      hasDedicatedProfile: true,
      image: "images/avatars/gautam-adani.jpg",
      bio: "Founder and Chairman of Adani Group, operating India's largest private ports, airports, transmission lines, and Khavda renewable parks."
    },
    {
      id: "savitri-jindal",
      name: "Savitri Jindal & family",
      country: "IN",
      countryName: "India",
      netWorthUsd: 41.1,
      publicEquityUsd: 39.7,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 1.4,
      dailyChange: 0.5,
      source: "O.P. Jindal Group (Steel, Power)",
      age: 76,
      hasDedicatedProfile: true,
      image: "images/avatars/savitri-jindal.jpg",
      bio: "Chairperson Emeritus of the O.P. Jindal Group and India's wealthiest woman across steel, power, and infrastructure."
    },
    {
      id: "shiv-nadar",
      name: "Shiv Nadar",
      country: "IN",
      countryName: "India",
      netWorthUsd: 30.8,
      publicEquityUsd: 23.5,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 7.3,
      dailyChange: 0.3,
      source: "HCL Technologies",
      age: 81,
      hasDedicatedProfile: true,
      image: "images/avatars/shiv-nadar.jpg",
      bio: "Founder of HCL Enterprise and pioneer of Indian IT engineering services with substantial liquid reserves."
    },
    {
      id: "dilip-shanghvi",
      name: "Dilip Shanghvi",
      country: "IN",
      countryName: "India",
      netWorthUsd: 26.9,
      publicEquityUsd: 26.1,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 0.8,
      dailyChange: 0.2,
      source: "Sun Pharmaceutical Industries",
      age: 71,
      hasDedicatedProfile: true,
      image: "images/avatars/dilip-shanghvi.jpg",
      bio: "Founder of Sun Pharmaceutical Industries, India's largest specialty generic pharmaceutical leader."
    },
    {
      id: "lakshmi-mittal",
      name: "Lakshmi Mittal",
      country: "IN",
      countryName: "India",
      netWorthUsd: 23.2,
      publicEquityUsd: 21.0,
      vestedOptionsUsd: 0.0,
      privateAssetsUsd: 2.2,
      dailyChange: 2.97,
      source: "ArcelorMittal Steel",
      age: 76,
      hasDedicatedProfile: true,
      image: "images/avatars/lakshmi-mittal.jpg",
      bio: "Executive Chairman of ArcelorMittal, the world's leading integrated steel and mining enterprise."
    }
  ];

  // Format Indian Numbering (₹ Crores)
  function formatInrCrores(crores) {
    if (isNaN(crores) || crores === null || crores === undefined) return '0';
    const parts = Math.round(crores).toString().split('.');
    let lastThree = parts[0].substring(parts[0].length - 3);
    const otherNumbers = parts[0].substring(0, parts[0].length - 3);
    if (otherNumbers !== '') {
      lastThree = ',' + lastThree;
    }
    return otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
  }

  // Format to Lakh Crores (e.g. ₹84.14 Lakh Cr)
  function formatInrLakhCrores(crores) {
    if (!crores) return '₹0 Cr';
    const lakhCr = crores / 100000;
    if (lakhCr >= 1) {
      return `₹${lakhCr.toFixed(2)} Lakh Cr`;
    }
    return `₹${formatInrCrores(crores)} Cr`;
  }

  function normalizeListWithRanks(rawList, fxRate) {
    const master = rawList.map(item => {
      const worth = Number(item.netWorth ?? item.netWorthUsd ?? 0);
      const inrCrore = Math.round(worth * fxRate * 100);
      return {
        ...item,
        netWorth: parseFloat(worth.toFixed(1)),
        netWorthUsd: parseFloat(worth.toFixed(1)),
        netWorthInrCrore: inrCrore,
        rateUsed: fxRate
      };
    });

    // Strict numerical descending sort by netWorth (1-based index -> zero off-by-one)
    master.sort((a, b) => Number(b.netWorth) - Number(a.netWorth));
    master.forEach((b, idx) => {
      b.globalRank = idx + 1;
    });

    // Clone subsets so regional countryRank NEVER mutates globalRank on shared references
    const globalTop10 = master.slice(0, 10).map(b => ({ ...b }));
    const indiaTop5 = master
      .filter(b => b.country === 'IN')
      .sort((a, b) => Number(b.netWorth) - Number(a.netWorth))
      .slice(0, 5)
      .map((b, idx) => ({ ...b, countryRank: idx + 1 }));

    const usaTop5 = master
      .filter(b => b.country === 'US')
      .sort((a, b) => Number(b.netWorth) - Number(a.netWorth))
      .slice(0, 5)
      .map((b, idx) => ({ ...b, countryRank: idx + 1 }));

    return {
      all: master,
      global: globalTop10,
      india: indiaTop5,
      usa: usaTop5
    };
  }

  const NetWorthEngine = {
    usdToInrRate: DEFAULT_USD_TO_INR_RATE,
    currencyMode: 'dual',
    data: null,
    meta: null,
    isFetchingFx: false,
    isFetchingLive: false,
    isLiveHydrated: false,
    lastLiveFetchAt: 0,

    async init() {
      // Clear legacy stale caches & enforce strict USD global / INR India default
      ['bw_networth_data_v1', 'bw_networth_data_v2', 'bw_networth_data_v3', 'bw_networth_data_v4', 'bw_currency_pref_v2'].forEach(k => {
        try { localStorage.removeItem(k); } catch (e) {}
      });

      this.currencyMode = 'dual';

      // Remove any leftover FX UI bar if present and render quick baseline immediately
      this.mountCurrencyBar();
      await this.initExchangeRate();
      this.hydrateInitialFallback();
      this.updateProfilePageDOM();

      // Immediately auto-refresh live FX & public market data whenever user enters the site
      await this.fetchLiveMarketData(false, true);

      // Keep data fresh silently every 5 minutes while page remains active
      if (!this._autoRefreshInterval) {
        this._autoRefreshInterval = setInterval(() => {
          if (typeof document === 'undefined' || !document.hidden) {
            this.fetchLiveMarketData(false);
          }
        }, 5 * 60 * 1000);
      }

      // Optional manual refresh button delegation (e.g., #refresh-global)
      document.addEventListener('click', (e) => {
        const btn = e.target.closest('#refresh-global, .refresh-btn');
        if (btn) {
          e.preventDefault();
          this.handleManualRefresh();
        }
      });
    },

    hydrateInitialFallback() {
      const hasSsrCards = Boolean(document.querySelector('#global-billionaires .billionaire-card'));
      try {
        const cached = localStorage.getItem(STORAGE_KEY);
        if (cached) {
          const parsed = JSON.parse(cached);
          if (parsed?.data?.all?.length) {
            if (parsed.meta?.exchangeRateUsdInr) {
              this.usdToInrRate = Number(parsed.meta.exchangeRateUsdInr);
            }
            this.data = normalizeListWithRanks(parsed.data.all, this.usdToInrRate);
            this.meta = parsed.meta;
            if (!hasSsrCards || this.currencyMode !== 'dual') {
              this.renderAllGrids();
            } else {
              this.mountSparklinesOnly();
            }
            this.updateRichestPeopleText();
            return;
          }
        }
      } catch (e) {}

      this.data = normalizeListWithRanks(MASTER_BILLIONAIRES, this.usdToInrRate);
      this.meta = {
        lastUpdated: new Date().toISOString(),
        exchangeRateUsdInr: this.usdToInrRate,
        source: 'SEC EDGAR & BSE/NSE Public Disclosures'
      };
      if (!hasSsrCards || this.currencyMode !== 'dual') {
        this.renderAllGrids();
      } else {
        this.mountSparklinesOnly();
      }
      this.updateRichestPeopleText();
    },

    mountSparklinesOnly() {
      if (!this.data || !window.BillionaireSparkline || typeof window.BillionaireSparkline.renderCard !== 'function') return;
      const allMap = new Map(this.data.all.map(b => [b.id, b]));
      document.querySelectorAll('.billionaire-card[data-billionaire-id]').forEach(card => {
        const slot = card.querySelector('.growth-trend-slot');
        if (slot && slot.children.length > 0) return;
        const person = allMap.get(card.getAttribute('data-billionaire-id'));
        if (person) {
          const isIndiaGrid = Boolean(card.closest('#india-billionaires'));
          window.BillionaireSparkline.renderCard(card, person, { isIndiaGrid });
        }
      });
    },

    async initExchangeRate() {
      try {
        const cachedFx = localStorage.getItem(FX_STORAGE_KEY);
        if (cachedFx) {
          const parsed = JSON.parse(cachedFx);
          if (parsed.rate && Date.now() - parsed.timestamp < 5 * 60 * 1000) {
            this.usdToInrRate = parsed.rate;
          }
        }
      } catch (e) {}
    },

    async fetchLiveMarketData(force = false, isEntry = false) {
      if (this.isFetchingLive) return;
      if (!force && !isEntry && Date.now() - this.lastLiveFetchAt < 45000 && this.isLiveHydrated) {
        return;
      }

      this.isFetchingLive = true;
      const pathname = window.location.pathname || '';
      const isSubPage = pathname.includes('/profiles/') || pathname.includes('/insights/') || pathname.includes('/tools/');
      const staticJsonUrl = isSubPage ? '../data/billionaires.json' : 'data/billionaires.json';

      const hostname = window.location.hostname || '';
      const isApiCapableHost =
        hostname === 'localhost' ||
        hostname === '127.0.0.1' ||
        hostname.endsWith('.run.app') ||
        hostname.endsWith('.netlify.app');

      try {
        // 1. Auto-fetch live USD/INR FX silently in parallel on every site entry
        const fxPromise = this.fetchLiveExchangeRate(force || isEntry);

        // 2. Query backend live endpoint only on API-capable hosts to avoid 404 console errors on static CDNs
        let payload = null;
        if (isApiCapableHost) {
          try {
            const apiUrl = force ? '/api/billionaires/live?refresh=1' : '/api/billionaires/live';
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), force ? 7000 : 3500);
            const resp = await fetch(apiUrl, { cache: 'no-store', signal: controller.signal });
            clearTimeout(timeoutId);
            if (resp.ok) {
              const apiJson = await resp.json();
              if (apiJson && apiJson.ok && Array.isArray(apiJson.all) && apiJson.all.length > 0) {
                payload = apiJson;
              }
            }
          } catch (e) {}
        }

        // 3. Seamless static JSON fallback (e.g. CDN / Netlify hosting) with cache revalidation
        if (!payload) {
          try {
            const staticResp = await fetch(staticJsonUrl, { cache: 'no-cache' });
            if (staticResp.ok) {
              const staticJson = await staticResp.json();
              if (staticJson && Array.isArray(staticJson.billionaires) && staticJson.billionaires.length > 0) {
                payload = {
                  ok: true,
                  all: staticJson.billionaires,
                  meta: {
                    ...(staticJson.meta || {}),
                    exchangeRateUsdInr: Number(staticJson.meta?.currencyUsdInrRate || this.usdToInrRate),
                    lastUpdated: staticJson.meta?.lastUpdated
                  }
                };
              }
            }
          } catch (e) {}
        }

        const freshClientRate = await fxPromise;

        if (payload && Array.isArray(payload.all) && payload.all.length > 0) {
          const payloadRate = Number(payload.meta?.exchangeRateUsdInr || payload.meta?.currencyUsdInrRate) || 0;
          const liveRate = (freshClientRate && freshClientRate > 75 && freshClientRate < 120)
            ? freshClientRate
            : (payloadRate > 75 && payloadRate < 120 ? payloadRate : this.usdToInrRate);

          this.usdToInrRate = liveRate;
          try {
            localStorage.setItem(FX_STORAGE_KEY, JSON.stringify({
              rate: liveRate,
              timestamp: Date.now()
            }));
          } catch (e) {}

          const normalized = normalizeListWithRanks(payload.all, liveRate);
          this.data = {
            all: normalized.all,
            global: normalized.global,
            india: normalized.india,
            usa: normalized.usa
          };
          this.meta = {
            ...(payload.meta || {}),
            exchangeRateUsdInr: liveRate,
            lastUpdated: payload.meta?.lastUpdated || new Date().toISOString()
          };
          this.isLiveHydrated = true;
          this.lastLiveFetchAt = Date.now();

          try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify({
              data: this.data,
              meta: this.meta
            }));
          } catch (e) {}

          this.renderAllGrids();
          this.updateCurrencyBar();
          this.updateProfilePageDOM();
          this.updateRichestPeopleText();

          window.dispatchEvent(new CustomEvent('bw-data-updated', {
            detail: {
              billionaires: this.data.all,
              global: this.data.global,
              india: this.data.india,
              usa: this.data.usa,
              meta: this.meta,
              isLive: true
            }
          }));

          if (force) {
            this.showToast(`Synced Latest Filings & Market Quotes (#1 ${this.data.global[0]?.name} $${this.data.global[0]?.netWorth}B)`);
          }
          return;
        }
      } catch (err) {
        await this.fetchLiveExchangeRate(true);
      } finally {
        this.isFetchingLive = false;
      }

      this.refreshLiveRankings(force);
    },

    async fetchLiveExchangeRate(force = false) {
      if (this.isFetchingFx) return this.usdToInrRate;
      if (!force) {
        try {
          const cachedFx = localStorage.getItem(FX_STORAGE_KEY);
          if (cachedFx) {
            const parsed = JSON.parse(cachedFx);
            if (parsed.rate && Date.now() - parsed.timestamp < 60 * 1000) {
              this.usdToInrRate = parsed.rate;
              return parsed.rate;
            }
          }
        } catch (e) {}
      }

      this.isFetchingFx = true;
      let resolvedRate = null;

      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 3500);
        const response = await fetch('https://open.er-api.com/v6/latest/USD', { cache: 'no-store', signal: controller.signal });
        clearTimeout(timeoutId);

        if (response.ok) {
          const result = await response.json();
          if (result && result.rates && result.rates.INR) {
            const liveRate = parseFloat(Number(result.rates.INR).toFixed(2));
            if (liveRate > 75 && liveRate < 120) {
              resolvedRate = liveRate;
              this.usdToInrRate = liveRate;
              try {
                localStorage.setItem(FX_STORAGE_KEY, JSON.stringify({
                  rate: liveRate,
                  timestamp: Date.now()
                }));
              } catch (e) {}
            }
          }
        }
      } catch (err) {
        try {
          const res2 = await fetch('https://api.exchangerate-api.com/v4/latest/USD', { cache: 'no-store' });
          if (res2.ok) {
            const data2 = await res2.json();
            if (data2?.rates?.INR) {
              const liveRate2 = parseFloat(Number(data2.rates.INR).toFixed(2));
              if (liveRate2 > 75 && liveRate2 < 120) {
                resolvedRate = liveRate2;
                this.usdToInrRate = liveRate2;
                try {
                  localStorage.setItem(FX_STORAGE_KEY, JSON.stringify({
                    rate: liveRate2,
                    timestamp: Date.now()
                  }));
                } catch (e) {}
              }
            }
          }
        } catch (e) {}
      } finally {
        this.isFetchingFx = false;
      }

      return resolvedRate;
    },

    refreshLiveRankings(isManualTrigger = false) {
      const rate = this.usdToInrRate || DEFAULT_USD_TO_INR_RATE;
      const sourceList = (this.data && Array.isArray(this.data.all) && this.data.all.length > 0)
        ? this.data.all
        : MASTER_BILLIONAIRES;

      this.data = normalizeListWithRanks(sourceList, rate);
      this.meta = {
        ...(this.meta || {}),
        lastUpdated: this.meta?.lastUpdated || new Date().toISOString(),
        exchangeRateUsdInr: rate,
        source: 'SEC EDGAR, BSE/NSE Filings & Public Exchange APIs'
      };

      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify({
          data: this.data,
          meta: this.meta
        }));
      } catch (e) {}

      this.renderAllGrids();
      this.updateProfilePageDOM();
      this.updateRichestPeopleText();

      window.dispatchEvent(new CustomEvent('bw-data-updated', {
        detail: {
          billionaires: this.data.all,
          global: this.data.global,
          india: this.data.india,
          usa: this.data.usa,
          meta: this.meta
        }
      }));

      if (isManualTrigger && !this.isLiveHydrated) {
        this.showToast(`Refreshed: Real-time valuations updated @ 1 USD = ₹${rate}`);
      }
    },

    refreshData(externalList) {
      if (!Array.isArray(externalList) || externalList.length === 0) return;
      const incomingMap = new Map();
      externalList.forEach(item => {
        if (item && item.id) incomingMap.set(item.id, item);
      });

      const currentAll = (this.data && Array.isArray(this.data.all) ? this.data.all : MASTER_BILLIONAIRES).map(b => {
        const inc = incomingMap.get(b.id);
        if (!inc) return b;
        const worth = Number(inc.netWorth ?? inc.netWorthUsd ?? b.netWorthUsd);
        return {
          ...b,
          netWorth: worth,
          netWorthUsd: worth,
          dailyChange: inc.dailyChange !== undefined ? inc.dailyChange : b.dailyChange
        };
      });

      this.data = normalizeListWithRanks(currentAll, this.usdToInrRate);
      this.renderAllGrids();
      this.updateRichestPeopleText();
    },

    getById(id) {
      if (!id) return null;
      const pools = [
        this.data?.all,
        this.data?.global,
        this.data?.india,
        this.data?.usa,
        MASTER_BILLIONAIRES
      ];
      for (const pool of pools) {
        if (Array.isArray(pool)) {
          const found = pool.find(b => b.id === id || b.forbesUri === id);
          if (found) return found;
        }
      }
      return null;
    },

    refreshCalculatedValues() {
      if (!this.data || !this.data.all) return;
      this.data = normalizeListWithRanks(this.data.all, this.usdToInrRate);
      this.renderAllGrids();
      this.updateProfilePageDOM();
      this.updateRichestPeopleText();
    },

    async handleManualRefresh() {
      const btn = document.getElementById('refresh-global');
      if (btn) {
        btn.dataset.origHtml = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Syncing Live Quotes...';
        btn.disabled = true;
      }

      try {
        await this.fetchLiveMarketData(true);
      } finally {
        if (btn) {
          btn.innerHTML = btn.dataset.origHtml || '<i class="fas fa-sync-alt"></i> Refresh Cached Feed';
          btn.disabled = false;
        }
      }
    },

    mountCurrencyBar() {
      // Foreign exchange bar UI intentionally removed; remove any stale element if present
      const existingBar = document.getElementById('bw-live-forex-bar');
      if (existingBar) existingBar.remove();
    },

    updateCurrencyBar() {
      if (this.meta?.lastUpdated) {
        const iso = String(this.meta.lastUpdated);
        document.querySelectorAll('.intro-content time').forEach((el) => {
          el.setAttribute('datetime', iso);
        });
      }
    },

    setCurrencyMode() {
      this.currencyMode = 'dual';
      this.renderAllGrids();
    },

    renderAllGrids() {
      if (!this.data) return;

      const gb = document.getElementById('global-billionaires');
      const ib = document.getElementById('india-billionaires');
      const ub = document.getElementById('usa-billionaires');

      if (gb) this.renderGridCards(this.data.global, gb, 'global');
      if (ib) this.renderGridCards(this.data.india, ib, 'india');
      if (ub) this.renderGridCards(this.data.usa, ub, 'usa');

      const spinner = document.getElementById('loadingSpinner');
      if (spinner) spinner.style.display = 'none';

      this.updateIndiaStatsMetrics();
    },

    renderGridCards(list, container, gridType = 'global') {
      if (!container || !Array.isArray(list) || list.length === 0) return;

      // Guarantee list passed into renderer is strictly descending sorted
      const sortedList = [...list].sort((a, b) => Number(b.netWorthUsd) - Number(a.netWorthUsd));
      const isIndiaGrid = gridType === 'india' || container.id === 'india-billionaires';
      const isUsaGrid = gridType === 'usa' || container.id === 'usa-billionaires';

      container.innerHTML = '';
      const maxVal = sortedList[0]?.netWorthUsd || 900;

      sortedList.forEach((person, idx) => {
        const globalRank = Number(person.globalRank) || (idx + 1);
        const regionalRank = Number(person.countryRank) || (idx + 1);
        const displayBadgeRank = isIndiaGrid ? regionalRank : (isUsaGrid ? regionalRank : globalRank);

        const usdVal = Number(person.netWorthUsd).toFixed(1);
        const inrCrores = person.netWorthInrCrore || Math.round(person.netWorthUsd * this.usdToInrRate * 100);
        const inrLakhCrText = formatInrLakhCrores(inrCrores);
        const dailyNum = Number(person.dailyChange || 0);
        const isProfit = dailyNum >= 0;
        const changeClass = isProfit ? 'up' : 'down';
        const changeIcon = isProfit ? 'arrow-up' : 'arrow-down';
        const sign = isProfit ? '+' : '';

        const barWidth = Math.min(100, Math.max(8, (person.netWorthUsd / maxVal) * 100));
        const hasDedicated = person.hasDedicatedProfile !== false;
        const profileUrl = `profiles/${person.id}.html`;

        const rankLineText = isIndiaGrid
          ? `Rank #${regionalRank} in India &bull; Global #${globalRank}`
          : (isUsaGrid ? `US #${regionalRank} &bull; Global Rank #${globalRank}` : `Global Rank #${globalRank}`);

        const deltaUsdVal = ((Number(person.netWorthUsd) * dailyNum) / 100).toFixed(1);
        let netWorthDisplay = '';
        if (this.currencyMode === 'inr') {
          netWorthDisplay = `
            <p class="net-worth" style="font-size: 1.55rem; font-weight: 800; color: #FFA500; margin: 0.35rem 0 0.15rem 0;">
              ₹${formatInrCrores(inrCrores)} <span style="font-size:0.75rem;">Crores</span>
              <span class="inr-subtext" style="display:block; font-size:0.82rem; font-weight:600; color:var(--text); opacity:0.92; margin-top:3px;">
                (${inrLakhCrText}) &bull; ${rankLineText}
              </span>
            </p>
          `;
        } else if (isIndiaGrid && this.currencyMode !== 'usd') {
          netWorthDisplay = `
            <p class="net-worth" style="font-size: 1.55rem; font-weight: 800; color: #ff9933; margin: 0.35rem 0 0.15rem 0; line-height: 1.25;">
              ₹${formatInrCrores(inrCrores)} <span style="font-size:0.75rem;">Crores</span>
              <span class="inr-subtext" style="display:block; font-size:0.84rem; font-weight:700; color:#f9c74f; margin-top:4px;">
                ≈ ${inrLakhCrText} ($${usdVal}B USD)
              </span>
              <span style="display:block; font-size:0.76rem; font-weight:700; opacity:0.88; color:var(--text); margin-top:3px;">
                ${rankLineText}
              </span>
            </p>
          `;
        } else {
          netWorthDisplay = `
            <p class="net-worth" style="font-size: 1.6rem; font-weight: 800; color: #FFA500; margin: 0.35rem 0 0.15rem 0; line-height: 1.25;">
              $${usdVal}B USD
              <span style="display:block; font-size:0.78rem; font-weight:700; opacity:0.9; color:var(--text); margin-top:4px;">
                ${rankLineText}
              </span>
            </p>
          `;
        }

        const rankBadgeStyle = isIndiaGrid
          ? 'background: #ff9933; color: #1a1a2e; width: auto; padding: 3px 12px; border-radius: 20px; font-size: 0.82rem; font-weight: 800;'
          : '';
        const rankBadgeText = isIndiaGrid
          ? `#${displayBadgeRank} In India 🇮🇳`
          : (isUsaGrid ? `#${displayBadgeRank}` : `#${globalRank}`);

        const primaryActionHtml = hasDedicated
          ? `<a href="${profileUrl}" class="btn btn-primary open-profile-btn" style="display: flex; align-items: center; justify-content: center; gap: 8px; font-weight: 800; padding: 10px 16px; text-decoration: none; border-radius: 8px; font-size: 0.92rem; ${isIndiaGrid ? 'background:#ff9933; color:#1a1a2e; border:none;' : ''}">
               <i class="fas fa-id-card"></i> View Full Profile Page &rarr;
             </a>`
          : `<button type="button" class="btn btn-primary learn-more-btn" data-id="${person.id}" onclick="if(window.showProfileModal){window.showProfileModal('${person.id}');}" style="display: flex; align-items: center; justify-content: center; gap: 8px; font-weight: 800; padding: 10px 16px; border:none; border-radius: 8px; font-size: 0.92rem; cursor:pointer; ${isIndiaGrid ? 'background:#ff9933; color:#1a1a2e;' : ''}">
               <i class="fas fa-file-invoice-dollar"></i> View Financial Disclosures &rarr;
             </button>`;

        const imgWrapperStart = hasDedicated
          ? `<a href="${profileUrl}" title="View ${person.name}'s verified net worth and asset breakdown" style="display:block; text-align:center;">`
          : `<a href="javascript:void(0)" onclick="if(window.showProfileModal){window.showProfileModal('${person.id}');}" title="Preview ${person.name}'s live financial disclosures" style="display:block; text-align:center;">`;

        const titleWrapperStart = hasDedicated
          ? `<a href="${profileUrl}" title="View profile" style="text-decoration:none; color:inherit;">`
          : `<a href="javascript:void(0)" onclick="if(window.showProfileModal){window.showProfileModal('${person.id}');}" title="Preview disclosures" style="text-decoration:none; color:inherit;">`;

        const card = document.createElement('div');
        card.className = 'billionaire-card';
        card.dataset.billionaireId = person.id;
        if (isIndiaGrid) card.style.borderTop = '3px solid #ff9933';

        const avatarSrc = `images/avatars/${person.id}.jpg`;

        card.innerHTML = `
          <div class="rank-badge" style="${rankBadgeStyle}" title="Global Rank #${globalRank}">${rankBadgeText}</div>
          <a href="${profileUrl}" title="View ${person.name}'s verified net worth and asset breakdown" style="display:block; text-align:center;">
            <img src="${avatarSrc}" width="90" height="90" class="profile-img" alt="${person.name}" loading="lazy" decoding="async">
          </a>
          ${globalRank === 1 ? '<div class="crown-animation"><i class="fas fa-crown"></i></div>' : ''}

          <div class="wealth-meter">
            <div class="wealth-bar" style="width: ${barWidth.toFixed(1)}%; background: ${isIndiaGrid ? 'linear-gradient(90deg, #ff9933, #4ade80)' : 'linear-gradient(90deg, #FFA500, #ff9a00)'}; transition: width 0.6s ease;"></div>
          </div>

          <div class="wealth-change ${changeClass}">
            <i class="fas fa-${changeIcon}"></i> ${sign}${dailyNum.toFixed(2)}% today
            <span style="font-size:0.75rem; opacity:0.85; margin-left:4px;">(${sign}$${Math.abs(Number(deltaUsdVal)).toFixed(1)}B)</span>
          </div>

          <a href="${profileUrl}" title="View ${person.name} wealth profile" style="text-decoration:none; color:inherit;">
            <h3 style="transition: color 0.2s; cursor: pointer; color: var(--accent);">${person.name}</h3>
          </a>

          ${netWorthDisplay}

          <p class="primary-source" style="font-size: 0.86rem; color: var(--text); opacity: 0.9;">${person.source}</p>
          <div class="growth-trend-slot" data-sparkline-id="${person.id}"></div>

          <div class="button-container" style="display: flex; flex-direction: column; gap: 8px; margin-top: auto; padding-top: 12px;">
            ${isIndiaGrid ? `<button type="button" class="btn btn-ask-ai" onclick="if(window.BillionaireWatchBot){window.BillionaireWatchBot.ask('Break down ${person.name.replace(/'/g, '')} net worth in INR crores and disclosed BSE/NSE holdings');}" style="background: rgba(255,153,51,0.15); color: #ffb366; border: 1px solid rgba(255,153,51,0.35); padding: 7px 10px; border-radius: 6px; font-weight: 600; font-size: 0.8rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px;"><i class="fas fa-robot"></i> Ask AI About ${person.name.split(' ')[0]}</button>` : ''}
            <a href="${profileUrl}" class="btn btn-primary open-profile-btn" style="display: flex; align-items: center; justify-content: center; gap: 8px; font-weight: 800; padding: 10px 16px; text-decoration: none; border-radius: 8px; font-size: 0.92rem; ${isIndiaGrid ? 'background:#ff9933; color:#1a1a2e; border:none;' : ''}">
              <i class="fas fa-id-card"></i> ${person.name} Wealth Profile &rarr;
            </a>
            <button type="button" class="btn btn-secondary learn-more-btn" data-id="${person.id}" onclick="if(window.showProfileModal){window.showProfileModal('${person.id}');}" style="background-color: var(--secondary); color: var(--text); border: 1px solid rgba(255,255,255,0.18); font-size:0.84rem; padding:7px 10px; display:flex; align-items:center; justify-content:center; gap:6px; border-radius:6px; cursor:pointer;">
              <i class="fas fa-search-plus"></i> Quick Chart &amp; Disclosures
            </button>
          </div>

          <span class="country-flag" aria-label="${person.country} Country Code" style="display:inline-flex; align-items:center; justify-content:center; font-size:0.72rem; font-weight:800; background:#1a1a2e; color:#f9c74f; border:1px solid rgba(249,199,79,0.45); border-radius:4px; padding:2px 6px;">${person.country}</span>
        `;

        if (window.BillionaireSparkline && typeof window.BillionaireSparkline.renderCard === 'function') {
          window.BillionaireSparkline.renderCard(card, person, { isIndiaGrid });
        }

        container.appendChild(card);
      });
    },

    updateIndiaStatsMetrics() {
      if (!this.data || !this.data.india || this.data.india.length < 2) return;
      const top1 = this.data.india[0];
      const top2 = this.data.india[1];

      if (top1 && top2) {
        const gapUsd = Math.max(0, top1.netWorthUsd - top2.netWorthUsd).toFixed(1);
        const gapCr = Math.max(0, top1.netWorthInrCrore - top2.netWorthInrCrore);
        const combinedUsd = this.data.india.reduce((sum, b) => sum + Number(b.netWorthUsd || 0), 0).toFixed(1);
        const combinedCr = this.data.india.reduce((sum, b) => sum + Number(b.netWorthInrCrore || 0), 0);

        const metricsGrid = document.querySelector('.india-stats-grid');
        if (metricsGrid) {
          metricsGrid.innerHTML = `
            <div style="background: rgba(255,153,51,0.08); border: 1px solid rgba(255,153,51,0.25); border-left: 4px solid #ff9933; border-radius: 10px; padding: 12px 16px;">
              <div style="font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.5px; color: #ffb366; font-weight: 700;">#1 In India (Global #${top1.globalRank})</div>
              <div style="font-size: 1.3rem; font-weight: 800; color: #ff9933; margin: 3px 0 1px;">${top1.name}</div>
              <div style="font-size: 0.85rem; color: var(--text); font-weight: 600;">₹${formatInrCrores(top1.netWorthInrCrore)} Cr <span style="opacity: 0.75; font-size: 0.75rem;">($${top1.netWorthUsd}B)</span></div>
            </div>
            <div style="background: rgba(58,134,255,0.08); border: 1px solid rgba(58,134,255,0.25); border-left: 4px solid #3a86ff; border-radius: 10px; padding: 12px 16px;">
              <div style="font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.5px; color: #70a5ff; font-weight: 700;">#2 In India (Global #${top2.globalRank})</div>
              <div style="font-size: 1.3rem; font-weight: 800; color: #3a86ff; margin: 3px 0 1px;">${top2.name}</div>
              <div style="font-size: 0.85rem; color: var(--text); font-weight: 600;">₹${formatInrCrores(top2.netWorthInrCrore)} Cr <span style="opacity: 0.75; font-size: 0.75rem;">($${top2.netWorthUsd}B)</span></div>
            </div>
            <div style="background: rgba(74,222,128,0.08); border: 1px solid rgba(74,222,128,0.25); border-left: 4px solid #4ade80; border-radius: 10px; padding: 12px 16px;">
              <div style="font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.5px; color: #86efac; font-weight: 700;">#1 vs #2 Margin</div>
              <div style="font-size: 1.3rem; font-weight: 800; color: #4ade80; margin: 3px 0 1px;">₹${formatInrCrores(gapCr)} Cr</div>
              <div style="font-size: 0.85rem; color: var(--text); font-weight: 600;">$${gapUsd}B USD Margin</div>
            </div>
            <div style="background: rgba(249,199,79,0.08); border: 1px solid rgba(249,199,79,0.25); border-left: 4px solid #f9c74f; border-radius: 10px; padding: 12px 16px;">
              <div style="font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.5px; color: #fde047; font-weight: 700;">India Top 5 Combined</div>
              <div style="font-size: 1.3rem; font-weight: 800; color: #f9c74f; margin: 3px 0 1px;">₹${formatInrCrores(combinedCr)} Cr</div>
              <div style="font-size: 0.85rem; color: var(--text); font-weight: 600;">$${combinedUsd}B USD Total</div>
            </div>
          `;
        }
      }
    },

    updateRichestPeopleText() {
      const listEl = document.querySelector('#richest-people ul');
      if (listEl && this.data && Array.isArray(this.data.global)) {
        listEl.innerHTML = this.data.global.slice(0, 10).map(b =>
          `<li><a href="profiles/${b.id}.html" style="font-weight:700;">#${b.globalRank} ${b.name}</a> &ndash; $${Number(b.netWorthUsd).toFixed(1)} billion USD &bull; ${b.source || ''}</li>`
        ).join('');
      }
    },

    updateProfilePageDOM() {
      const currentPath = window.location.pathname;
      const profileMatch = currentPath.match(/\/profiles\/([^/.]+)/);
      if (!profileMatch || !this.data || !this.data.all) return;

      const profileId = profileMatch[1];
      const person = this.data.all.find(b => b.id === profileId);
      if (!person) return;

      const rate = this.usdToInrRate;
      const inrCrores = person.netWorthInrCrore || Math.round(person.netWorthUsd * rate * 100);
      const inrText = formatInrLakhCrores(inrCrores);

      const usdFormatted = `$${Number(person.netWorthUsd).toFixed(1)}B USD`;
      const inrFullFormatted = `${inrText} / ₹${formatInrCrores(inrCrores)} Cr`;

      // Update dedicated spans cleanly when present so country rank, primary sector, and daily change remain intact
      const rankEl = document.querySelector('.bw-global-rank');
      if (rankEl) rankEl.textContent = `#${person.globalRank} Worldwide`;

      const worthUsdEl = document.querySelector('.bw-net-worth-usd');
      if (worthUsdEl) worthUsdEl.textContent = usdFormatted;

      const worthInrEl = document.querySelector('.bw-net-worth-inr');
      if (worthInrEl) worthInrEl.textContent = inrFullFormatted;

      const fxEl = document.querySelector('.bw-fx-rate');
      if (fxEl) fxEl.textContent = `₹${Number(rate).toFixed(2)}`;

      if (rankEl || worthUsdEl) return;

      // Fallback for older static profile markup if spans are absent
      const stats = document.querySelectorAll('.profile-header .stat');
      stats.forEach(stat => {
        if (stat.textContent.includes('Estimated Net Worth:')) {
          const strongs = stat.querySelectorAll('strong');
          if (strongs.length >= 2) {
            strongs[0].textContent = usdFormatted;
            strongs[1].textContent = inrFullFormatted;
          }
        } else if (stat.textContent.includes('Global Rank:')) {
          const firstStrong = stat.querySelector('strong');
          if (firstStrong) firstStrong.textContent = `#${person.globalRank} Worldwide`;
        }
      });
    },

    showToast(message) {
      let toast = document.getElementById('bw-toast-notification');
      if (!toast) {
        toast = document.createElement('div');
        toast.id = 'bw-toast-notification';
        toast.style.cssText = `
          position: fixed;
          bottom: 25px;
          right: 25px;
          background: #16213e;
          color: #4ade80;
          border: 2px solid #4ade80;
          padding: 12px 20px;
          border-radius: 8px;
          font-weight: 700;
          font-size: 0.88rem;
          box-shadow: 0 10px 30px rgba(0,0,0,0.6);
          z-index: 10000;
          display: flex;
          align-items: center;
          gap: 10px;
          transition: opacity 0.3s ease, transform 0.3s ease;
        `;
        document.body.appendChild(toast);
      }
      toast.innerHTML = `<i class="fas fa-check-circle" style="color:#FFA500; font-size:1.1rem;"></i> <span>${message}</span>`;
      toast.style.opacity = '1';
      toast.style.transform = 'translateY(0)';

      clearTimeout(this._toastTimeout);
      this._toastTimeout = setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(20px)';
      }, 3500);
    }
  };

  // Expose full Global API
  window.BillionaireWatchData = {
    getAll: () => NetWorthEngine.data?.all || MASTER_BILLIONAIRES,
    getGlobal: () => NetWorthEngine.data?.global || [],
    getIndia: () => NetWorthEngine.data?.india || [],
    getUsa: () => NetWorthEngine.data?.usa || [],
    getById: (id) => NetWorthEngine.getById(id),
    refreshData: (list) => NetWorthEngine.refreshData(list),
    getFxRate: () => NetWorthEngine.usdToInrRate,
    isLiveHydrated: () => NetWorthEngine.isLiveHydrated,
    refresh: () => NetWorthEngine.handleManualRefresh(),
    render: () => NetWorthEngine.renderAllGrids(),
    formatInr: formatInrCrores,
    formatLakhCr: formatInrLakhCrores
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => NetWorthEngine.init());
  } else {
    NetWorthEngine.init();
  }

  window.addEventListener('pageshow', () => {
    NetWorthEngine.fetchLiveMarketData(false);
  });

  window.addEventListener('focus', () => {
    NetWorthEngine.fetchLiveMarketData(false);
  });
})();
