/**
 * Spend Elon Musk's $1,000,000,000,000 ($1 Trillion) Fortune
 * Inspired by neal.fun's "Spend Bill Gates' Money"
 * BillionaireWatch.in Interactive Feature
 */
(function() {
  'use strict';

  const STARTING_BALANCE = 1000000000000; // $1,000,000,000,000 (1 Trillion USD)
  function getUsdToInr() {
    if (window.BillionaireWatchData && typeof window.BillionaireWatchData.getFxRate === 'function') {
      const rate = Number(window.BillionaireWatchData.getFxRate());
      if (rate > 75 && rate < 120) return rate;
    }
    return 94.29;
  }

  const ITEMS = [
    { id: 'big-mac', name: 'Big Mac', price: 5, icon: '🍔', category: 'Food' },
    { id: 'flip-flops', name: 'Flip Flops', price: 3, icon: '🩴', category: 'Apparel' },
    { id: 'coca-cola', name: 'Coca-Cola Pack (6x)', price: 6, icon: '🥤', category: 'Food' },
    { id: 'movie-ticket', name: 'Movie Ticket', price: 15, icon: '🎟️', category: 'Entertainment' },
    { id: 'book', name: 'Bestseller Book', price: 20, icon: '📚', category: 'Entertainment' },
    { id: 'video-game', name: 'AAA Video Game', price: 70, icon: '🎮', category: 'Entertainment' },
    { id: 'netflix-year', name: '1 Year Netflix Premium', price: 240, icon: '📺', category: 'Entertainment' },
    { id: 'airpods-max', name: 'AirPods Max Headphones', price: 550, icon: '🎧', category: 'Electronics' },
    { id: 'iphone-16-pro', name: 'iPhone 16 Pro Max 1TB', price: 1599, icon: '📱', category: 'Electronics' },
    { id: 'gaming-pc', name: 'Top-tier RTX 5090 PC', price: 4500, icon: '🖥️', category: 'Electronics' },
    { id: 'rolex', name: 'Rolex Submariner Watch', price: 15000, icon: '⌚', category: 'Luxury' },
    { id: 'ford-f150', name: 'Ford F-150 Lightning EV', price: 60000, icon: '🛻', category: 'Vehicles' },
    { id: 'tesla-plaid', name: 'Tesla Model S Plaid', price: 90000, icon: '🏎️', category: 'Vehicles' },
    { id: 'gold-bar', name: '1 Kilogram Gold Bar', price: 85000, icon: '🧈', category: 'Assets' },
    { id: 'monster-truck', name: 'Custom Monster Truck', price: 175000, icon: '🚜', category: 'Vehicles' },
    { id: 'single-family-home', name: 'American Suburban Home', price: 420000, icon: '🏡', category: 'Real Estate' },
    { id: 'ferrari-sf90', name: 'Ferrari SF90 Stradale', price: 550000, icon: '🏎️', category: 'Vehicles' },
    { id: 'mcdonalds-franchise', name: "McDonald's Franchise Store", price: 1600000, icon: '🍟', category: 'Business' },
    { id: 'superbowl-ad', name: '30s Super Bowl Commercial', price: 7500000, icon: '🏈', category: 'Media' },
    { id: 'm1-tank', name: 'M1A2 Abrams Battle Tank', price: 10000000, icon: '🛡️', category: 'Defense' },
    { id: 'f1-team-car', name: 'Formula 1 Racing Car', price: 16000000, icon: '🏁', category: 'Vehicles' },
    { id: 'apache-helicopter', name: 'AH-64 Apache Helicopter', price: 35000000, icon: '🚁', category: 'Defense' },
    { id: 'mega-mansion', name: 'Bel-Air Mega Mansion', price: 65000000, icon: '🏰', category: 'Real Estate' },
    { id: 'falcon-9', name: 'SpaceX Falcon 9 Launch', price: 67000000, icon: '🚀', category: 'Space' },
    { id: 'f35-fighter', name: 'F-35 Lightning II Fighter Jet', price: 110000000, icon: '✈️', category: 'Defense' },
    { id: 'superyacht', name: '300-Foot Luxury Superyacht', price: 320000000, icon: '🛥️', category: 'Luxury' },
    { id: 'boeing-747', name: 'Custom Boeing 747 VIP Plane', price: 420000000, icon: '🛫', category: 'Vehicles' },
    { id: 'mona-lisa', name: 'The Mona Lisa (Valuation)', price: 860000000, icon: '🖼️', category: 'Art' },
    { id: 'cruise-ship', name: 'Icon-Class Luxury Cruise Ship', price: 1300000000, icon: '🚢', category: 'Vehicles' },
    { id: 'burj-khalifa', name: 'Burj Khalifa Skyscraper', price: 1500000000, icon: '🏙️', category: 'Real Estate' },
    { id: 'nba-team', name: 'NBA Team (e.g. Warriors)', price: 4000000000, icon: '🏀', category: 'Sports' },
    { id: 'nuclear-plant', name: 'Clean Nuclear Power Plant', price: 9500000000, icon: '⚛️', category: 'Infrastructure' },
    { id: 'starship-fleet', name: 'Fleet of 100 SpaceX Starships', price: 10000000000, icon: '🛸', category: 'Space' },
    { id: 'ai-gpu-cluster', name: '1,000,000 Nvidia AI GPUs Cluster', price: 35000000000, icon: '🧠', category: 'Tech' },
    { id: 'end-hunger-un', name: 'End World Hunger (1-Yr UN Goal)', price: 40000000000, icon: '🌍', category: 'Humanity' },
    { id: 'buy-twitter', name: 'Buy Twitter / X (2022 Deal)', price: 44000000000, icon: '✖️', category: 'Tech' },
    { id: 'mars-city-alpha', name: 'Self-Sustaining Mars City Alpha', price: 100000000000, icon: '🪐', category: 'Space' },
    { id: 'hyperloop-network', name: 'Global High-Speed Hyperloop', price: 150000000000, icon: '🚄', category: 'Infrastructure' }
  ];

  function formatMoney(num) {
    return '$' + num.toLocaleString('en-US');
  }

  function formatInrCrores(usd) {
    const inr = usd * getUsdToInr();
    const crores = inr / 10000000;
    if (crores < 1) return `₹${(crores * 100).toFixed(0)} Lakhs`;
    if (crores >= 100000) return `₹${(crores / 100000).toFixed(2)} Lakh Cr`;
    return `₹${Math.round(crores).toLocaleString('en-IN')} Cr`;
  }

  function injectGameStyles() {
    if (document.getElementById('spend-elon-game-styles')) return;
    const style = document.createElement('style');
    style.id = 'spend-elon-game-styles';
    style.textContent = `
      .spend-balance-bar {
        background: linear-gradient(135deg, #16213e, #0a0f1d) !important;
        border: 2px solid #f9c74f !important;
        border-radius: 12px !important;
        box-shadow: 0 8px 30px rgba(0, 0, 0, 0.7) !important;
        color: #ffffff !important;
      }
      .spend-balance-bar .balance-display, #balanceDisplay {
        color: #4ade80 !important;
        font-weight: 900 !important;
        text-shadow: 0 0 25px rgba(74, 222, 128, 0.5) !important;
      }
      .spend-card {
        background: #16213e !important;
        border: 1px solid rgba(255, 255, 255, 0.16) !important;
        border-radius: 12px !important;
        color: #ffffff !important;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
      }
      .spend-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.55);
        border-color: #f9c74f !important;
      }
      .spend-card h3 {
        color: #ffffff !important;
        font-size: 1.1rem !important;
        font-weight: 700 !important;
      }
      .spend-card .spend-price {
        color: #4ade80 !important;
        font-weight: 800 !important;
        font-size: 1.2rem !important;
      }
      .spend-card .input-qty {
        background: #0b0f19 !important;
        color: #ffffff !important;
        border: 1.5px solid #475569 !important;
        border-radius: 6px !important;
        font-weight: 800 !important;
      }
      .btn-buy {
        background: #4ade80 !important;
        color: #0b0f19 !important;
        font-weight: 800 !important;
        border: none !important;
        border-radius: 6px !important;
        cursor: pointer !important;
      }
      .btn-buy:active, .btn-sell:active {
        transform: scale(0.95);
      }
      .btn-sell {
        background: #ef4444 !important;
        color: #ffffff !important;
        font-weight: 800 !important;
        border: none !important;
        border-radius: 6px !important;
        cursor: pointer !important;
      }
      @media (max-width: 640px) {
        .spend-balance-bar {
          top: 55px !important;
          padding: 12px 14px !important;
          margin-bottom: 16px !important;
          border-radius: 8px !important;
        }
        .spend-balance-bar .balance-display {
          font-size: clamp(1.4rem, 6.5vw, 2.1rem) !important;
        }
        .spend-items-grid {
          grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)) !important;
          gap: 12px !important;
        }
        .spend-card {
          padding: 14px 10px !important;
        }
        .spend-card h3 {
          font-size: 0.98rem !important;
        }
        .spend-receipt-container {
          padding: 18px 14px !important;
          margin: 25px 8px !important;
        }
      }
      @media (min-width: 641px) and (max-width: 1024px) {
        .spend-items-grid {
          grid-template-columns: repeat(2, 1fr) !important;
          gap: 16px !important;
        }
      }
      @media (min-width: 1025px) {
        .spend-items-grid {
          grid-template-columns: repeat(3, 1fr) !important;
          gap: 20px !important;
        }
      }
    `;
    document.head.appendChild(style);
  }

  class SpendElonGame {
    constructor(containerElement) {
      injectGameStyles();
      this.container = containerElement;
      this.balance = STARTING_BALANCE;
      this.inventory = {};
      ITEMS.forEach(item => {
        this.inventory[item.id] = 0;
      });
      this.render();
    }

    get totalSpent() {
      return STARTING_BALANCE - this.balance;
    }

    get pctSpent() {
      return ((this.totalSpent / STARTING_BALANCE) * 100).toFixed(4);
    }

    buy(itemId, qty = 1) {
      const item = ITEMS.find(i => i.id === itemId);
      if (!item) return;
      const cost = item.price * qty;
      if (this.balance >= cost) {
        this.balance -= cost;
        this.inventory[itemId] += qty;
        this.updateUI();
      }
    }

    sell(itemId, qty = 1) {
      const item = ITEMS.find(i => i.id === itemId);
      if (!item) return;
      const current = this.inventory[itemId] || 0;
      const toSell = Math.min(current, qty);
      if (toSell > 0) {
        this.balance += item.price * toSell;
        this.inventory[itemId] -= toSell;
        this.updateUI();
      }
    }

    setQty(itemId, newQty) {
      const item = ITEMS.find(i => i.id === itemId);
      if (!item) return;
      const current = this.inventory[itemId] || 0;
      const target = Math.max(0, parseInt(newQty) || 0);
      const diff = target - current;
      if (diff > 0) {
        const cost = diff * item.price;
        if (cost <= this.balance) {
          this.balance -= cost;
          this.inventory[itemId] = target;
        } else {
          // Buy max possible
          const maxAffordable = Math.floor(this.balance / item.price);
          this.balance -= maxAffordable * item.price;
          this.inventory[itemId] += maxAffordable;
        }
      } else if (diff < 0) {
        const refund = Math.abs(diff) * item.price;
        this.balance += refund;
        this.inventory[itemId] = target;
      }
      this.updateUI();
    }

    reset() {
      this.balance = STARTING_BALANCE;
      ITEMS.forEach(item => {
        this.inventory[item.id] = 0;
      });
      this.updateUI();
      this.container.scrollIntoView({ behavior: 'smooth' });
    }

    render() {
      this.container.innerHTML = `
        <div class="spend-elon-wrapper" style="max-width: 1100px; margin: 0 auto; font-family: inherit;">
          
          <!-- Sticky Balance Banner -->
          <div class="spend-balance-bar" id="spendBalanceBar" style="
            position: sticky;
            top: 65px;
            z-index: 95;
            background: linear-gradient(135deg, #16213e, #0f0f1a);
            border: 2px solid #f9c74f;
            border-radius: 12px;
            padding: 18px 24px;
            margin-bottom: 25px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.5);
            text-align: center;
            backdrop-filter: blur(10px);
          ">
            <div style="font-size: 0.88rem; text-transform: uppercase; letter-spacing: 1.5px; color: #ffffff !important; font-weight: 800; margin-bottom: 6px;">
              🚀 Remaining Balance of Elon Musk's $1 Trillion Fortune
            </div>
            <div class="balance-display" id="balanceDisplay" style="
              font-size: clamp(2rem, 5vw, 3rem);
              font-weight: 900;
              color: #4ade80 !important;
              letter-spacing: -0.5px;
              line-height: 1.1;
              text-shadow: 0 0 25px rgba(74, 222, 128, 0.5) !important;
              transition: all 0.2s ease;
            ">
              ${formatMoney(this.balance)}
            </div>
            <div style="font-size: 1rem; color: #f9c74f !important; font-weight: 700; margin-top: 6px;" id="balanceInrDisplay">
              ≈ ${formatInrCrores(this.balance)}
            </div>
            
            <!-- Progress Bar -->
            <div style="margin-top: 14px; background: rgba(255,255,255,0.18); border-radius: 10px; height: 10px; overflow: hidden; position: relative;">
              <div id="spendProgressBar" style="
                width: ${this.pctSpent}%;
                height: 100%;
                background: linear-gradient(90deg, #f9c74f, #f94144);
                transition: width 0.3s ease;
              "></div>
            </div>
            <div style="display: flex; justify-content: space-between; font-size: 0.85rem; color: #ffffff !important; margin-top: 8px;">
              <span style="color: #ffffff !important;">Spent: <strong id="totalSpentText" style="color: #f9c74f !important; font-weight: 800;">${formatMoney(this.totalSpent)}</strong></span>
              <span style="color: #ffffff !important;">Spent %: <strong id="pctSpentText" style="color: #f87171 !important; font-weight: 800;">${this.pctSpent}%</strong></span>
            </div>
          </div>

          <!-- Items Grid -->
          <div class="spend-items-grid" style="
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
          ">
            ${ITEMS.map(item => this.renderCard(item)).join('')}
          </div>

          <!-- Receipt / Bill at the End -->
          <div class="spend-receipt-container" id="spendReceiptContainer" style="
            background: #ffffff;
            color: #111827;
            max-width: 600px;
            margin: 40px auto;
            padding: 30px 25px;
            border-radius: 8px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.6);
            font-family: 'Courier New', Courier, monospace;
            position: relative;
            border-top: 8px dashed #d1d5db;
            border-bottom: 8px dashed #d1d5db;
          ">
            <div style="text-align: center; border-bottom: 2px dashed #9ca3af; padding-bottom: 15px; margin-bottom: 20px;">
              <h2 style="font-size: 1.5rem; font-weight: 900; margin: 0 0 5px 0; color: #111827;">🧾 ELON MUSK $1T RECEIPT</h2>
              <p style="margin: 0; font-size: 0.85rem; color: #6b7280;">BillionaireWatch.in Wealth Simulator</p>
              <p style="margin: 2px 0 0 0; font-size: 0.75rem; color: #9ca3af;">Initial Funds: $1,000,000,000,000 USD</p>
            </div>

            <div id="receiptItemsList" style="min-height: 80px;">
              <p style="text-align: center; color: #6b7280; font-style: italic;">You haven't bought anything yet! Start spending Elon's money above.</p>
            </div>

            <div style="border-top: 2px dashed #9ca3af; margin-top: 20px; padding-top: 15px;">
              <div style="display: flex; justify-content: space-between; font-size: 1.1rem; font-weight: 900;">
                <span>TOTAL SPENT:</span>
                <span id="receiptTotal">$0</span>
              </div>
              <div style="display: flex; justify-content: space-between; font-size: 0.95rem; font-weight: 700; color: #059669; margin-top: 5px;">
                <span>REMAINING:</span>
                <span id="receiptRemaining">$1,000,000,000,000</span>
              </div>
            </div>

            <!-- Receipt Actions -->
            <div style="display: flex; gap: 10px; margin-top: 25px; flex-wrap: wrap;">
              <button type="button" id="btnCopyReceiptShare" style="
                flex: 1 1 100%;
                background: #2563eb;
                color: #ffffff;
                border: none;
                padding: 12px;
                border-radius: 6px;
                font-weight: 700;
                cursor: pointer;
                font-family: inherit;
                font-size: 0.9rem;
              ">📋 Copy &amp; Share My Receipt Challenge</button>
              <a id="btnProfileShareX" href="https://twitter.com/intent/tweet?text=Can%20you%20spend%20Elon%20Musk%27s%20%241%20Trillion%3F&url=https%3A%2F%2Fwww.billionairewatch.in%2Fspend-elon-money.html" target="_blank" rel="noopener noreferrer" style="
                flex: 1;
                background: #0f172a;
                color: #ffffff;
                text-decoration: none;
                padding: 12px;
                border-radius: 6px;
                font-weight: 700;
                text-align: center;
                font-family: inherit;
                font-size: 0.9rem;
              ">Share on X</a>
              <button type="button" id="btnResetSpend" style="
                flex: 1;
                background: #ef4444;
                color: #ffffff;
                border: none;
                padding: 12px;
                border-radius: 6px;
                font-weight: 700;
                cursor: pointer;
                font-family: inherit;
                font-size: 0.9rem;
              ">🔄 Reset</button>
              <button type="button" id="btnPrintReceipt" style="
                flex: 1;
                background: #10b981;
                color: #ffffff;
                border: none;
                padding: 12px;
                border-radius: 6px;
                font-weight: 700;
                cursor: pointer;
                font-family: inherit;
                font-size: 0.9rem;
              ">🖨️ Print</button>
            </div>
            <p id="profileShareCopiedToast" style="display:none; text-align:center; margin-top:10px; font-weight:700; font-size:0.85rem; color:#059669 !important;">Receipt copied! Share it anywhere to challenge friends.</p>
          </div>

        </div>
      `;

      this.attachEvents();
      this.updateUI();
    }

    renderCard(item) {
      const qty = this.inventory[item.id] || 0;
      return `
        <div class="spend-card" id="card-${item.id}" style="
          background: #16213e !important;
          border: 1.5px solid rgba(255,255,255,0.14) !important;
          border-radius: 12px !important;
          padding: 20px !important;
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          transition: transform 0.2s ease, box-shadow 0.2s ease;
        ">
          <div style="font-size: 3rem; margin-bottom: 8px; line-height: 1;">${item.icon}</div>
          <h3 style="font-size: 1.1rem; margin: 0 0 6px 0; color: #ffffff !important; font-weight: 700;">${item.name}</h3>
          <div style="font-size: 1.25rem; font-weight: 900; color: #4ade80 !important; margin-bottom: 2px;">
            ${formatMoney(item.price)}
          </div>
          <div style="font-size: 0.82rem; color: #f9c74f !important; font-weight: 600; margin-bottom: 15px;">
            ≈ ${formatInrCrores(item.price)}
          </div>

          <div style="display: flex; align-items: center; justify-content: center; width: 100%; gap: 8px; margin-top: auto;">
            <button type="button" class="btn-sell" data-id="${item.id}" style="
              background: #f87171;
              color: #111827;
              border: none;
              padding: 8px 14px;
              border-radius: 6px;
              font-weight: 800;
              cursor: pointer;
              transition: all 0.15s ease;
              ${qty <= 0 ? 'opacity: 0.4; cursor: not-allowed;' : ''}
            " ${qty <= 0 ? 'disabled' : ''}>Sell</button>

            <input type="number" min="0" class="input-qty" data-id="${item.id}" value="${qty}" style="
              width: 75px;
              text-align: center;
              padding: 8px 4px;
              border-radius: 6px;
              border: 1px solid rgba(255,255,255,0.2);
              background: rgba(0,0,0,0.3);
              color: #ffffff;
              font-weight: 700;
              font-size: 0.95rem;
            ">

            <button type="button" class="btn-buy" data-id="${item.id}" style="
              background: #4ade80;
              color: #111827;
              border: none;
              padding: 8px 14px;
              border-radius: 6px;
              font-weight: 800;
              cursor: pointer;
              transition: all 0.15s ease;
            ">Buy</button>
          </div>
        </div>
      `;
    }

    attachEvents() {
      // Delegate clicks for Buy/Sell
      this.container.addEventListener('click', (e) => {
        const buyBtn = e.target.closest('.btn-buy');
        if (buyBtn) {
          const id = buyBtn.getAttribute('data-id');
          this.buy(id, 1);
          return;
        }

        const sellBtn = e.target.closest('.btn-sell');
        if (sellBtn) {
          const id = sellBtn.getAttribute('data-id');
          this.sell(id, 1);
          return;
        }

        if (e.target.id === 'btnResetSpend') {
          this.reset();
          return;
        }

        if (e.target.id === 'btnCopyReceiptShare') {
          const topItems = ITEMS.filter(i => (this.inventory[i.id] || 0) > 0)
            .sort((a, b) => (b.price * this.inventory[b.id]) - (a.price * this.inventory[a.id]))
            .slice(0, 3)
            .map(i => `${this.inventory[i.id].toLocaleString()}x ${i.name}`)
            .join(', ');
          const msg = this.totalSpent > 0
            ? `I spent ${formatMoney(this.totalSpent)} (${this.pctSpent}%) of Elon Musk's $1 Trillion (${topItems}) and still have ${formatMoney(this.balance)} left! Play here: https://www.billionairewatch.in/spend-elon-money.html`
            : `Can you spend Elon Musk's $1 Trillion fortune? Play here: https://www.billionairewatch.in/spend-elon-money.html`;
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(msg).catch(() => {});
          }
          const toast = this.container.querySelector('#profileShareCopiedToast');
          if (toast) {
            toast.style.display = 'block';
            setTimeout(() => { toast.style.display = 'none'; }, 3000);
          }
          return;
        }

        if (e.target.id === 'btnPrintReceipt') {
          window.print();
          return;
        }
      });

      // Delegate change on inputs
      this.container.addEventListener('input', (e) => {
        if (e.target.classList.contains('input-qty')) {
          const id = e.target.getAttribute('data-id');
          this.setQty(id, e.target.value);
        }
      });
    }

    updateUI() {
      // 1. Balance
      const balEl = this.container.querySelector('#balanceDisplay');
      const balInrEl = this.container.querySelector('#balanceInrDisplay');
      const progEl = this.container.querySelector('#spendProgressBar');
      const spentText = this.container.querySelector('#totalSpentText');
      const pctText = this.container.querySelector('#pctSpentText');

      if (balEl) balEl.textContent = formatMoney(this.balance);
      if (balInrEl) balInrEl.textContent = `≈ ${formatInrCrores(this.balance)}`;
      if (progEl) progEl.style.width = `${this.pctSpent}%`;
      if (spentText) spentText.textContent = formatMoney(this.totalSpent);
      if (pctText) pctText.textContent = `${this.pctSpent}%`;

      // 2. Buttons & Inputs
      ITEMS.forEach(item => {
        const qty = this.inventory[item.id] || 0;
        const card = this.container.querySelector(`#card-${item.id}`);
        if (card) {
          const sellBtn = card.querySelector('.btn-sell');
          const buyBtn = card.querySelector('.btn-buy');
          const input = card.querySelector('.input-qty');

          if (input && document.activeElement !== input) {
            input.value = qty;
          }

          if (sellBtn) {
            sellBtn.disabled = qty <= 0;
            sellBtn.style.opacity = qty <= 0 ? '0.35' : '1';
            sellBtn.style.cursor = qty <= 0 ? 'not-allowed' : 'pointer';
          }

          if (buyBtn) {
            const canAfford = this.balance >= item.price;
            buyBtn.disabled = !canAfford;
            buyBtn.style.opacity = !canAfford ? '0.35' : '1';
            buyBtn.style.cursor = !canAfford ? 'not-allowed' : 'pointer';
          }
        }
      });

      // 3. Receipt
      const listEl = this.container.querySelector('#receiptItemsList');
      const receiptTotalEl = this.container.querySelector('#receiptTotal');
      const receiptRemainingEl = this.container.querySelector('#receiptRemaining');

      if (listEl) {
        const purchased = ITEMS.filter(i => (this.inventory[i.id] || 0) > 0);
        if (purchased.length === 0) {
          listEl.innerHTML = `<p style="text-align: center; color: #6b7280; font-style: italic;">You haven't bought anything yet! Start spending Elon's money above.</p>`;
        } else {
          listEl.innerHTML = `
            <table style="width: 100%; border-collapse: collapse; font-size: 0.88rem;">
              <tbody>
                ${purchased.map(i => {
                  const q = this.inventory[i.id];
                  const lineTotal = i.price * q;
                  return `
                    <tr style="border-bottom: 1px dotted #e5e7eb;">
                      <td style="padding: 6px 0;">${i.icon} ${i.name}</td>
                      <td style="padding: 6px 0; text-align: center; color: #6b7280;">x${q.toLocaleString()}</td>
                      <td style="padding: 6px 0; text-align: right; font-weight: 700;">${formatMoney(lineTotal)}</td>
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>
          `;
        }
      }

      if (receiptTotalEl) receiptTotalEl.textContent = formatMoney(this.totalSpent);
      if (receiptRemainingEl) receiptRemainingEl.textContent = formatMoney(this.balance);
    }
  }

  // Global initializer
  window.initSpendElonGame = function(selector) {
    const el = typeof selector === 'string' ? document.querySelector(selector) : selector;
    if (el) {
      return new SpendElonGame(el);
    }
  };

  // Auto initialize if container exists (handles both pre- and post-DOMContentLoaded)
  function autoInit() {
    const defaultEl = document.getElementById('spend-elon-game-container');
    if (defaultEl && !defaultEl.dataset.initialized) {
      defaultEl.dataset.initialized = 'true';
      window.initSpendElonGame(defaultEl);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', autoInit);
  } else {
    autoInit();
  }

})();
