/**
 * Netlify Scheduled Function: update-networth
 * Runs on schedule to check public FX rates and market quotes, and triggers a Netlify
 * Build Hook (if NETLIFY_BUILD_HOOK_URL is configured) to regenerate static pre-rendered HTML.
 */
exports.handler = async function () {
  const startedAt = new Date().toISOString();
  console.log('[BillionaireWatch Cron] Scheduled Net Worth check triggered at:', startedAt);

  let fxRate = null;
  try {
    const fxResp = await fetch('https://open.er-api.com/v6/latest/USD');
    if (fxResp.ok) {
      const fxJson = await fxResp.json();
      fxRate = fxJson?.rates?.INR ? Number(fxJson.rates.INR).toFixed(2) : null;
    }
  } catch (err) {
    console.warn('[BillionaireWatch Cron] FX check failed:', err.message);
  }

  let buildHookTriggered = false;
  if (process.env.NETLIFY_BUILD_HOOK_URL) {
    try {
      const hookResp = await fetch(process.env.NETLIFY_BUILD_HOOK_URL, { method: 'POST' });
      buildHookTriggered = hookResp.ok;
    } catch (err) {
      console.warn('[BillionaireWatch Cron] Build hook trigger failed:', err.message);
    }
  }

  return {
    statusCode: 200,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      ok: true,
      message: 'Scheduled public market & FX synchronization check executed.',
      fxUsdInr: fxRate,
      buildHookTriggered,
      timestamp: startedAt,
      nextRun: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
    }),
  };
};
