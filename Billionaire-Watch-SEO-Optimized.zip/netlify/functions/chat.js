/**
 * Netlify Serverless Function: /.netlify/functions/chat
 * Grounds responses in BillionaireWatch's cached SEC/BSE-derived dataset (data/billionaires.json),
 * open FX rates, and Google Search over official public filings. Zero scraping.
 */
const fs = require('fs');
const path = require('path');

function loadCachedDataset() {
  const candidates = [
    path.resolve(__dirname, '../../data/billionaires.json'),
    path.resolve(process.cwd(), 'data/billionaires.json'),
    path.resolve(process.cwd(), 'public/live-site/data/billionaires.json'),
  ];
  for (const filePath of candidates) {
    try {
      if (fs.existsSync(filePath)) {
        return JSON.parse(fs.readFileSync(filePath, 'utf8'));
      }
    } catch {
      // Try next candidate path
    }
  }
  return null;
}

exports.handler = async function (event) {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method Not Allowed' }) };
  }

  try {
    const { prompt } = JSON.parse(event.body || '{}');
    if (!prompt) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'Prompt is required' }) };
    }

    const apiKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_GENAI_API_KEY;
    if (!apiKey) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ reply: null, status: 'fallback-to-local' }),
      };
    }

    let liveSummary = '';
    try {
      const cached = loadCachedDataset();
      let fxRate = cached?.meta?.currencyUsdInrRate ? Number(cached.meta.currencyUsdInrRate) : 94.09;
      try {
        const fxRes = await fetch('https://open.er-api.com/v6/latest/USD');
        if (fxRes.ok) {
          const fxJson = await fxRes.json();
          if (fxJson?.rates?.INR) fxRate = Number(fxJson.rates.INR);
        }
      } catch {
        // Use cached FX rate
      }

      if (Array.isArray(cached?.billionaires) && cached.billionaires.length > 0) {
        const list = cached.billionaires
          .slice()
          .sort((a, b) => Number(b.netWorthUsd || 0) - Number(a.netWorthUsd || 0))
          .slice(0, 12)
          .map(
            (p, idx) =>
              `#${idx + 1} ${p.name}: $${Number(p.netWorthUsd || 0).toFixed(1)}B (${p.source || ''})`
          )
          .join('\n');
        liveSummary = `Cached Public-Filing Snapshot (1 USD = ₹${fxRate.toFixed(2)} INR):\n${list}`;
      }
    } catch {
      // Proceed without cached snapshot
    }

    const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-4-hydrogen:generateContent?key=${apiKey}`;
    const payload = {
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: `You are "BillionaireWatch AI". Use Google Search when needed to check official SEC Form 4, Schedule 13D, BSE/NSE shareholding disclosures, and public market quotes. Always provide USD Billion + Indian Rupee Crores/Lakh Crores and exact 1-based Global Rank, noting figures are independent educational estimates.\n\n${liveSummary}\n\nUser Question: ${prompt}`,
            },
          ],
        },
      ],
      tools: [{ google_search: {} }],
      generationConfig: {
        temperature: 0.25,
        maxOutputTokens: 700,
      },
    };

    const response = await fetch(geminiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'aistudio-build',
      },
      body: JSON.stringify(payload),
    });

    if (response.ok) {
      const result = await response.json();
      const text = result?.candidates?.[0]?.content?.parts?.[0]?.text;
      const chunks = result?.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      const sources = chunks
        .map((c) => (c.web?.uri ? { title: c.web.title || c.web.uri, url: c.web.uri } : null))
        .filter(Boolean);

      if (text) {
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({ reply: text, sources, source: 'gemini-google-search' }),
        };
      }
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ reply: null, status: 'fallback-to-local' }),
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message }),
    };
  }
};
