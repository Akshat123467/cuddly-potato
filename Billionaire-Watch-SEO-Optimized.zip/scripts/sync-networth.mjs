#!/usr/bin/env node
/**
 * BillionaireWatch.in - Compliant Scheduled Net Worth Pipeline
 *
 * Calculates real-time valuations from:
 *   - Public SEC Form 4 / Schedule 13D & BSE/NSE promoter shareholding counts (data/holdings-config.json)
 *   - Legal public market quotes (Finnhub / Alpha Vantage via env vars, or Yahoo Finance v8 chart JSON)
 *   - Public reference FX rates (open.er-api.com)
 *
 * Zero scraping of Forbes or Bloomberg. Includes TTL cache, error handling,
 * fallback to last-known-good data/billionaires.json, and post-sync static regeneration.
 */
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { runOgGeneration } from './generate-og-images.mjs';
import { generateSite } from './generate-site.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const SITE_ROOT = path.resolve(__dirname, '..');

async function fetchJsonWithTimeout(url, headers = {}, timeoutMs = 6000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const resp = await fetch(url, { headers, signal: controller.signal });
    if (!resp.ok) throw new Error(`HTTP ${resp.status} for ${url}`);
    return await resp.json();
  } finally {
    clearTimeout(timer);
  }
}

async function fetchFxRates(fallbackInr = 94.29, fallbackEurPerUsd = 0.925) {
  const endpoints = [
    'https://open.er-api.com/v6/latest/USD',
    'https://api.exchangerate-api.com/v4/latest/USD'
  ];
  for (const endpoint of endpoints) {
    try {
      const data = await fetchJsonWithTimeout(endpoint);
      const inr = Number(data?.rates?.INR);
      const eur = Number(data?.rates?.EUR);
      if (inr > 70 && inr < 125) {
        return {
          usdInr: parseFloat(inr.toFixed(2)),
          usdPerEur: eur > 0.5 && eur < 1.5 ? parseFloat((1 / eur).toFixed(4)) : 1 / fallbackEurPerUsd,
          fxUpdatedUtc: data.time_last_update_utc || new Date().toUTCString(),
          fxSource: endpoint
        };
      }
    } catch {
      // Fall through to next open FX endpoint
    }
  }
  return {
    usdInr: fallbackInr,
    usdPerEur: 1.08,
    fxUpdatedUtc: new Date().toUTCString(),
    fxSource: 'cached-fallback'
  };
}

async function fetchTickerQuote(ticker) {
  const cleanTicker = ticker.replace('.', '-'); // BRK.A -> BRK-A for Yahoo Finance

  // 1. Optional licensed Finnhub API key (US tickers without exchange suffix)
  if (process.env.FINNHUB_API_KEY && !ticker.includes('.')) {
    try {
      const url = `https://finnhub.io/api/v1/quote?symbol=${encodeURIComponent(ticker)}&token=${encodeURIComponent(process.env.FINNHUB_API_KEY)}`;
      const q = await fetchJsonWithTimeout(url);
      if (q && q.c > 0) {
        const prev = q.pc || q.c;
        const pct = prev > 0 ? ((q.c - prev) / prev) * 100 : 0;
        return { priceLocal: Number(q.c), dailyChangePct: parseFloat(pct.toFixed(2)), source: 'finnhub' };
      }
    } catch {
      // Fallback to Yahoo v8
    }
  }

  // 2. Public Yahoo Finance v8 Chart Endpoint
  const yhUrl = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(cleanTicker)}?range=5d&interval=1d`;
  const yh = await fetchJsonWithTimeout(yhUrl, {
    'User-Agent': 'BillionaireWatch-PublicDataSync/2.0',
    Accept: 'application/json'
  });
  const meta = yh?.chart?.result?.[0]?.meta;
  const price = Number(meta?.regularMarketPrice || meta?.previousClose || 0);
  const prevClose = Number(meta?.chartPreviousClose || meta?.previousClose || price);
  if (price > 0) {
    const pct = prevClose > 0 ? ((price - prevClose) / prevClose) * 100 : 0;
    return {
      priceLocal: price,
      dailyChangePct: parseFloat(pct.toFixed(2)),
      currency: meta?.currency || 'USD',
      source: 'yahoo-finance-v8'
    };
  }
  throw new Error(`No valid market quote returned for ${ticker}`);
}

export async function runSyncPipeline({ force = false, skipRegen = false } = {}) {
  const configPath = path.join(SITE_ROOT, 'data', 'holdings-config.json');
  const dataPath = path.join(SITE_ROOT, 'data', 'billionaires.json');

  const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  const previousJson = fs.existsSync(dataPath)
    ? JSON.parse(fs.readFileSync(dataPath, 'utf8'))
    : { meta: {}, billionaires: [] };

  const ttlMs = (Number(config.meta?.cacheTtlMinutes || 60)) * 60 * 1000;
  const prevTimestamp = Date.parse(previousJson.meta?.lastUpdated || '');
  if (!force && !Number.isNaN(prevTimestamp) && Date.now() - prevTimestamp < ttlMs) {
    console.log(`[Sync Pipeline] Cache fresh (updated ${previousJson.meta.lastUpdated}). Skipping external API fetch.`);
    if (!skipRegen) {
      runOgGeneration();
      generateSite();
    }
    return previousJson;
  }

  const prevMap = new Map((previousJson.billionaires || []).map((b) => [b.id, b]));
  const fx = await fetchFxRates(previousJson.meta?.currencyUsdInrRate || config.meta?.defaultUsdInrRate || 94.29);

  // Deduplicate public tickers across all 17 billionaire profiles
  const uniqueTickers = new Set();
  for (const b of config.billionaires) {
    for (const h of b.publicHoldings || []) {
      uniqueTickers.add(h.ticker);
    }
  }

  const quotes = new Map();
  let liveSuccessCount = 0;
  await Promise.all(
    Array.from(uniqueTickers).map(async (ticker) => {
      try {
        const quote = await fetchTickerQuote(ticker);
        quotes.set(ticker, quote);
        liveSuccessCount++;
      } catch {
        // Silent fallback handled per holding below
      }
    })
  );

  const updatedList = config.billionaires.map((cfg) => {
    const prevRecord = prevMap.get(cfg.id);
    let publicEquityB = 0;
    let vestedOptionsB = 0;
    let privateAssetsB = 0;
    let weightedChangeSum = 0;
    let weightedChangeWeight = 0;
    const disclosures = [];

    for (const h of cfg.publicHoldings || []) {
      const liveQuote = quotes.get(h.ticker);
      const hasLive = Boolean(liveQuote && liveQuote.priceLocal > 0);
      const rawPriceLocal = hasLive ? liveQuote.priceLocal : Number(h.fallbackPrice || 0);
      let priceUsd = rawPriceLocal;

      if (h.currency === 'INR') {
        priceUsd = rawPriceLocal / fx.usdInr;
      } else if (h.currency === 'EUR') {
        priceUsd = rawPriceLocal * fx.usdPerEur;
      }

      const pctChange = hasLive ? liveQuote.dailyChangePct : Number(cfg.baselineDailyChange || 0);

      const isOpt = h.exerciseOptionPrice !== null && h.exerciseOptionPrice !== undefined;
      const spread = isOpt ? Math.max(0, priceUsd - Number(h.exerciseOptionPrice)) : priceUsd;
      const valB = (Number(h.shares) * spread) / 1e9;

      if (isOpt) vestedOptionsB += valB;
      else publicEquityB += valB;

      weightedChangeSum += valB * pctChange;
      weightedChangeWeight += valB;

      disclosures.push({
        companyName: h.companyName,
        ticker: h.ticker,
        exchange: h.exchange,
        shares: h.shares,
        priceUsd: parseFloat(priceUsd.toFixed(2)),
        exerciseOptionPriceUsd: isOpt ? Number(h.exerciseOptionPrice) : null,
        isOption: isOpt,
        valueBillions: parseFloat(valB.toFixed(2))
      });
    }

    for (const p of cfg.privateAndOptionHoldings || []) {
      const valB = Number(p.valueBillions || 0);
      if (p.isOption) vestedOptionsB += valB;
      else privateAssetsB += valB;
      disclosures.push({ ...p });
    }

    disclosures.sort((a, b) => Number(b.valueBillions) - Number(a.valueBillions));

    const totalB = parseFloat((publicEquityB + vestedOptionsB + privateAssetsB).toFixed(1));
    const finalWorthB = totalB > 0 ? totalB : Number(prevRecord?.netWorthUsd || cfg.baselineNetWorthUsd || 0);
    const inrCrore = Math.round(finalWorthB * fx.usdInr * 100);
    const avgDaily = weightedChangeWeight > 0
      ? parseFloat((weightedChangeSum / weightedChangeWeight).toFixed(2))
      : Number(prevRecord?.dailyChange || cfg.baselineDailyChange || 0);

    return {
      id: cfg.id,
      name: cfg.name,
      globalRank: 0,
      countryRank: 0,
      country: cfg.country,
      countryName: cfg.countryName,
      netWorthUsd: finalWorthB,
      publicEquityUsd: parseFloat(publicEquityB.toFixed(1)),
      vestedOptionsUsd: parseFloat(vestedOptionsB.toFixed(1)),
      privateAssetsUsd: parseFloat(privateAssetsB.toFixed(1)),
      netWorthInrCrore: inrCrore,
      dailyChange: avgDaily,
      source: cfg.source,
      age: cfg.age,
      profileUrl: `profiles/${cfg.id}.html`,
      hasDedicatedProfile: true,
      tickers: (cfg.publicHoldings || []).map((h) => h.ticker),
      primaryHoldingShare: (cfg.publicHoldings || []).map((h) => `${h.companyName} (${h.ticker})`).join(', '),
      bio: cfg.bio,
      disclosures
    };
  });

  // Strict descending numerical sort and 1-based global & country ranks
  updatedList.sort((a, b) => Number(b.netWorthUsd) - Number(a.netWorthUsd));
  const cCount = {};
  updatedList.forEach((b, idx) => {
    b.globalRank = idx + 1;
    cCount[b.country] = (cCount[b.country] || 0) + 1;
    b.countryRank = cCount[b.country];
  });

  const nowIso = new Date().toISOString();
  const nextJson = {
    meta: {
      title: 'BillionaireWatch.in Independent Wealth Index',
      lastUpdated: nowIso,
      nextScheduledUpdate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
      updateFrequencyMinutes: 60,
      currencyUsdInrRate: fx.usdInr,
      fxUpdatedUtc: fx.fxUpdatedUtc,
      liveQuotesResolved: liveSuccessCount,
      totalTrackedTickers: uniqueTickers.size,
      status: liveSuccessCount > 0 ? 'synchronized-live-quotes' : 'synchronized-cached-fallback',
      source: 'SEC EDGAR (Form 4 / Schedule 13D), BSE/NSE Promoter Disclosures & Open Equity/FX APIs',
      sortOrder: 'numerical-descending-by-netWorthUsd'
    },
    billionaires: updatedList
  };

  fs.writeFileSync(dataPath, JSON.stringify(nextJson, null, 2) + '\n', 'utf8');
  console.log(`[Sync Pipeline] Wrote data/billionaires.json (${liveSuccessCount}/${uniqueTickers.size} live ticker quotes, 1 USD = ₹${fx.usdInr}).`);

  if (!skipRegen) {
    runOgGeneration();
    generateSite();
  }

  return nextJson;
}

if (process.argv[1] && path.resolve(process.argv[1]) === __filename) {
  const force = process.argv.includes('--force');
  runSyncPipeline({ force }).catch((err) => {
    console.error('[Sync Pipeline] Fatal error:', err);
    process.exit(1);
  });
}
