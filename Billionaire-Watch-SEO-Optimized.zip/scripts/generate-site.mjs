#!/usr/bin/env node
/**
 * BillionaireWatch.in - Static Pre-Renderer & Multi-Page Profile Generator
 *
 * Reads synchronized public valuations from data/billionaires.json and filings metadata
 * from data/holdings-config.json to:
 *   1. Generate all 17 individual billionaire profile pages (profiles/<id>.html)
 *   2. Pre-render full crawler-accessible HTML inside index.html (plus <noscript> table & JSON-LD)
 *   3. Update sitemap.xml & robots.txt with accurate lastmod timestamps
 */
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const SITE_ROOT = path.resolve(__dirname, '..');

function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function formatInrCrores(crores) {
  if (Number.isNaN(Number(crores))) return '0';
  const rounded = Math.round(Number(crores)).toString();
  let lastThree = rounded.slice(-3);
  const rest = rounded.slice(0, -3);
  if (rest !== '') lastThree = ',' + lastThree;
  return rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + lastThree;
}

function formatInrLakhCr(crores) {
  const num = Number(crores || 0);
  const lakhCr = num / 100000;
  if (lakhCr >= 1) return `₹${lakhCr.toFixed(2)} Lakh Cr`;
  return `₹${formatInrCrores(num)} Cr`;
}

function formatHumanDate(iso) {
  try {
    return new Date(iso).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      timeZone: 'UTC'
    });
  } catch {
    return String(iso).slice(0, 10);
  }
}

function formatShortUtc(iso) {
  try {
    const d = new Date(iso);
    return `${d.toISOString().slice(0, 10)} ${d.toISOString().slice(11, 16)} UTC`;
  } catch {
    return String(iso).slice(0, 10);
  }
}

function buildElonDeepDive(elon, allMerged) {
  const topPeers = allMerged.slice(1, 4);
  const muskWorth = Number(elon.netWorthUsd).toFixed(1);
  const cardsHtml = topPeers.map((p) => {
    const diff = Math.max(0, elon.netWorthUsd - p.netWorthUsd).toFixed(1);
    return `
      <div style="background:#0f0f1a; padding:16px; border-radius:10px; text-align:center; border:1px solid rgba(249,199,79,0.25);">
        <h4 style="margin:0 0 8px 0;">#${p.globalRank}: ${escapeHtml(p.name)}</h4>
        <p style="font-size:1.45rem; font-weight:800; margin:4px 0;">$${Number(p.netWorthUsd).toFixed(1)}B</p>
        <p style="margin:4px 0 0; font-size:0.88rem;">~$${diff}B behind #1</p>
      </div>
    `;
  }).join('\n');

  return `
        <section class="spend-game-section" style="margin: 34px 0; background: linear-gradient(135deg, rgba(22, 33, 62, 0.96), rgba(15, 15, 26, 0.96)); border: 2px solid #f9c74f; border-radius: 14px; padding: 28px 20px;">
            <div style="text-align: center; margin-bottom: 22px;">
                <span style="background: rgba(249, 199, 79, 0.18); font-weight: 800; font-size: 0.8rem; padding: 4px 14px; border-radius: 20px; text-transform: uppercase;">Interactive Wealth Simulator</span>
                <h2 style="margin: 12px 0 8px 0;">Spend Elon Musk's Fortune Interactive Calculator</h2>
                <p style="max-width: 720px; margin: 0 auto; font-size: 0.95rem;">
                    At an estimated $${muskWorth}B USD valuation across SpaceX, Tesla, and xAI, test how much capital it takes to deploy sovereign-scale wealth across rockets, real estate, sports teams, and global infrastructure.
                </p>
            </div>
            <div id="spend-elon-game-container"></div>
        </section>

        <section class="tesla-transformation">
            <h2><i class="fas fa-robot"></i> Tesla Strategic Valuation Drivers: Robotics, Autonomy &amp; Energy</h2>
            <p>Tesla represents Musk's largest publicly traded stake, valued daily against NASDAQ closing prices and disclosed SEC Form 4 shareholdings. Equity analysts weigh automotive gross margins alongside stationary energy storage deployments (Megapack) and autonomous fleet software rollouts.</p>
            <div class="insight-box">
                <h3>Key Sensitivity Variables</h3>
                <p>Every $10 move in Tesla share price alters Musk's disclosed public equity by roughly $3.96 billion, making public market multiples and AI/robotics execution the dominant driver of short-term daily variance.</p>
            </div>
        </section>

        <section class="starlink-strategy">
            <h2><i class="fas fa-satellite"></i> SpaceX &amp; Starlink Commercial Cash-Flow Engine</h2>
            <p>Private equity tender transactions make SpaceX common stock and vested option spreads the anchor of Musk's balance sheet. Recurring broadband revenue from Starlink's global subscriber base alongside Starship launch cadence form the core benchmark behind secondary market pricing.</p>
        </section>

        <section class="competitive-analysis">
            <h2><i class="fas fa-trophy"></i> Comparative Gap vs. Global Peers</h2>
            <p>Comparison of Musk's current $${muskWorth}B valuation against the next three highest-ranked global billionaires:</p>
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr)); gap:15px; margin:18px 0;">
                ${cardsHtml}
            </div>
        </section>
  `;
}

function buildDisclosuresRows(person) {
  const list = Array.isArray(person.disclosures) && person.disclosures.length > 0
    ? person.disclosures
    : [];

  if (list.length === 0) {
    return `<tr><td colspan="5">Disclosed holdings consolidated under primary ${escapeHtml(person.source)} equity stakes ($${Number(person.netWorthUsd).toFixed(1)}B USD).</td></tr>`;
  }

  return list.map((d) => {
    const sharesText = d.shares > 100
      ? Number(d.shares).toLocaleString('en-US')
      : (d.isOption ? 'Option Pool' : 'Private Controlling Stake');
    const priceText = d.priceUsd < 100000
      ? `$${Number(d.priceUsd).toFixed(2)}${d.isOption && d.exerciseOptionPriceUsd !== null ? ` (Strike: $${Number(d.exerciseOptionPriceUsd).toFixed(2)})` : ''}`
      : 'Tender / Peer Benchmark';
    const badge = d.isOption ? ' <small>(Vested Option Spread)</small>' : '';
    return `<tr>
      <td><strong>${escapeHtml(d.companyName)}</strong>${badge}</td>
      <td>${escapeHtml(d.ticker || 'PRIVATE')} &bull; ${escapeHtml(d.exchange || 'Benchmark')}</td>
      <td>${sharesText}</td>
      <td>${priceText}</td>
      <td><strong>$${Number(d.valueBillions).toFixed(2)}B</strong></td>
    </tr>`;
  }).join('\n');
}

function buildRelatedCard(p, showCountryRank) {
  const rankLine = p.country === 'IN' && showCountryRank
    ? `#${p.countryRank} in India &bull; Global #${p.globalRank}`
    : `Global #${p.globalRank} &bull; ${escapeHtml(p.countryName || p.country)}`;
  return `
    <a href="${p.id}.html" class="related-card">
      <div class="related-card-title">${escapeHtml(p.name)} &mdash; $${Number(p.netWorthUsd).toFixed(1)}B</div>
      <div class="related-card-meta">${rankLine} &bull; ${escapeHtml(p.source)}</div>
    </a>
  `;
}

function renderCardHtml(person, maxVal, fxRate, gridType) {
  const isIndia = gridType === 'india';
  const isUsa = gridType === 'usa';
  const globalRank = Number(person.globalRank);
  const regionalRank = Number(person.countryRank || globalRank);
  const badgeRank = isIndia || isUsa ? regionalRank : globalRank;
  const usdVal = Number(person.netWorthUsd).toFixed(1);
  const inrCr = person.netWorthInrCrore || Math.round(person.netWorthUsd * fxRate * 100);
  const lakhCrText = formatInrLakhCr(inrCr);
  const dailyNum = Number(person.dailyChange || 0);
  const isProfit = dailyNum >= 0;
  const changeClass = isProfit ? 'up' : 'down';
  const changeIcon = isProfit ? 'arrow-up' : 'arrow-down';
  const sign = isProfit ? '+' : '';
  const deltaUsdVal = ((Number(person.netWorthUsd) * dailyNum) / 100).toFixed(1);
  const barWidth = Math.min(100, Math.max(8, (Number(person.netWorthUsd) / maxVal) * 100));

  const rankSubline = isIndia
    ? `Rank #${regionalRank} in India &bull; Global #${globalRank}`
    : (isUsa ? `US #${regionalRank} &bull; Global Rank #${globalRank}` : `Global Rank #${globalRank}`);

  const badgeStyle = isIndia
    ? 'background: #ff9933; color: #1a1a2e; width: auto; padding: 3px 12px; border-radius: 20px; font-size: 0.82rem; font-weight: 800;'
    : '';
  const badgeText = isIndia ? `#${badgeRank} 🇮🇳` : `#${badgeRank}`;

  const netWorthHtml = isIndia
    ? `<p class="net-worth" style="font-size: 1.55rem; font-weight: 800; color: #ff9933; margin: 0.35rem 0 0.15rem 0; line-height: 1.25;">
         ₹${formatInrCrores(inrCr)} <span style="font-size:0.75rem;">Crores</span>
         <span class="inr-subtext" style="display:block; font-size:0.84rem; font-weight:700; color:#f9c74f; margin-top:4px;">≈ ${lakhCrText} ($${usdVal}B USD)</span>
         <span style="display:block; font-size:0.76rem; font-weight:700; opacity:0.9; color:var(--text); margin-top:3px;">${rankSubline}</span>
       </p>`
    : `<p class="net-worth" style="font-size: 1.55rem; font-weight: 800; color: #FFA500; margin: 0.35rem 0 0.15rem 0; line-height: 1.25;">
         $${usdVal}B USD
         <span style="display:block; font-size:0.78rem; font-weight:700; opacity:0.9; color:var(--text); margin-top:4px;">${rankSubline}</span>
       </p>`;

  return `
    <article class="billionaire-card" data-billionaire-id="${escapeHtml(person.id)}" ${isIndia ? 'style="border-top: 3px solid #ff9933;"' : ''}>
      <div class="rank-badge" style="${badgeStyle}" title="Global Rank #${globalRank}">${badgeText}</div>
      <a href="profiles/${escapeHtml(person.id)}.html" title="Read ${escapeHtml(person.name)} net worth analysis" style="display:block; text-align:center;">
        <img src="images/avatars/${escapeHtml(person.id)}.jpg" width="90" height="90" class="profile-img" alt="${escapeHtml(person.name)} net worth profile" loading="lazy" decoding="async">
      </a>
      ${globalRank === 1 ? '<div class="crown-animation"><i class="fas fa-crown"></i></div>' : ''}
      <div class="wealth-meter">
        <div class="wealth-bar" style="width: ${barWidth.toFixed(1)}%; background: ${isIndia ? 'linear-gradient(90deg, #ff9933, #4ade80)' : 'linear-gradient(90deg, #FFA500, #ff9a00)'};"></div>
      </div>
      <div class="wealth-change ${changeClass}">
        <i class="fas fa-${changeIcon}"></i> ${sign}${dailyNum.toFixed(2)}% today
        <span style="font-size:0.75rem; opacity:0.85; margin-left:4px;">(${sign}$${Math.abs(Number(deltaUsdVal)).toFixed(1)}B)</span>
      </div>
      <a href="profiles/${escapeHtml(person.id)}.html" title="${escapeHtml(person.name)} wealth breakdown" style="text-decoration:none; color:inherit;">
        <h3 style="color: var(--accent);">${escapeHtml(person.name)}</h3>
      </a>
      ${netWorthHtml}
      <p class="primary-source" style="font-size: 0.86rem; color: var(--text); opacity: 0.9;">${escapeHtml(person.source)}</p>
      <div class="growth-trend-slot" data-sparkline-id="${escapeHtml(person.id)}"></div>
      <div class="button-container" style="display: flex; flex-direction: column; gap: 8px; margin-top: auto; padding-top: 12px;">
        <a href="profiles/${escapeHtml(person.id)}.html" class="btn btn-primary open-profile-btn" style="display: flex; align-items: center; justify-content: center; gap: 8px; font-weight: 800; padding: 10px 14px; text-decoration: none; border-radius: 8px; font-size: 0.9rem; ${isIndia ? 'background:#ff9933; color:#1a1a2e; border:none;' : ''}">
          <i class="fas fa-id-card"></i> ${escapeHtml(person.name)} Wealth Profile &rarr;
        </a>
        <button type="button" class="btn btn-secondary learn-more-btn" data-id="${escapeHtml(person.id)}" onclick="if(window.showProfileModal){window.showProfileModal('${escapeHtml(person.id)}');}" style="background-color: var(--secondary); color: var(--text); border: 1px solid rgba(255,255,255,0.22); font-size:0.84rem; padding:7px 10px; display:flex; align-items:center; justify-content:center; gap:6px; border-radius:6px; cursor:pointer;">
          <i class="fas fa-chart-bar"></i> Quick Chart &amp; Disclosures
        </button>
      </div>
      <span class="country-flag" aria-label="Country: ${escapeHtml(person.countryName || person.country)}" style="display:inline-flex; align-items:center; justify-content:center; font-size:0.72rem; font-weight:800; background:#1a1a2e; color:#f9c74f; border:1px solid rgba(249,199,79,0.45); border-radius:4px; padding:2px 6px;">${escapeHtml(person.country)}</span>
    </article>
  `;
}

function buildHomepageMainHtml(mergedList, meta) {
  const fxRate = Number(meta.currencyUsdInrRate || 94.29).toFixed(2);
  const lastUpdatedIso = meta.lastUpdated || new Date().toISOString();
  const lastUpdatedHuman = formatHumanDate(lastUpdatedIso);
  const lastUpdatedShort = formatShortUtc(lastUpdatedIso);

  const globalTop10 = mergedList.slice(0, 10);
  const indiaTop = mergedList.filter((b) => b.country === 'IN').slice(0, 5);
  const usaTop5 = mergedList.filter((b) => b.country === 'US').slice(0, 5);

  const globalCards = globalTop10.map((p) => renderCardHtml(p, globalTop10[0].netWorthUsd, fxRate, 'global')).join('\n');
  const indiaCards = indiaTop.map((p) => renderCardHtml(p, indiaTop[0].netWorthUsd, fxRate, 'india')).join('\n');
  const usaCards = usaTop5.map((p) => renderCardHtml(p, usaTop5[0].netWorthUsd, fxRate, 'usa')).join('\n');

  const top1India = indiaTop[0];
  const top2India = indiaTop[1];
  const indiaGapUsd = (top1India.netWorthUsd - top2India.netWorthUsd).toFixed(1);
  const indiaGapCr = formatInrCrores(top1India.netWorthInrCrore - top2India.netWorthInrCrore);
  const indiaTop5CombinedUsd = indiaTop.reduce((sum, b) => sum + Number(b.netWorthUsd || 0), 0).toFixed(1);
  const indiaTop5CombinedCr = formatInrCrores(indiaTop.reduce((sum, b) => sum + Number(b.netWorthInrCrore || 0), 0));

  const top10ListItems = globalTop10.map((b) => {
    return `<li><a href="profiles/${escapeHtml(b.id)}.html" style="font-weight:700;">#${b.globalRank} ${escapeHtml(b.name)}</a> &ndash; $${Number(b.netWorthUsd).toFixed(1)} billion USD &bull; ${escapeHtml(b.source)}</li>`;
  }).join('\n');

  const noscriptRows = mergedList.map((b) => `
    <tr>
      <td>#${b.globalRank}</td>
      <td><a href="profiles/${escapeHtml(b.id)}.html">${escapeHtml(b.name)}</a></td>
      <td>${escapeHtml(b.countryName || b.country)}</td>
      <td>${b.age ?? 'N/A'}</td>
      <td>$${Number(b.netWorthUsd).toFixed(1)}B</td>
      <td>₹${formatInrCrores(b.netWorthInrCrore)} Cr</td>
      <td>${escapeHtml(b.source)}</td>
    </tr>
  `).join('\n');

  const musk = mergedList[0];

  return `
    <!-- PRERENDERED_MAIN_START -->
    <section class="intro-content">
      <h1>Billionaire Net Worth Index 2026 &ndash; Global &amp; India Rankings</h1>
      <p>BillionaireWatch.in tracks estimated net worth across global and Indian business leaders using disclosed beneficial shareholdings from <strong>SEC EDGAR (Form 4 &amp; Schedule 13D)</strong>, <strong>BSE/NSE promoter filings</strong>, public equity market prices, and benchmark private-company tender rounds. Updated snapshot as of <time datetime="${escapeHtml(lastUpdatedIso)}">${lastUpdatedHuman}</time>.</p>
      <div class="analysis-buttons-intro" style="display: flex; justify-content: center; gap: 15px; margin-top: 24px; flex-wrap: wrap;">
        <a href="#global" class="analysis-btn global-btn" style="padding: 12px 24px; font-size: 1rem; border-radius: 8px;"><i class="fas fa-globe"></i> Global Top 10</a>
        <a href="#india" class="analysis-btn india-btn" style="padding: 12px 26px; font-size: 1rem; border-radius: 8px; background: linear-gradient(135deg, #ff9933, #ff5722); font-weight: 700;"><i class="fas fa-flag"></i> Indian Billionaires (₹ Crores)</a>
        <a href="#usa" class="analysis-btn usa-btn" style="padding: 12px 24px; font-size: 1rem; border-radius: 8px;"><i class="fas fa-flag-usa"></i> US Top 5</a>
        <a href="spend-elon-money.html" class="analysis-btn" style="padding: 12px 26px; font-size: 1rem; border-radius: 8px; background: linear-gradient(135deg, #10b981, #059669); color: #ffffff !important; font-weight: 800;"><i class="fas fa-gamepad"></i> Play Spend $1 Trillion Game</a>
        <a href="tools/wealth-blueprint.html" class="analysis-btn" style="padding: 12px 26px; font-size: 1rem; border-radius: 8px; background: linear-gradient(135deg, #facc15, #eab308); color: #0b0f19 !important; font-weight: 800;"><i class="fas fa-calculator"></i> Wealth Blueprint Simulator</a>
      </div>
    </section>

    <section id="global" style="scroll-margin-top: 80px;">
      <div class="section-header">
        <h2>World's Top 10 Richest People &mdash; ${escapeHtml(lastUpdatedHuman)} Snapshot</h2>
        <button type="button" class="btn btn-primary refresh-btn" id="refresh-global"><i class="fas fa-sync-alt"></i> Refresh Cached Feed</button>
      </div>
      <div class="billionaire-grid" id="global-billionaires">
        ${globalCards}
      </div>
      <p style="text-align: center; margin-top: 18px; color: var(--neutral);">Independent educational valuation estimates calculated from public regulatory share counts and exchange closing prices. Not financial advice.</p>
    </section>

    <section class="info-section" id="spend-elon-promo" style="background: var(--card-bg); border: 2px solid #10b981; border-radius: 14px; padding: 26px 22px; margin: 26px 0; text-align: center; box-shadow: var(--shadow);">
      <span style="display: inline-block; background: #065f46; color: #ffffff !important; border: 1px solid #10b981; border-radius: 20px; padding: 4px 14px; font-size: 0.78rem; font-weight: 800; letter-spacing: 0.6px; text-transform: uppercase; margin-bottom: 10px;">Viral Interactive Challenge &bull; 60s Speedrun Mode</span>
      <h2 style="margin: 0 0 10px 0; color: var(--accent); font-size: clamp(1.35rem, 3vw, 2rem);">Can You Spend $1,000,000,000,000 in 60 Seconds?</h2>
      <p style="max-width: 720px; margin: 0 auto 20px auto; color: var(--text); font-size: 0.98rem;">Try our flagship <strong>Spend $1 Trillion Dollars</strong> simulator! Bulk-buy <strong>×100 SpaceX Starships</strong>, NBA &amp; IPL teams, private islands, Nvidia AI clusters, or Big Macs &mdash; then share your speedrun score and receipt.</p>
      <div style="display: flex; justify-content: center; gap: 12px; flex-wrap: wrap;">
        <a href="spend-elon-money.html" class="btn" style="display: inline-flex; align-items: center; gap: 10px; background: linear-gradient(135deg, #10b981, #059669); color: #ffffff !important; padding: 13px 26px; border-radius: 10px; font-size: 1rem; font-weight: 800; text-decoration: none;">
          <i class="fas fa-gamepad"></i> Play Spend $1 Trillion Game &rarr;
        </a>
        <a href="tools/wealth-blueprint.html" class="btn" style="display: inline-flex; align-items: center; gap: 10px; background: linear-gradient(135deg, #facc15, #eab308); color: #0b0f19 !important; padding: 13px 26px; border-radius: 10px; font-size: 1rem; font-weight: 800; text-decoration: none;">
          <i class="fas fa-calculator"></i> Launch Wealth Blueprint Simulator &rarr;
        </a>
      </div>
    </section>

    <section class="country-section" id="india" style="scroll-margin-top: 85px; border-radius: 14px; padding: 25px; border: 1px solid rgba(255, 153, 51, 0.25);">
      <div class="country-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; border-bottom: 2px solid #ff9933; padding-bottom: 16px; margin-bottom: 22px;">
        <div>
          <h2 style="margin: 0; font-size: clamp(1.4rem, 3vw, 2rem); color: #ff9933;">Top Indian Billionaires 2026 (INR Crores &amp; USD)</h2>
          <p style="margin: 6px 0 0; font-size: 0.9rem; opacity: 0.9;">Promoter holdings across Reliance Industries, Adani Group, O.P. Jindal Group, HCL Tech, ArcelorMittal &amp; Sun Pharma synced to live market exchange rates.</p>
        </div>
      </div>

      <div class="india-stats-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 14px; margin-bottom: 24px;">
        <div style="background: rgba(255,153,51,0.08); border: 1px solid rgba(255,153,51,0.25); border-left: 4px solid #ff9933; border-radius: 10px; padding: 12px 16px;">
          <div style="font-size: 0.72rem; text-transform: uppercase; color: #ffb366; font-weight: 700;">#1 In India (Global #${top1India.globalRank})</div>
          <div style="font-size: 1.25rem; font-weight: 800; color: #ff9933; margin: 3px 0 1px;">${escapeHtml(top1India.name)}</div>
          <div style="font-size: 0.85rem; font-weight: 600;">₹${formatInrCrores(top1India.netWorthInrCrore)} Cr ($${Number(top1India.netWorthUsd).toFixed(1)}B)</div>
        </div>
        <div style="background: rgba(58,134,255,0.08); border: 1px solid rgba(58,134,255,0.25); border-left: 4px solid #3a86ff; border-radius: 10px; padding: 12px 16px;">
          <div style="font-size: 0.72rem; text-transform: uppercase; color: #70a5ff; font-weight: 700;">#2 In India (Global #${top2India.globalRank})</div>
          <div style="font-size: 1.25rem; font-weight: 800; color: #3a86ff; margin: 3px 0 1px;">${escapeHtml(top2India.name)}</div>
          <div style="font-size: 0.85rem; font-weight: 600;">₹${formatInrCrores(top2India.netWorthInrCrore)} Cr ($${Number(top2India.netWorthUsd).toFixed(1)}B)</div>
        </div>
        <div style="background: rgba(74,222,128,0.08); border: 1px solid rgba(74,222,128,0.25); border-left: 4px solid #4ade80; border-radius: 10px; padding: 12px 16px;">
          <div style="font-size: 0.72rem; text-transform: uppercase; color: #86efac; font-weight: 700;">#1 vs #2 India Margin</div>
          <div style="font-size: 1.25rem; font-weight: 800; color: #4ade80; margin: 3px 0 1px;">₹${indiaGapCr} Cr</div>
          <div style="font-size: 0.85rem; font-weight: 600;">$${indiaGapUsd}B USD Margin</div>
        </div>
        <div style="background: rgba(249,199,79,0.08); border: 1px solid rgba(249,199,79,0.25); border-left: 4px solid #f9c74f; border-radius: 10px; padding: 12px 16px;">
          <div style="font-size: 0.72rem; text-transform: uppercase; color: #fde047; font-weight: 700;">India Top 5 Combined</div>
          <div style="font-size: 1.25rem; font-weight: 800; color: #f9c74f; margin: 3px 0 1px;">₹${indiaTop5CombinedCr} Cr</div>
          <div style="font-size: 0.85rem; font-weight: 600;">$${indiaTop5CombinedUsd}B USD Total</div>
        </div>
      </div>

      <div class="billionaire-grid" id="india-billionaires">
        ${indiaCards}
      </div>
    </section>

    <section class="country-section" id="usa" style="scroll-margin-top: 85px;">
      <div class="country-header">
        <h2>Top 5 United States Billionaires &mdash; SEC Filing Valuations</h2>
      </div>
      <p style="margin-bottom: 20px;">Direct equity and vested option estimates calculated from US SEC beneficial ownership reports and NASDAQ/NYSE prices.</p>
      <div class="billionaire-grid" id="usa-billionaires">
        ${usaCards}
      </div>
    </section>

    <noscript>
      <section class="info-section" id="noscript-directory" style="overflow-x:auto; border: 2px solid #f9c74f; padding: 20px; border-radius: 12px; margin: 24px 0;">
        <h2>Complete Audited Billionaire Net Worth Directory (No-JavaScript View)</h2>
        <p>JavaScript is disabled in your browser. Below is the complete pre-rendered table of all tracked global and Indian wealth profiles updated <time datetime="${escapeHtml(lastUpdatedIso)}">${lastUpdatedHuman}</time>:</p>
        <table style="width:100%; border-collapse:collapse; margin-top:12px;">
          <thead>
            <tr>
              <th style="text-align:left; padding:8px; border-bottom:2px solid #f9c74f;">Global Rank</th>
              <th style="text-align:left; padding:8px; border-bottom:2px solid #f9c74f;">Billionaire Profile</th>
              <th style="text-align:left; padding:8px; border-bottom:2px solid #f9c74f;">Country</th>
              <th style="text-align:left; padding:8px; border-bottom:2px solid #f9c74f;">Age</th>
              <th style="text-align:left; padding:8px; border-bottom:2px solid #f9c74f;">Net Worth (USD)</th>
              <th style="text-align:left; padding:8px; border-bottom:2px solid #f9c74f;">Net Worth (INR)</th>
              <th style="text-align:left; padding:8px; border-bottom:2px solid #f9c74f;">Primary Holdings</th>
            </tr>
          </thead>
          <tbody>
            ${noscriptRows}
          </tbody>
        </table>
      </section>
    </noscript>

    <section class="info-section" id="richest-people">
      <h2>Top 10 Richest Individuals Worldwide (${escapeHtml(lastUpdatedHuman)})</h2>
      <p>As of <time datetime="${escapeHtml(lastUpdatedIso)}">${lastUpdatedHuman}</time>, <strong>${escapeHtml(musk.name)}</strong> ranks #1 globally at <strong>$${Number(musk.netWorthUsd).toFixed(1)} billion USD</strong>. Select any individual profile below for full public shareholding disclosures and 10-year historical charts:</p>
      <ul>
        ${top10ListItems}
      </ul>
      <p>All estimates are independent calculations from regulatory disclosures. Review our <a href="about.html#methodology">editorial methodology and sources overview</a>.</p>
    </section>

    <section class="info-section" id="net-worth-methodology">
      <h2>Independent Net Worth Calculation Methodology</h2>
      <p>BillionaireWatch.in publishes independent mathematical estimates computed from primary regulatory documents and open market data (without affiliation to Forbes Media or Bloomberg L.P.):</p>
      <ul>
        <li><strong>Public Company Stakes:</strong> Share counts reported on SEC EDGAR (Form 4, Schedule 13D/13G) and Indian BSE/NSE promoter filings multiplied by closing exchange quotes.</li>
        <li><strong>Vested Performance Options:</strong> In-the-money spread computed as (Market Price &minus; Option Strike Price) &times; vested option count.</li>
        <li><strong>Private Company Holdings:</strong> Benchmarked against disclosed tender offers, primary institutional financing rounds, and comparable listed multiples.</li>
        <li><strong>Currency Conversion:</strong> Reference USD/INR exchange rates (${fxRate} INR per USD as of this snapshot) applied consistently across global and Indian profiles.</li>
      </ul>
    </section>

    <section class="info-section" id="trending-faq">
      <h2>Frequently Asked Questions</h2>
      <h3>Who is the richest person in the world right now?</h3>
      <p>According to our <time datetime="${escapeHtml(lastUpdatedIso)}">${lastUpdatedHuman}</time> valuation snapshot, <a href="profiles/${escapeHtml(musk.id)}.html"><strong>${escapeHtml(musk.name)}</strong></a> ranks #1 globally with an estimated net worth of <strong>$${Number(musk.netWorthUsd).toFixed(1)} billion USD</strong> across ${escapeHtml(musk.source)}.</p>
      <h3>Who is the richest billionaire in India?</h3>
      <p><a href="profiles/${escapeHtml(top1India.id)}.html"><strong>${escapeHtml(top1India.name)}</strong></a> holds India's #1 spot (Global #${top1India.globalRank}) with an estimated fortune of <strong>${formatInrLakhCr(top1India.netWorthInrCrore)} ($${Number(top1India.netWorthUsd).toFixed(1)}B)</strong>, followed by <a href="profiles/${escapeHtml(top2India.id)}.html"><strong>${escapeHtml(top2India.name)}</strong></a> at ${formatInrLakhCr(top2India.netWorthInrCrore)}.</p>
      <h3>How often are valuations synchronized?</h3>
      <p>Our automated data pipeline refreshes exchange quotes, promoter disclosures, and USD/INR forex rates on a scheduled cadence, writing verified snapshots directly into static HTML and JSON for fast delivery and full search-engine indexability.</p>
    </section>

    <section class="info-section" id="articles">
      <h2>Research Articles &amp; Market Deep Dives</h2>
      <p>Explore original data journalism and structural studies across billionaire asset allocation, sovereign wealth comparisons, and family offices:</p>
      <div class="article-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 22px; margin-top: 24px;">
        <div class="article-card" style="background: var(--card-bg); border-radius: var(--border-radius); padding: 20px; box-shadow: var(--shadow);">
          <h3 style="color: var(--accent); margin-top: 0;">Where Billionaires Are Investing in 2026: Private Markets</h3>
          <p style="margin-bottom: 15px;">Analysis of institutional capital allocation across private credit, AI compute infrastructure, and energy transition assets.</p>
          <a href="insights/billionaire-investment-strategy-2026.html" class="btn btn-primary" style="display: inline-block;">Read Investment Strategy Report &rarr;</a>
        </div>
        <div class="article-card" style="background: var(--card-bg); border-radius: var(--border-radius); padding: 20px; box-shadow: var(--shadow);">
          <h3 style="color: var(--accent); margin-top: 0;">California Wealth Tax Proposal &amp; Founder Mobility</h3>
          <p style="margin-bottom: 15px;">Examining how unrealized equity taxation mechanics affect Silicon Valley cap tables and state tax policy.</p>
          <a href="insights/california-wealth-tax-explained.html" class="btn btn-primary" style="display: inline-block;">Read Wealth Tax Analysis &rarr;</a>
        </div>
        <div class="article-card" style="background: var(--card-bg); border-radius: var(--border-radius); padding: 20px; box-shadow: var(--shadow); border-top: 3px solid #4ade80;">
          <h3 style="color: var(--accent); margin-top: 0;">The Race to the First $1 Trillion Fortune</h3>
          <p style="margin-bottom: 15px;">Mathematical compounding scenarios for Tesla robotics, SpaceX Starlink, and hyperscale AI equity.</p>
          <a href="insights/first-trillionaire-race.html" class="btn btn-primary" style="display: inline-block;">Read Trillionaire Race Breakdown &rarr;</a>
        </div>
        <div class="article-card" style="background: var(--card-bg); border-radius: var(--border-radius); padding: 20px; box-shadow: var(--shadow);">
          <h3 style="color: var(--accent); margin-top: 0;">7 Billionaire Capital Compounding Principles</h3>
          <p style="margin-bottom: 15px;">Case studies across Berkshire Hathaway, Alphabet, Inditex, and Reliance equity governance.</p>
          <a href="insights/billionaire-wealth-strategies.html" class="btn btn-primary" style="display: inline-block;">Read 7 Wealth Strategies &rarr;</a>
        </div>
        <div class="article-card" style="background: var(--card-bg); border-radius: var(--border-radius); padding: 20px; box-shadow: var(--shadow);">
          <h3 style="color: var(--accent); margin-top: 0;">Strategic Philanthropy &amp; Foundation Pledges</h3>
          <p style="margin-bottom: 15px;">Tracking climate mitigation endowments, global health grants, and donor-advised equity vehicles.</p>
          <a href="insights/billionaire-philanthropy-2026.html" class="btn btn-primary" style="display: inline-block;">Read Philanthropy Report &rarr;</a>
        </div>
        <div class="article-card" style="background: var(--card-bg); border-radius: var(--border-radius); padding: 20px; box-shadow: var(--shadow);">
          <h3 style="color: var(--accent); margin-top: 0;">Mukesh Ambani Family Office &amp; Reliance Structure</h3>
          <p style="margin-bottom: 15px;">Inside India's largest promoter group across Jio Platforms, Reliance Retail, and green hydrogen capital.</p>
          <a href="insights/mukesh-ambani-family-office.html" class="btn btn-primary" style="display: inline-block;">Read Ambani Case Study &rarr;</a>
        </div>
      </div>
      <div style="text-align: center; margin-top: 24px;">
        <a href="articles.html" class="btn btn-primary" style="display: inline-flex; align-items: center; gap: 8px; padding: 12px 26px; font-weight: 800; border-radius: 8px;">
          <i class="fas fa-newspaper"></i> Browse Full Research Articles Hub &rarr;
        </a>
      </div>
    </section>
    <!-- PRERENDERED_MAIN_END -->
  `;
}

export function generateSite() {
  const configPath = path.join(SITE_ROOT, 'data', 'holdings-config.json');
  const dataPath = path.join(SITE_ROOT, 'data', 'billionaires.json');
  const templatePath = path.join(SITE_ROOT, 'scripts', 'profile-template.html');

  const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  const liveData = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
  const template = fs.readFileSync(templatePath, 'utf8');

  const configMap = new Map(config.billionaires.map((c) => [c.id, c]));
  const fxRate = Number(liveData.meta?.currencyUsdInrRate || config.meta?.defaultUsdInrRate || 94.29);
  const lastUpdatedIso = liveData.meta?.lastUpdated || new Date().toISOString();
  const lastUpdatedDate = lastUpdatedIso.slice(0, 10);
  const lastUpdatedHuman = formatHumanDate(lastUpdatedIso);
  const lastUpdatedShort = formatShortUtc(lastUpdatedIso);

  // Merge live figures + config editorial metadata & strictly sort descending
  const mergedList = liveData.billionaires
    .map((b) => {
      const cfg = configMap.get(b.id) || {};
      const worth = Number(b.netWorthUsd ?? cfg.baselineNetWorthUsd ?? 0);
      const inrCrore = b.netWorthInrCrore || Math.round(worth * fxRate * 100);
      const disclosures = Array.isArray(b.disclosures) && b.disclosures.length > 0
        ? b.disclosures
        : [
            ...(cfg.publicHoldings || []).map((ph) => ({
              companyName: ph.companyName,
              ticker: ph.ticker,
              exchange: ph.exchange,
              shares: ph.shares,
              priceUsd: ph.fallbackPrice,
              exerciseOptionPriceUsd: ph.exerciseOptionPrice,
              isOption: Boolean(ph.exerciseOptionPrice),
              valueBillions: parseFloat(((ph.shares * ph.fallbackPrice) / 1e9).toFixed(2))
            })),
            ...(cfg.privateAndOptionHoldings || [])
          ];

      return {
        ...cfg,
        ...b,
        netWorthUsd: parseFloat(worth.toFixed(1)),
        netWorthInrCrore: inrCrore,
        publicEquityUsd: Number(b.publicEquityUsd ?? worth * 0.85).toFixed(1),
        vestedOptionsUsd: Number(b.vestedOptionsUsd ?? 0).toFixed(1),
        privateAssetsUsd: Number(b.privateAssetsUsd ?? worth * 0.15).toFixed(1),
        disclosures,
        profileUrl: `profiles/${b.id}.html`,
        hasDedicatedProfile: true
      };
    })
    .sort((a, b) => Number(b.netWorthUsd) - Number(a.netWorthUsd));

  // Re-assign clean 1-based global and country ranks
  const countryCounters = {};
  mergedList.forEach((b, idx) => {
    b.globalRank = idx + 1;
    countryCounters[b.country] = (countryCounters[b.country] || 0) + 1;
    b.countryRank = countryCounters[b.country];
  });

  // 1. Render all 17 profile pages
  const profilesDir = path.join(SITE_ROOT, 'profiles');
  if (!fs.existsSync(profilesDir)) fs.mkdirSync(profilesDir, { recursive: true });

  for (const person of mergedList) {
    const usdStr = `$${Number(person.netWorthUsd).toFixed(1)}B`;
    const inrStr = `${formatInrLakhCr(person.netWorthInrCrore)} / ₹${formatInrCrores(person.netWorthInrCrore)} Cr`;
    const dailyNum = Number(person.dailyChange || 0);
    const dailyStr = `${dailyNum >= 0 ? '+' : ''}${dailyNum.toFixed(2)}%`;

    const historyArr = Array.isArray(person.history) && person.history.length >= 10
      ? [...person.history.slice(0, 10), Number(person.netWorthUsd)]
      : [10, 12, 15, 18, 22, 28, 35, 45, 60, 75, Number(person.netWorthUsd)];

    const compList = Array.isArray(person.wealthComposition) && person.wealthComposition.length > 0
      ? person.wealthComposition
      : [
          { name: `${person.source} Equity`, value: 85, color: person.color || '#f9c74f' },
          { name: 'Private Holdings & Cash', value: 15, color: '#4ade80' }
        ];

    const compBarHtml = compList.map((c) =>
      `<div style="width:${c.value}%; background:${escapeHtml(c.color)};" title="${escapeHtml(c.name)}: ${c.value}%"></div>`
    ).join('');
    const compLegendHtml = compList.map((c) =>
      `<div class="legend-chip"><span class="legend-dot" style="background:${escapeHtml(c.color)};"></span><span>${escapeHtml(c.name)} (${c.value}%)</span></div>`
    ).join('');

    const timelineHtml = (person.careerTimeline || []).map((t) =>
      `<li><strong>${escapeHtml(t.year)}:</strong> ${escapeHtml(t.event)}</li>`
    ).join('\n');

    const faqs = Array.isArray(person.faqs) && person.faqs.length > 0
      ? person.faqs
      : [
          {
            q: `What is ${person.name}'s estimated net worth in 2026?`,
            a: `As of ${lastUpdatedHuman}, ${person.name}'s estimated net worth is ${usdStr} USD (${inrStr}) across ${person.source}.`
          },
          {
            q: `How does BillionaireWatch.in calculate ${person.name}'s wealth?`,
            a: `We multiply SEC or BSE/NSE disclosed share counts by public closing equity prices and add verified private valuation benchmarks.`
          }
        ];

    const faqHtml = faqs.map((f) =>
      `<div class="faq-item"><h3>${escapeHtml(f.q)}</h3><p>${escapeHtml(f.a)}</p></div>`
    ).join('\n');

    const countryAnchor = person.country === 'IN' ? 'india' : (person.country === 'US' ? 'usa' : 'global');
    const countryBadge = person.country === 'IN'
      ? `<strong>#${person.countryRank} in India</strong>`
      : `<strong>#${person.countryRank} in ${escapeHtml(person.countryName || person.country)}</strong>`;

    const sameCountryPeers = mergedList
      .filter((p) => p.id !== person.id && p.country === person.country)
      .slice(0, 4);
    const sameSectorPeers = mergedList
      .filter((p) => p.id !== person.id && p.primarySector === person.primarySector)
      .slice(0, 4);
    const adjacentRanks = mergedList
      .filter((p) => p.id !== person.id && Math.abs(p.globalRank - person.globalRank) <= 3)
      .slice(0, 4);

    const introParagraph = `${person.name} holds Global Rank #${person.globalRank} with an independent estimated net worth of ${usdStr} USD (${inrStr}) as of ${lastUpdatedHuman}. Wealth is anchored primarily by equity ownership in ${person.source}.`;

    const schemaOrg = {
      '@context': 'https://schema.org',
      '@type': 'Organization',
      name: 'Billionaire Watch',
      url: 'https://www.billionairewatch.in/',
      logo: 'https://www.billionairewatch.in/logo.png',
      contactPoint: {
        '@type': 'ContactPoint',
        contactType: 'Editorial Desk',
        email: 'editorial@billionairewatch.in'
      }
    };

    const schemaPerson = {
      '@context': 'https://schema.org',
      '@type': 'Person',
      name: person.name,
      description: introParagraph,
      url: `https://www.billionairewatch.in/profiles/${person.id}.html`,
      image: `https://www.billionairewatch.in/images/og-billionaires/${person.id}.jpg`,
      jobTitle: person.source,
      nationality: person.countryName || person.country,
      netWorth: {
        '@type': 'MonetaryAmount',
        currency: 'USD',
        value: Math.round(Number(person.netWorthUsd) * 1e9)
      },
      knowsAbout: person.industries || [person.primarySector || 'Business Leadership']
    };

    const schemaBreadcrumb = {
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: 'https://www.billionairewatch.in/' },
        { '@type': 'ListItem', position: 2, name: `${person.countryName || person.country} Rankings`, item: `https://www.billionairewatch.in/#${countryAnchor}` },
        { '@type': 'ListItem', position: 3, name: person.name, item: `https://www.billionairewatch.in/profiles/${person.id}.html` }
      ]
    };

    const schemaFaq = {
      '@context': 'https://schema.org',
      '@type': 'FAQPage',
      mainEntity: faqs.map((f) => ({
        '@type': 'Question',
        name: f.q,
        acceptedAnswer: { '@type': 'Answer', text: f.a }
      }))
    };

    let html = template;
    const replacements = {
      '{{ID}}': person.id,
      '{{NAME}}': escapeHtml(person.name),
      '{{PAGE_TITLE}}': `${person.name} Net Worth 2026 (${usdStr}) | Public Disclosures & Holdings | BillionaireWatch.in`,
      '{{META_DESCRIPTION}}': `${person.name} estimated net worth is ${usdStr} (${formatInrLakhCr(person.netWorthInrCrore)}) as of ${lastUpdatedHuman}. Audited SEC/BSE shareholding breakdown, wealth composition, 10-year chart & FAQ.`,
      '{{OG_TITLE}}': `${person.name} Net Worth 2026: ${usdStr} (${formatInrLakhCr(person.netWorthInrCrore)})`,
      '{{OG_DESCRIPTION}}': `Global Rank #${person.globalRank}. Explore ${person.name}'s equity holdings in ${person.source}, valuation methodology, and 10-year net worth chart.`,
      '{{MODIFIED_ISO}}': lastUpdatedIso,
      '{{LAST_UPDATED_HUMAN}}': lastUpdatedHuman,
      '{{LAST_UPDATED_SHORT}}': lastUpdatedShort,
      '{{COUNTRY_ANCHOR}}': countryAnchor,
      '{{COUNTRY_NAME}}': escapeHtml(person.countryName || person.country),
      '{{COUNTRY_RANK_BADGE}}': countryBadge,
      '{{GLOBAL_RANK}}': String(person.globalRank),
      '{{PRIMARY_SECTOR}}': escapeHtml(person.primarySector || 'Global Markets'),
      '{{USD_DISPLAY}}': `${usdStr} USD`,
      '{{INR_DISPLAY}}': inrStr,
      '{{FX_RATE}}': fxRate.toFixed(2),
      '{{DAILY_CHANGE_DISPLAY}}': dailyStr,
      '{{AGE}}': person.age ? String(person.age) : 'N/A',
      '{{SOURCE}}': escapeHtml(person.source),
      '{{INTRO_PARAGRAPH}}': escapeHtml(introParagraph),
      '{{BIO_PARAGRAPH}}': escapeHtml(person.bio || ''),
      '{{PUBLIC_EQUITY_USD}}': person.publicEquityUsd,
      '{{VESTED_OPTIONS_USD}}': person.vestedOptionsUsd,
      '{{PRIVATE_ASSETS_USD}}': person.privateAssetsUsd,
      '{{DISCLOSURES_ROWS}}': buildDisclosuresRows(person),
      '{{COMPOSITION_BAR_HTML}}': compBarHtml,
      '{{COMPOSITION_LEGEND_HTML}}': compLegendHtml,
      '{{CAREER_TIMELINE_HTML}}': timelineHtml,
      '{{PHILANTHROPY_TEXT}}': escapeHtml(person.philanthropy || 'Public philanthropy allocations tracked via institutional foundation filings.'),
      '{{ELON_DEEP_DIVE_SECTION}}': person.id === 'elon-musk' ? buildElonDeepDive(person, mergedList) : '',
      '{{ELON_EXTRA_SCRIPTS}}': person.id === 'elon-musk' ? '<script src="../assets/js/spend-elon-game.js" defer></script>' : '',
      '{{FAQ_HTML}}': faqHtml,
      '{{RELATED_COUNTRY_HTML}}': sameCountryPeers.length
        ? sameCountryPeers.map((p) => buildRelatedCard(p, true)).join('\n')
        : '<a href="../index.html#global" class="related-card"><div class="related-card-title">Global Top 10 Terminal</div><div class="related-card-meta">View full international rankings</div></a>',
      '{{RELATED_SECTOR_HTML}}': sameSectorPeers.length
        ? sameSectorPeers.map((p) => buildRelatedCard(p, false)).join('\n')
        : mergedList.slice(0, 3).filter((p) => p.id !== person.id).map((p) => buildRelatedCard(p, false)).join('\n'),
      '{{RELATED_ADJACENT_HTML}}': adjacentRanks.map((p) => buildRelatedCard(p, false)).join('\n'),
      '{{HISTORY_JSON}}': JSON.stringify(historyArr),
      '{{CHART_COLOR}}': person.color || '#f9c74f',
      '{{COMPOSITION_LABELS_JSON}}': JSON.stringify(compList.map((c) => c.name)),
      '{{COMPOSITION_VALUES_JSON}}': JSON.stringify(compList.map((c) => c.value)),
      '{{COMPOSITION_COLORS_JSON}}': JSON.stringify(compList.map((c) => c.color)),
      '{{SCHEMA_ORGANIZATION_JSON}}': JSON.stringify(schemaOrg),
      '{{SCHEMA_PERSON_JSON}}': JSON.stringify(schemaPerson),
      '{{SCHEMA_BREADCRUMB_JSON}}': JSON.stringify(schemaBreadcrumb),
      '{{SCHEMA_FAQ_JSON}}': JSON.stringify(schemaFaq)
    };

    for (const [token, val] of Object.entries(replacements)) {
      html = html.split(token).join(val);
    }

    fs.writeFileSync(path.join(profilesDir, `${person.id}.html`), html, 'utf8');
  }

  // 2. Inject pre-rendered <main> + updated modified_time + FAQPage/Organization/ItemList JSON-LD into index.html
  const indexPath = path.join(SITE_ROOT, 'index.html');
  let indexHtml = fs.readFileSync(indexPath, 'utf8');

  const renderedMain = buildHomepageMainHtml(mergedList, { ...liveData.meta, currencyUsdInrRate: fxRate, lastUpdated: lastUpdatedIso });

  const mainRegex = /(<main[^>]*id="main-content"[^>]*>)[\s\S]*?(?=\n\s*<!-- Profile Modal -->)/i;
  if (mainRegex.test(indexHtml)) {
    indexHtml = indexHtml.replace(mainRegex, (_m, openTag) => `${openTag}\n${renderedMain}\n    </main>`);
  } else {
    const fallbackMainRegex = /(<main[^>]*id="main-content"[^>]*>)[\s\S]*?(<\/main>)/i;
    if (!fallbackMainRegex.test(indexHtml)) {
      throw new Error('Could not locate <main id="main-content"> in public/live-site/index.html');
    }
    indexHtml = indexHtml.replace(fallbackMainRegex, (_m, openTag, closeTag) => `${openTag}\n${renderedMain}\n    ${closeTag}`);
  }

  // Update article:modified_time & ensure revisit-after stays removed
  indexHtml = indexHtml.replace(/<meta\s+name="revisit-after"[^>]*>\s*/gi, '');
  indexHtml = indexHtml.replace(
    /<meta\s+property="article:modified_time"\s+content="[^"]*"\s*\/?>/i,
    () => `<meta property="article:modified_time" content="${lastUpdatedIso}">`
  );

  // Inject/update structured JSON-LD block if markers exist
  const schemaBlock = `<!-- SEO_SCHEMA_START -->
    <script type="application/ld+json">${JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'WebSite',
      name: 'Billionaire Watch',
      url: 'https://www.billionairewatch.in/',
      description: 'Independent wealth tracking index using SEC EDGAR, BSE, and NSE disclosures with public equity market quotes.',
      dateModified: lastUpdatedIso,
      publisher: {
        '@type': 'Organization',
        name: 'Billionaire Watch',
        url: 'https://www.billionairewatch.in/',
        logo: 'https://www.billionairewatch.in/logo.png',
        contactPoint: { '@type': 'ContactPoint', contactType: 'Editorial Desk', email: 'editorial@billionairewatch.in' }
      }
    })}</script>
    <script type="application/ld+json">${JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'ItemList',
      name: 'Global Top 10 Billionaires Net Worth Rankings',
      numberOfItems: 10,
      itemListElement: mergedList.slice(0, 10).map((b) => ({
        '@type': 'ListItem',
        position: b.globalRank,
        url: `https://www.billionairewatch.in/profiles/${b.id}.html`,
        name: `${b.name} ($${Number(b.netWorthUsd).toFixed(1)}B)`
      }))
    })}</script>
    <script type="application/ld+json">${JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: 'https://www.billionairewatch.in/' },
        { '@type': 'ListItem', position: 2, name: 'Billionaire Net Worth Rankings', item: 'https://www.billionairewatch.in/#global' }
      ]
    })}</script>
    <script type="application/ld+json">${JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'FAQPage',
      mainEntity: [
        {
          '@type': 'Question',
          name: 'Who is the richest person in the world right now?',
          acceptedAnswer: { '@type': 'Answer', text: `${mergedList[0].name} ranks #1 globally at an estimated $${Number(mergedList[0].netWorthUsd).toFixed(1)}B USD as of ${lastUpdatedHuman}.` }
        },
        {
          '@type': 'Question',
          name: 'Who is the richest billionaire in India?',
          acceptedAnswer: { '@type': 'Answer', text: `${mergedList.find((b) => b.country === 'IN').name} leads India at ${formatInrLakhCr(mergedList.find((b) => b.country === 'IN').netWorthInrCrore)} ($${Number(mergedList.find((b) => b.country === 'IN').netWorthUsd).toFixed(1)}B USD).` }
        },
        {
          '@type': 'Question',
          name: 'How does BillionaireWatch.in calculate net worth estimates?',
          acceptedAnswer: { '@type': 'Answer', text: 'Net worth figures multiply beneficial share counts from SEC EDGAR and BSE/NSE filings by public stock market prices, adding vested option spreads and private financing benchmarks.' }
        }
      ]
    })}</script>
    <!-- SEO_SCHEMA_END -->`;

  const seoMarkerRegex = /<!-- SEO_SCHEMA_START -->[\s\S]*?<!-- SEO_SCHEMA_END -->/;
  if (seoMarkerRegex.test(indexHtml)) {
    indexHtml = indexHtml.replace(seoMarkerRegex, () => schemaBlock);
  }

  fs.writeFileSync(indexPath, indexHtml, 'utf8');

  // 3. Regenerate sitemap.xml & robots.txt
  const coreUrls = [
    { loc: 'https://www.billionairewatch.in/', lastmod: lastUpdatedDate, changefreq: 'daily', priority: '1.0' },
    { loc: 'https://www.billionairewatch.in/spend-elon-money.html', lastmod: lastUpdatedDate, changefreq: 'daily', priority: '1.0' },
    { loc: 'https://www.billionairewatch.in/tools/wealth-blueprint.html', lastmod: lastUpdatedDate, changefreq: 'weekly', priority: '0.95' },
    { loc: 'https://www.billionairewatch.in/articles.html', lastmod: lastUpdatedDate, changefreq: 'weekly', priority: '0.90' },
    { loc: 'https://www.billionairewatch.in/analysis.html', lastmod: lastUpdatedDate, changefreq: 'weekly', priority: '0.85' },
    { loc: 'https://www.billionairewatch.in/about.html', lastmod: lastUpdatedDate, changefreq: 'monthly', priority: '0.75' },
    { loc: 'https://www.billionairewatch.in/contact.html', lastmod: lastUpdatedDate, changefreq: 'monthly', priority: '0.70' },
    { loc: 'https://www.billionairewatch.in/privacy-policy.html', lastmod: lastUpdatedDate, changefreq: 'monthly', priority: '0.50' },
    { loc: 'https://www.billionairewatch.in/terms.html', lastmod: lastUpdatedDate, changefreq: 'monthly', priority: '0.50' },
    { loc: 'https://www.billionairewatch.in/disclaimer.html', lastmod: lastUpdatedDate, changefreq: 'monthly', priority: '0.50' }
  ];

  const profileUrls = mergedList.map((b) => ({
    loc: `https://www.billionairewatch.in/profiles/${b.id}.html`,
    lastmod: lastUpdatedDate,
    changefreq: 'daily',
    priority: b.globalRank <= 10 || b.country === 'IN' ? '0.95' : '0.90'
  }));

  const insightFiles = [
    'billionaire-investment-strategy-2026.html',
    'california-wealth-tax-explained.html',
    'first-trillionaire-race.html',
    'billionaire-wealth-strategies.html',
    'billionaire-philanthropy-2026.html',
    'mukesh-ambani-family-office.html'
  ].map((file) => ({
    loc: `https://www.billionairewatch.in/insights/${file}`,
    lastmod: lastUpdatedDate,
    changefreq: 'weekly',
    priority: '0.85'
  }));

  const allUrls = [...coreUrls, ...profileUrls, ...insightFiles];
  const sitemapXml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${allUrls.map((u) => `  <url>
    <loc>${u.loc}</loc>
    <lastmod>${u.lastmod}</lastmod>
    <changefreq>${u.changefreq}</changefreq>
    <priority>${u.priority}</priority>
  </url>`).join('\n')}
</urlset>
`;
  fs.writeFileSync(path.join(SITE_ROOT, 'sitemap.xml'), sitemapXml, 'utf8');

  const robotsTxt = `User-agent: *
Allow: /
Disallow: /scripts/
Disallow: /netlify/

Sitemap: https://www.billionairewatch.in/sitemap.xml
`;
  fs.writeFileSync(path.join(SITE_ROOT, 'robots.txt'), robotsTxt, 'utf8');

  console.log(`[Site Generator] Pre-rendered index.html, generated ${mergedList.length} profiles, and wrote ${allUrls.length} URLs to sitemap.xml.`);
}

if (process.argv[1] && path.resolve(process.argv[1]) === __filename) {
  generateSite();
}
