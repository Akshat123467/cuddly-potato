#!/usr/bin/env node
/**
 * BillionaireWatch.in - Unique OG Image & Local Avatar Generator
 * Uses native ImageMagick (`convert`) primitives (no external SVG delegates) to render crisp
 * 1200x630 JPG social cards, 512x512 logo.png, and 400x400 compressed local avatar tiles.
 */
import fs from 'fs';
import path from 'path';
import { execFileSync } from 'child_process';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const SITE_ROOT = path.resolve(__dirname, '..');

function resolveFont(candidates) {
  for (const p of candidates) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

const FONT_BOLD = resolveFont([
  '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
  '/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf',
  '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',
]);

const FONT_REG = resolveFont([
  '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
  '/usr/share/fonts/dejavu/DejaVuSans.ttf',
  '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf',
]) || FONT_BOLD;

function ensureDir(dir) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

function cleanLabel(str, maxLen = 78) {
  return String(str || '')
    .replace(/[\r\n]+/g, ' ')
    .replace(/^@/, '')
    .replace(/%/g, '%%')
    .slice(0, maxLen)
    .trim();
}

function formatInrLakhCr(crores) {
  if (!crores || Number.isNaN(Number(crores))) return 'Rs.0 Cr';
  const lakhCr = Number(crores) / 100000;
  if (lakhCr >= 1) {
    return `Rs.${lakhCr.toFixed(2)} Lakh Cr`;
  }
  return `Rs.${Math.round(Number(crores)).toLocaleString('en-US')} Cr`;
}

function withFont(fontPath) {
  return fontPath ? ['-font', fontPath] : [];
}

function generateLogo() {
  const outLogo = path.join(SITE_ROOT, 'logo.png');
  const args = [
    '-size', '512x512',
    'gradient:#1a1a2e-#0f0f1a',
    '-fill', 'none', '-stroke', '#f9c74f', '-strokewidth', '10',
    '-draw', 'roundrectangle 18,18 494,494 84,84',
    '-stroke', 'none', '-fill', '#f9c74f',
    '-draw', 'polygon 112,316 142,172 212,246 256,142 300,246 370,172 400,316',
    '-draw', 'roundrectangle 112,336 400,364 8,8',
    ...withFont(FONT_BOLD),
    '-pointsize', '44', '-fill', '#ffffff', '-gravity', 'North',
    '-annotate', '+0+388', 'BW.IN',
    '-strip',
    outLogo,
  ];
  execFileSync('convert', args, { stdio: 'pipe' });
}

function renderOgCardJpg(outPath, {
  eyebrow,
  title,
  subtitle,
  statPrimary,
  statSecondary,
  badgeText,
  accentColor = '#f9c74f',
  dateStr,
  quality = '84',
}) {
  const args = [
    '-size', '1200x630',
    'gradient:#0f0f1a-#1a1a2e',
    '-fill', 'none', '-stroke', accentColor, '-strokewidth', '3',
    '-draw', 'roundrectangle 34,34 1166,596 22,22',
    '-fill', '#16213e', '-stroke', accentColor, '-strokewidth', '2',
    '-draw', 'roundrectangle 70,74 470,118 22,22',
    '-stroke', '#4ade80',
    '-draw', 'roundrectangle 800,74 1126,118 22,22',
    '-fill', '#0f0f1a', '-stroke', accentColor, '-strokewidth', '2',
    '-draw', 'roundrectangle 72,316 1126,480 18,18',
    '-stroke', 'none', '-fill', accentColor,
    '-draw', 'roundrectangle 72,508 1126,516 4,4',

    ...withFont(FONT_BOLD),
    '-pointsize', '19', '-fill', accentColor, '-gravity', 'NorthWest',
    '-annotate', '+94+85', cleanLabel(eyebrow, 34),

    '-pointsize', '19', '-fill', '#4ade80', '-gravity', 'NorthEast',
    '-annotate', '+96+85', cleanLabel(badgeText, 28),

    '-pointsize', '54', '-fill', '#ffffff', '-gravity', 'NorthWest',
    '-annotate', '+72+160', cleanLabel(title, 32),

    ...withFont(FONT_REG),
    '-pointsize', '25', '-fill', '#cbd5e1', '-gravity', 'NorthWest',
    '-annotate', '+72+236', cleanLabel(subtitle, 68),

    ...withFont(FONT_BOLD),
    '-pointsize', '50', '-fill', accentColor, '-gravity', 'NorthWest',
    '-annotate', '+108+340', cleanLabel(statPrimary, 36),

    ...withFont(FONT_REG),
    '-pointsize', '24', '-fill', '#4ade80', '-gravity', 'NorthWest',
    '-annotate', '+108+412', cleanLabel(statSecondary, 68),

    ...withFont(FONT_BOLD),
    '-pointsize', '23', '-fill', accentColor, '-gravity', 'NorthWest',
    '-annotate', '+72+542', 'BillionaireWatch.in',

    ...withFont(FONT_REG),
    '-pointsize', '20', '-fill', '#94a3b8', '-gravity', 'NorthEast',
    '-annotate', '+74+544', `${cleanLabel(dateStr, 24)} | SEC, BSE/NSE & Public Data`,

    '-quality', quality,
    '-strip',
    outPath,
  ];
  execFileSync('convert', args, { stdio: 'pipe' });
}

function renderAvatarJpg(outPath, person, quality = '82') {
  const cleanName = String(person.name || 'Billionaire')
    .replace(/\s*&\s*family/i, '')
    .replace(/&amp;|&/g, ' ')
    .trim();
  const words = cleanName.split(/\s+/).filter(Boolean);
  const firstLine = (words[0] || 'BW').toUpperCase();
  const secondLine = words.slice(1).join(' ').toUpperCase();
  const maxWordLen = Math.max(firstLine.length, secondLine.length || 1);

  let pointSize = '54';
  if (maxWordLen <= 5) pointSize = '66';
  else if (maxWordLen <= 7) pointSize = '54';
  else if (maxWordLen <= 8) pointSize = '48';
  else pointSize = '40';

  const isIndia = person.country === 'IN';
  const accent = isIndia ? '#ff9933' : '#f9c74f';

  const textArgs = secondLine
    ? [
        ...withFont(FONT_BOLD),
        '-pointsize', pointSize, '-fill', '#ffffff', '-gravity', 'Center',
        '-annotate', '+0-32', cleanLabel(firstLine, 20),
        '-pointsize', pointSize, '-fill', accent, '-gravity', 'Center',
        '-annotate', '+0+34', cleanLabel(secondLine, 20),
      ]
    : [
        ...withFont(FONT_BOLD),
        '-pointsize', pointSize, '-fill', accent, '-gravity', 'Center',
        '-annotate', '+0+0', cleanLabel(firstLine, 20),
      ];

  const args = [
    '-size', '400x400',
    'gradient:#16213e-#0f0f1a',
    ...textArgs,
    '-quality', quality,
    '-strip',
    outPath,
  ];
  execFileSync('convert', args, { stdio: 'pipe' });
}

export function runOgGeneration() {
  const imagesDir = path.join(SITE_ROOT, 'images');
  const ogBillionairesDir = path.join(imagesDir, 'og-billionaires');
  const avatarsDir = path.join(imagesDir, 'avatars');
  ensureDir(imagesDir);
  ensureDir(ogBillionairesDir);
  ensureDir(avatarsDir);

  const dataPath = path.join(SITE_ROOT, 'data', 'billionaires.json');
  const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
  const list = data.billionaires || [];
  const lastUpdatedDate = String(data.meta?.lastUpdated || new Date().toISOString()).slice(0, 10);
  const fxRate = Number(data.meta?.currencyUsdInrRate || 94.09).toFixed(2);
  const top1 = list[0];

  generateLogo();

  renderOgCardJpg(path.join(imagesDir, 'og-image.jpg'), {
    eyebrow: 'INDEPENDENT WEALTH INDEX',
    badgeText: `FX: 1 USD = Rs.${fxRate}`,
    title: 'Billionaire Net Worth 2026',
    subtitle: 'Global Top 10, India Top 5 (INR Crores) & Public Disclosures',
    statPrimary: top1 ? `#1 ${top1.name}: $${Number(top1.netWorthUsd).toFixed(1)}B` : 'Global Wealth Terminal',
    statSecondary: top1 ? `${formatInrLakhCr(top1.netWorthInrCrore)} | ${list.length} Audited Profiles` : 'SEC, BSE & NSE Filings',
    accentColor: '#f9c74f',
    dateStr: `Updated ${lastUpdatedDate}`,
    quality: '84',
  });

  const insightsMeta = [
    {
      file: 'og-investment.jpg',
      eyebrow: 'INSTITUTIONAL RESEARCH',
      badgeText: '2026 ALLOCATION',
      title: 'Where Billionaires Invest',
      subtitle: 'AI Infrastructure, Private Credit, Robotics & Energy Transition',
      statPrimary: 'Private Equity & AI Compute',
      statSecondary: 'Portfolio Allocation Benchmarks Across Global Family Offices',
      accent: '#38bdf8',
    },
    {
      file: 'og-trillionaire.jpg',
      eyebrow: 'VALUATION SCENARIO ANALYSIS',
      badgeText: 'TRILLIONAIRE WATCH',
      title: 'The First Trillionaire Race',
      subtitle: 'Compounding Equity Curves Across SpaceX, Tesla, Nvidia & AI',
      statPrimary: '$1,000,000,000,000',
      statSecondary: 'Interactive Spending Simulator + Equity Sensitivity Models',
      accent: '#4ade80',
    },
    {
      file: 'og-wealth-strategies.jpg',
      eyebrow: 'CAPITAL PLAYBOOK',
      badgeText: '7 CORE LESSONS',
      title: 'Billionaire Wealth Strategies',
      subtitle: 'Concentrated Equity, Float Leverage & Multi-Decade Compounding',
      statPrimary: 'Ownership Over Salary',
      statSecondary: 'Case Studies from Berkshire Hathaway, Alphabet & Reliance',
      accent: '#f9c74f',
    },
    {
      file: 'og-philanthropy.jpg',
      eyebrow: 'GLOBAL IMPACT TRACKER',
      badgeText: 'PHILANTHROPY 2026',
      title: 'Strategic Billionaire Giving',
      subtitle: 'Climate Tech, Global Health, Education & Research Grants',
      statPrimary: '$100B+ Pledged Capital',
      statSecondary: 'How Endowments & Foundations Deploy Donor-Advised Equity',
      accent: '#a78bfa',
    },
    {
      file: 'og-california-tax.jpg',
      eyebrow: 'POLICY & DOMICILE IMPACT',
      badgeText: 'TAX ANALYSIS',
      title: 'California Wealth Tax Study',
      subtitle: 'How Proposed Net Worth Assessments Affect Founder Cap Tables',
      statPrimary: 'Unrealized Gains & Mobility',
      statSecondary: 'Silicon Valley Domicile Shifts & Trust Valuation Mechanics',
      accent: '#f87171',
    },
    {
      file: 'og-ambani-family-office.jpg',
      eyebrow: 'INDIA FAMILY OFFICE BRIEF',
      badgeText: 'INDIA #1 WEALTH',
      title: 'Mukesh Ambani Family Office',
      subtitle: 'Reliance Industries Promoters, Jio Digital, Retail & Green Energy',
      statPrimary: 'India Multi-Generational Hub',
      statSecondary: 'SEBI Promoter Disclosures, Dividends & Succession Architecture',
      accent: '#ff9933',
    },
  ];

  for (const item of insightsMeta) {
    renderOgCardJpg(path.join(imagesDir, item.file), {
      eyebrow: item.eyebrow,
      badgeText: item.badgeText,
      title: item.title,
      subtitle: item.subtitle,
      statPrimary: item.statPrimary,
      statSecondary: item.statSecondary,
      accentColor: item.accent,
      dateStr: `Updated ${lastUpdatedDate}`,
      quality: '82',
    });
  }

  for (const person of list) {
    const isIndia = person.country === 'IN';
    const accent = isIndia ? '#ff9933' : '#f9c74f';
    const badge = isIndia
      ? `INDIA #${person.countryRank || person.globalRank} | GLOBAL #${person.globalRank}`
      : `GLOBAL RANK #${person.globalRank}`;

    renderOgCardJpg(path.join(ogBillionairesDir, `${person.id}.jpg`), {
      eyebrow: `${person.countryName || person.country} WEALTH PROFILE`,
      badgeText: badge,
      title: person.name,
      subtitle: person.source,
      statPrimary: `$${Number(person.netWorthUsd).toFixed(1)} Billion USD`,
      statSecondary: `${formatInrLakhCr(person.netWorthInrCrore)} (Rs.${Math.round(Number(person.netWorthInrCrore)).toLocaleString('en-US')} Cr)`,
      accentColor: accent,
      dateStr: `Updated ${lastUpdatedDate}`,
      quality: '82',
    });

    renderAvatarJpg(path.join(avatarsDir, `${person.id}.jpg`), person, '82');
  }

  console.log(`[OG Generator] Generated logo.png, og-image.jpg, 6 insights JPGs, ${list.length} profile OG cards, and ${list.length} local avatars.`);
}

if (process.argv[1] && path.resolve(process.argv[1]) === __filename) {
  runOgGeneration();
}
